





//START OF JAVASCRIPT ENGINE TO OPERATE GAME

var RockBands60s_1,RockBands60s_2,RockBands60s_3,RockBands60s_4,RockBands60s_5,RockBands60s_6,RockBands60s_7,RockBands60s_8,RockBands60s_9,RockBands60s_10,StateCapital_1,StateCapital_2,
StateCapital_3,StateCapital_4,StateCapital_5,StateCapital_6,StateCapital_7,StateCapital_8,StateCapital_9,StateCapital_10,
 letter_3_1,letter_3_2,letter_3_3,letter_4_1,letter_4_2,letter_4_3,letter_4_4,letter_5_1,letter_5_2,letter_5_3,
 letter_5_4,letter_5_5,letter_6_1,letter_6_2,letter_6_3,letter_6_4,letter_6_5,letter_6_6,letter_7_1,letter_7_2,letter_7_3,letter_7_4,letter_7_5,letter_7_6,letter_7_7,
 letter_8_1,letter_8_2,letter_8_3,letter_8_4,letter_8_5,letter_8_6,letter_8_7,letter_8_8,counter_letter_1,counter_letter_2,counter_letter_3,counter_letter_4,counter_letter_5,counter_letter_6,counter_letter_7,counter_letter_8,counter_letter_9,counter_letter_10,
 charac_1,charac_2,charac_3,charac_4,charac_5,charac_6,charac_7,charac_8,letter_input,amount_of_letters,n,letters_left,questionCash,betCounter,questionCashArr,turned_off,score,totalQuestionCash7,total7cashMinus,main_score,r,end_of_category,total_letters,percentage,total_percent,
 letter_count,letter_total,CurrentLetterCount,aa,isPaused,timeLeft,elem, timerId,button_1,button_2,button_3,category_chosen,cash_8_8_minus;

var Controller = function(category,clue,letters,answer,counter,correctanswer,questionCash,categoryCash){
   this.category=category;
   this.clue=clue;
   this.letters=letters;
   this.answer=answer;
   this.counter=counter;
   this.correctanswer=correctanswer;
   this.questionCash=questionCash;
   this.categoryCash=categoryCash;
   
   
}
  
//gets data from instances/objects to place into question box   
Controller.prototype.addHTML= function(obj){


end_of_category=document.querySelector('.clue_count').innerHTML=(obj.counter);
betCounter=document.querySelector('.clue_count_betters').innerHTML=(obj.counter);
category_chosen=document.querySelector('.category_chosed').innerHTML=(obj.category);
document.querySelector('.category_chosed_now').innerHTML=(obj.category);
document.querySelector('.category_chosed_betters').innerHTML=(obj.category);
document.querySelector('.clue').innerHTML=(obj.clue);
amount_of_letters=document.querySelector('.letter_count').innerHTML=(obj.letters);


if(obj.letters===3){
  document.querySelector(".write_box_3_3").classList.add('show_boxes');
  document.querySelector(".write_box_3_3").classList.remove('hide_boxes');
  document.querySelector(".write_box_4_4").classList.add('hide_boxes');
  document.querySelector(".write_box_5_5").classList.add('hide_boxes');
  document.querySelector(".write_box_6_6").classList.add('hide_boxes');
  document.querySelector(".write_box_7_7").classList.add('hide_boxes');
  document.querySelector(".write_box_8_8").classList.add('hide_boxes');
  
}else if(obj.letters===4){
  document.querySelector(".write_box_4_4").classList.add('show_boxes');
  document.querySelector(".write_box_4_4").classList.remove('hide_boxes');
  document.querySelector(".write_box_3_3").classList.add('hide_boxes');
  document.querySelector(".write_box_5_5").classList.add('hide_boxes');
  document.querySelector(".write_box_6_6").classList.add('hide_boxes');
  document.querySelector(".write_box_7_7").classList.add('hide_boxes');
  document.querySelector(".write_box_8_8").classList.add('hide_boxes');
  
}else if(obj.letters===5){
  document.querySelector(".write_box_5_5").classList.add('show_boxes');
  document.querySelector(".write_box_5_5").classList.remove('hide_boxes');
  document.querySelector(".write_box_3_3").classList.add('hide_boxes');
  document.querySelector(".write_box_4_4").classList.add('hide_boxes');
  document.querySelector(".write_box_6_6").classList.add('hide_boxes');
  document.querySelector(".write_box_7_7").classList.add('hide_boxes');
  document.querySelector(".write_box_8_8").classList.add('hide_boxes');
  
}else if(obj.letters===6){
  document.querySelector(".write_box_6_6").classList.add('show_boxes');
  document.querySelector(".write_box_6_6").classList.remove('hide_boxes');
  document.querySelector(".write_box_7_7").classList.add('hide_boxes');
  document.querySelector(".write_box_8_8").classList.add('hide_boxes');
  document.querySelector(".write_box_3_3").classList.add('hide_boxes');
  document.querySelector(".write_box_4_4").classList.add('hide_boxes');
  document.querySelector(".write_box_5_5").classList.add('hide_boxes');
  ;
}else if(obj.letters===7){
  document.querySelector(".write_box_7_7").classList.add('show_boxes');
  document.querySelector(".write_box_7_7").classList.remove('hide_boxes');
  document.querySelector(".write_box_3_3").classList.add('hide_boxes');
  document.querySelector(".write_box_5_5").classList.add('hide_boxes');
  document.querySelector(".write_box_6_6").classList.add('hide_boxes');
  document.querySelector(".write_box_4_4").classList.add('hide_boxes');
  document.querySelector(".write_box_8_8").classList.add('hide_boxes');
  
}else{
  document.querySelector(".write_box_8_8").classList.add('show_boxes');
  document.querySelector(".write_box_8_8").classList.remove('hide_boxes');
  document.querySelector(".write_box_7_7").classList.add('hide_boxes');
  document.querySelector(".write_box_6_6").classList.add('hide_boxes');
  document.querySelector(".write_box_3_3").classList.add('hide_boxes');
  document.querySelector(".write_box_4_4").classList.add('hide_boxes');
  document.querySelector(".write_box_5_5").classList.add('hide_boxes');
 
}

};

//keeps track of questions and where you are in their sequence
Controller.prototype.keepTrackOfQuestions=function(obj,arr,arr2){
     
  if(obj.counter===1){
    obj.addHTML(obj);
    arr.push('question 1');
    
    arr2=[];
     arr2.push(obj.letters);
     aa=arr2;
   
    
   
  }else if(obj.counter===2){
    obj.addHTML(obj);
    arr.push('question 2');
    
    arr2=[];
   arr2.push(obj.letters);
   aa=arr2;
    
    
    
  }else if(obj.counter===3){
    obj.addHTML(obj);
    arr.push('question 3');
    
    arr2=[];
    arr2.push(obj.letters);
    aa=arr2;
    ;
     
     
  }else if(obj.counter===4){
    obj.addHTML(obj);
    arr.push('question 4');
    
    arr2=[];
    arr2.push(obj.letters);
    aa=arr2;
    
     
     
  }else if(obj.counter===5){
    obj.addHTML(obj);
    arr.push('question 5');
    
    arr2=[];
    arr2.push(obj.letters);
    aa=arr2;
 
     
     
  }else if(obj.counter===6){
    obj.addHTML(obj);
    arr.push('question 6');
    
    arr2=[];
    arr2.push(obj.letters);
    aa=arr2;
    
    
  }else if(obj.counter===7){
    obj.addHTML(obj);
    arr.push('question 7');
    
    arr2=[];
    arr2.push(obj.letters);
    aa=arr2;
    
    
  }else if(obj.counter===8){
    obj.addHTML(obj);
    arr.push('question 8');
    
    arr2=[];
    arr2.push(obj.letters);
    aa=arr2;
    
    
  }else if(obj.counter===9){
    obj.addHTML(obj);
    arr.push('question 9');
    ;
    arr2=[];
    arr2.push(obj.letters);
    aa=arr2;
    
    
  }else if(obj.counter===10){
    obj.addHTML(obj);
    arr.push('question 10');
    
    arr2=[];
    arr2.push(obj.letters);
    aa=arr2;
    
    
  }
  
}

//retrieves data to be compared with the input data
Controller.prototype.quessAnswer=function(obj){
 
if(obj.letters===3){
  letter_3_1 = obj.answer[0];
  letter_3_2 = obj.answer[1];
  letter_3_3 = obj.answer[2];
  CurrentAnswerLetters=[];
   CurrentAnswerLetters.push(letter_3_1,letter_3_2,letter_3_3);
   
}else if(obj.letters===4){
  letter_4_1 = obj.answer[0];
  letter_4_2 = obj.answer[1];
  letter_4_3 = obj.answer[2];
  letter_4_4 = obj.answer[3];
  CurrentAnswerLetters=[];
   CurrentAnswerLetters.push(letter_4_1,letter_4_2,letter_4_3,letter_4_4);
   
  }else if(obj.letters===5){
  letter_5_1=obj.answer[0];
  letter_5_2=obj.answer[1];
  letter_5_3=obj.answer[2];
  letter_5_4=obj.answer[3];
  letter_5_5=obj.answer[4];
  CurrentAnswerLetters=[];
   CurrentAnswerLetters.push(letter_5_1,letter_5_2,letter_5_3,letter_5_4,letter_5_5);
   
}else if(obj.letters===6){
  letter_6_1=obj.answer[0];
  letter_6_2=obj.answer[1];
  letter_6_3=obj.answer[2];
  letter_6_4=obj.answer[3];
  letter_6_5=obj.answer[4];
  letter_6_6=obj.answer[5];
  CurrentAnswerLetters=[];
   CurrentAnswerLetters.push(letter_6_1,letter_6_2,letter_6_3,letter_6_4,letter_6_5,letter_6_6);
  
}else if(obj.letters===7){
   letter_7_1=obj.answer[0];
   letter_7_2=obj.answer[1];
   letter_7_3=obj.answer[2];
   letter_7_4=obj.answer[3];
   letter_7_5= obj.answer[4];
   letter_7_6=obj.answer[5];
   letter_7_7=obj.answer[6];
   CurrentAnswerLetters=[];
   CurrentAnswerLetters.push(letter_7_1,letter_7_2,letter_7_3,letter_7_4,letter_7_5,letter_7_6,letter_7_7);
   
}else if(obj.letters===8){
  letter_8_1=obj.answer[0];
  letter_8_2=obj.answer[1];
  letter_8_3=obj.answer[2];
  letter_8_4=obj.answer[3];
  letter_8_5= obj.answer[4];
  letter_8_6=obj.answer[5];
  letter_8_7=obj.answer[6];
  letter_8_8=obj.answer[7];
  CurrentAnswerLetters=[];
   CurrentAnswerLetters.push(letter_8_1,letter_8_2,letter_8_3,letter_8_4,letter_8_5,letter_8_6,letter_8_7,letter_8_8);
   
}


};

//keeps track of current letters for each question, for each category
CurrentLetterCount=[];

//keep record of letters fro each answer
CurrentAnswerLetters=[];

//Categories Information for Game
     
///60'S ROCK BANDS 
 

//Event Listeners for '60s rock band' category and next question buttons

document.querySelector('.nextBox').addEventListener('click', clearOutAllLetters);
document.querySelector('.betters_button').addEventListener('click', clearOutAllLetters);
document.querySelector('.no_more_questions').classList.add('hide_boxes');





 //Instances of Controller for category "60s Rock Band "  
     RockBands60s_1 = new Controller('60\'s Rock Bands','This band had a major hit in 1964, with the song,"The House of The Rising Sun',7,['A','N','I','M','A','L','S'],1,'ANIMALS');
     RockBands60s_2 = new Controller('60\'s Rock Bands','This band "Broke on Through to the other side" with this hit song in 1967',5 ,['D','O','O','R','S'],2,'DOORS');
     RockBands60s_3 = new Controller('60\'s Rock Bands','He had  big hit\'s "Sunshine Superman" and "Season of the Witch", back in 1966',7 ,['D','O','N','O','V','A','N'],3,'DONOVAN');
     RockBands60s_4 = new Controller('60\'s Rock Bands','The last name of the guitar player, who was part of the 60\'s band "The Byrds", who went on to join CSN',6 ,['C','R','O','S','B','Y'],4,'CROSBY');
     RockBands60s_5 = new Controller('60\'s Rock Bands','Last name of the first guitar player with the 60\'s band, "The Yardbirds", who went on to have a very successful solo career',7,['C','L','A','P','T','O','N'],5,'CLAPTON');
     RockBands60s_6 = new Controller('60\'s Rock Bands','Jefferson Airplane had a hit song in 1967, with a song about a "White ? ',6 ,['R','A','B','B','I','T'],6,'RABBIT');
     RockBands60s_7 = new Controller('60\'s Rock Bands','This California band from the 60\'s, got their name from a member of the reptile family ',7 ,['T','U','R','T','L','E','S'],7,'TURTLE');
     RockBands60s_8 = new Controller('60\'s Rock Bands','This hit song from the english rock band, "Deep Purple" told a certain woman to keep quiet',4 ,['H','U','S','H'],8,'HUSH');
     RockBands60s_9 = new Controller('60\'s Rock Bands','Whats the name of the city in Germany, where the Beatles played early in their career?',7 ,['H','A','M','B','U','R','G'],9,'HAMBURG');
     RockBands60s_10 = new Controller('60\'s Rock Bands','This Neil Diamond song from 1968, talked about a woman from what American state ?',8 ,['K','E','N','T','U','C','K','Y'],10,'KENTUCKY');
 
     document.querySelector('.rockband60s').addEventListener('click',testforLastQuestion);
    document.querySelector('.nextBox').addEventListener('click',endCategory);
    document.querySelector('.rockband60s').addEventListener('click',RockBand60sQuestionsTracker);

//Array for '60's rock band' to keep track of questions answered
var rockband60sArr=[];  


//click category and next question buttons for '60s rock band/keep track of questions asked'  

function RockBand60sQuestionsTracker(){
  
  if(!rockband60sArr[0]){
  RockBands60s_1.keepTrackOfQuestions(RockBands60s_1,rockband60sArr,CurrentLetterCount);
  RockBands60s_1.quessAnswer(RockBands60s_1);
  
  
} else if(!rockband60sArr[1]){
  RockBands60s_2.keepTrackOfQuestions(RockBands60s_2,rockband60sArr,CurrentLetterCount);
  RockBands60s_2.quessAnswer(RockBands60s_2);
  

 }else if(!rockband60sArr[2]){
  RockBands60s_3.keepTrackOfQuestions(RockBands60s_3,rockband60sArr,CurrentLetterCount);
  RockBands60s_3.quessAnswer(RockBands60s_3);
 
 }else if(!rockband60sArr[3]){
  RockBands60s_4.keepTrackOfQuestions(RockBands60s_4,rockband60sArr,CurrentLetterCount);
  RockBands60s_4.quessAnswer(RockBands60s_4);

 }else if(!rockband60sArr[4]){
  RockBands60s_5.keepTrackOfQuestions(RockBands60s_5,rockband60sArr,CurrentLetterCount);
  RockBands60s_5.quessAnswer(RockBands60s_5);
 
 }else if(!rockband60sArr[5]){
  RockBands60s_6.keepTrackOfQuestions(RockBands60s_6,rockband60sArr,CurrentLetterCount);
  RockBands60s_6.quessAnswer(RockBands60s_6);
  
 }else if(!rockband60sArr[6]){
  RockBands60s_7.keepTrackOfQuestions(RockBands60s_7,rockband60sArr,CurrentLetterCount);
  RockBands60s_7.quessAnswer(RockBands60s_7);
  
 }else if(!rockband60sArr[7]){
  RockBands60s_8.keepTrackOfQuestions(RockBands60s_8,rockband60sArr,CurrentLetterCount);
  RockBands60s_8.quessAnswer(RockBands60s_8);
  
 }else if(!rockband60sArr[8]){
  RockBands60s_9.keepTrackOfQuestions(RockBands60s_9,rockband60sArr,CurrentLetterCount);
  RockBands60s_9.quessAnswer(RockBands60s_9);
 
  
 }else if(!rockband60sArr[9]){
  RockBands60s_10.keepTrackOfQuestions(RockBands60s_10,rockband60sArr,CurrentLetterCount);
  RockBands60s_10.quessAnswer(RockBands60s_10);
  
  
  }else if(rockband60sArr.length===10){
    hitLastQuestion();
    
    }

}




 //Instances of Controller for category "state capitals "  
 StateCapital_1 = new Controller('State Capitals','This capital of this state, is from a state known for it\'s vast wilderness and eskimo population',6,['J','U','N','E','A','U'],1,'JUNEAU');
 StateCapital_2 = new Controller('State Capitals','This state\'s capital, is from a state ,known for it\'s beautiful beaches and pineapples',8 ,['H','O','N','O','L','U','L','U'],2,'HONOLULU');
 StateCapital_3 = new Controller('State Capitals','The pilgrims landed in this state back in the early 1600\'s. It\'s state capital is ?',6 ,['B','O','S','T','O','N'],3,'BOSTON');
 StateCapital_4 = new Controller('State Capitals','This state\'s largest city, isn\'t it\'s capital, but is known for it\'s gambling',8 ,['L','A','S','V','E','G','A','S'],4,'LASVEGAS');
 StateCapital_5 = new Controller('State Capitals','The old man in the mountain, lives in this state. What is the name of it\'s capital?',7,['C','O','N','C','O','R','D'],5,'CONCORD');
 StateCapital_6 = new Controller('State Capitals','Music is synonomous with this state\'s capital.It is known as one of the largest state\'s in the country',6 ,['A','U','S','T','I','N'],6,'AUSTIN');
 StateCapital_7 = new Controller('State Capitals','This state is known as the "Land of 10,000 lakes", It\'s state capital is ?',7 ,['L','A','N','S','I','N','G'],7,'LANSING');
 StateCapital_8 = new Controller('State Capitals','This state is known for it\'s famous national park and towering mountains. What\'s it\'s state capital?',8 ,['C','H','E','Y','E','N','N','E'],8,'CHEYENNE');
 StateCapital_9 = new Controller('State Capitals','In the 1940\'s, this was the place, where early nuclear testing was done. It\'s state capital is?',7 ,['S','A','N','T','A','F','E'],9,'SANTAFE');
 StateCapital_10 = new Controller('State Capitals','Custer\'s last stand took place in this state in the 1860\'s. It\'s state capital is?',6 ,['H','E','L','E','N','A'],10,'HELENA');

document.querySelector('.statecapitals').addEventListener('click',testforLastQuestion);
document.querySelector('.nextBox').addEventListener('click',endCategory);
document.querySelector('.statecapitals').addEventListener('click',StateCapitalsQuestionsTracker);

//Array for 'state capitals' to keep track of questions answered
var statecapitalsArr=[];  

//click category and next question buttons for 'state capitals/keep track of questions asked'  

function StateCapitalsQuestionsTracker(){

if(!statecapitalsArr[0]){
StateCapital_1.keepTrackOfQuestions(StateCapital_1,statecapitalsArr,CurrentLetterCount);
StateCapital_1.quessAnswer(StateCapital_1);


} else if(!statecapitalsArr[1]){
  StateCapital_2.keepTrackOfQuestions(StateCapital_2,statecapitalsArr,CurrentLetterCount);
  StateCapital_2.quessAnswer(StateCapital_2);


}else if(!statecapitalsArr[2]){
  StateCapital_3.keepTrackOfQuestions(StateCapital_3,statecapitalsArr,CurrentLetterCount);
  StateCapital_3.quessAnswer(StateCapital_3);

}else if(!statecapitalsArr[3]){
  StateCapital_4.keepTrackOfQuestions(StateCapital_4,statecapitalsArr,CurrentLetterCount);
  StateCapital_4.quessAnswer(StateCapital_4);

}else if(!statecapitalsArr[4]){
  StateCapital_5.keepTrackOfQuestions(StateCapital_5,statecapitalsArr,CurrentLetterCount);
  StateCapital_5.quessAnswer(StateCapital_5);

}else if(!statecapitalsArr[5]){
  StateCapital_6.keepTrackOfQuestions(StateCapital_6,statecapitalsArr,CurrentLetterCount);
  StateCapital_6.quessAnswer(StateCapital_6);

}else if(!statecapitalsArr[6]){
  StateCapital_7.keepTrackOfQuestions(StateCapital_7,statecapitalsArr,CurrentLetterCount);
  StateCapital_7.quessAnswer(StateCapital_7);;

}else if(!statecapitalsArr[7]){
  StateCapital_8.keepTrackOfQuestions(StateCapital_8,statecapitalsArr,CurrentLetterCount);
  StateCapital_8.quessAnswer(StateCapital_8);

}else if(!statecapitalsArr[8]){
  StateCapital_9.keepTrackOfQuestions(StateCapital_9,statecapitalsArr,CurrentLetterCount);
  StateCapital_9.quessAnswer(StateCapital_9);
  

}else if(!statecapitalsArr[9]){
  StateCapital_10.keepTrackOfQuestions(StateCapital_10,statecapitalsArr,CurrentLetterCount);
  StateCapital_10.quessAnswer(StateCapital_10);
  
 
}else if(statecapitalsArr.length===10){
  hitLastQuestion();
  
  }
}

 //Instances of Controller for category "world history "  
 WorldHistory_1 = new Controller('World History','Last name of the man who pioneered wireless radio in the early 20th century',7,['M','A','R','C','O','N','I'],1,'MARCONI');
 WorldHistory_2 = new Controller('World History','He brought the idea of "passive resistance", to his struggle to make India independent in the early 20th century',6 ,['G','A','N','D','H','I'],2,'GANDHI');
 WorldHistory_3 = new Controller('World History','Raffaele Esposito is credited with creating, what famous Italian cuisine ?',5 ,['P','I','Z','Z','A'],3,'PIZZA');
 WorldHistory_4 = new Controller('World History','What was the last name of the man, who invented the world\'s first car?',4 ,['B','E','N','Z'],4,'BENZ');
 WorldHistory_5 = new Controller('World History','What is the name of the world\'s largest airline company ?' ,5,['D','E','L','T','A'],5,'DELTA');
 WorldHistory_6 = new Controller('World History','What is the name of the discoverer of A. C. electricity?',5 ,['T','E','S','L','A'],6,'TESLA');
 WorldHistory_7 = new Controller('World History','He was one of the most famous Union General\'s from the Civil War.',7 ,['S','H','E','R','M','A','N'],7,'SHERMAN');
 WorldHistory_8 = new Controller('World History','He was the 33rd president of the United States',6 ,['T','R','U','M','A','N'],8,'TRUMAN');
 WorldHistory_9 = new Controller('World History','This is known as the last battle of World War 2. Where did it take place?',6 ,['B','E','R','L','I','N'],9,'BERLIN');
 WorldHistory_10 = new Controller('World History','Who was president of the United States, whne the Vietnam War ended?',4 ,['F','O','R','D'],10,'FORD');

document.querySelector('.worldhistory').addEventListener('click',testforLastQuestion);
document.querySelector('.nextBox').addEventListener('click',endCategory);
document.querySelector('.worldhistory').addEventListener('click',WorldHistoryQuestionsTracker);

//Array for 'state capitals' to keep track of questions answered
var worldhistoryArr=[];  

//click category and next question buttons for 'state capitals/keep track of questions asked'  

function WorldHistoryQuestionsTracker(){

if(!worldhistoryArr[0]){
WorldHistory_1.keepTrackOfQuestions(WorldHistory_1,worldhistoryArr,CurrentLetterCount);
WorldHistory_1.quessAnswer(WorldHistory_1);


} else if(!worldhistoryArr[1]){
  WorldHistory_2.keepTrackOfQuestions(WorldHistory_2,worldhistoryArr,CurrentLetterCount);
  WorldHistory_2.quessAnswer(WorldHistory_2);


}else if(!worldhistoryArr[2]){
  WorldHistory_3.keepTrackOfQuestions(WorldHistory_3,worldhistoryArr,CurrentLetterCount);
  WorldHistory_3.quessAnswer(WorldHistory_3);

}else if(!worldhistoryArr[3]){
  WorldHistory_4.keepTrackOfQuestions(WorldHistory_4,worldhistoryArr,CurrentLetterCount);
  WorldHistory_4.quessAnswer(WorldHistory_4);

}else if(!worldhistoryArr[4]){
  WorldHistory_5.keepTrackOfQuestions(WorldHistory_5,worldhistoryArr,CurrentLetterCount);
  WorldHistory_5.quessAnswer(WorldHistory_5);

}else if(!worldhistoryArr[5]){
  WorldHistory_6.keepTrackOfQuestions(WorldHistory_6,worldhistoryArr,CurrentLetterCount);
  WorldHistory_6.quessAnswer(WorldHistory_6);

}else if(!worldhistoryArr[6]){
  WorldHistory_7.keepTrackOfQuestions(WorldHistory_7,worldhistoryArr,CurrentLetterCount);
  WorldHistory_7.quessAnswer(WorldHistory_7);;

}else if(!worldhistoryArr[7]){
  WorldHistory_8.keepTrackOfQuestions(WorldHistory_8,worldhistoryArr,CurrentLetterCount);
  WorldHistory_8.quessAnswer(WorldHistory_8);

}else if(!worldhistoryArr[8]){
  WorldHistory_9.keepTrackOfQuestions(WorldHistory_9,worldhistoryArr,CurrentLetterCount);
  WorldHistory_9.quessAnswer(WorldHistory_9);
  

}else if(!worldhistoryArr[9]){
  WorldHistory_10.keepTrackOfQuestions(WorldHistory_10,worldhistoryArr,CurrentLetterCount);
  WorldHistory_10.quessAnswer(WorldHistory_10);
  
 
}else if(worldhistoryArr.length===10){
  hitLastQuestion();
  
}
}


//american sports
 //Instances of Controller for category "american sports"  
 AmericanSports_1 = new Controller('American Sports','What is the name of the number 1 sport in America today ?',8,['F','O','O','T','B','A','L','L'],1,'FOOTBALL');
 AmericanSports_2 = new Controller('American Sports','The last name of the first father-son duo, to hit back-to-back homers in an MLB game?',7 ,['G','R','I','F','F','E','Y'],2,'GRIFFEY');
 AmericanSports_3 = new Controller('American Sports','What college team, did Michael Jordan originally want to play for?',4 ,['U','C','L','A'],3,'UCLA');
 AmericanSports_4 = new Controller('American Sports','What was the last name of the first president, to throw out a ceremonial pitch at a baseball game?',4 ,['T','A','F','T'],4,'TAFT');
 AmericanSports_5 = new Controller('American Sports','What is the first name, of the only athlete, to play in both a world series and a super bowl' ,5,['D','E','I','O','N'],5,'DEION');
 AmericanSports_6 = new Controller('American Sports','Last name of the baseball player, nicknamed the,"The Iron Bird"',6 ,['R','I','P','K','E','N'],6,'RIPKEN');
 AmericanSports_7 = new Controller('American Sports','First name of the boxer, who was a 42-1 underdog, when he K.O\'d Mike Tyson ?',6 ,['B','U','S','T','E','R'],6,'BUSTER');
 AmericanSports_8 = new Controller('American Sports','Last name of the Lakers coach who trademarked the term "three-peat"',5 ,['R','I','L','E','Y'],8,'RILEY');
 AmericanSports_9 = new Controller('American Sports','The only known human mascot in any of the 4 major pro sports, is a ?',6 ,['V','I','K','I','N','G'],9,'VIKING');
 AmericanSports_10 = new Controller('American Sports','Last name of the golfer, that led the PGA Tour in driving distance, for eight years during the 1990s?',4 ,['D','A','L','Y'],10,'DALY');

document.querySelector('.americansports').addEventListener('click',testforLastQuestion);
document.querySelector('.nextBox').addEventListener('click',endCategory);
document.querySelector('.americansports').addEventListener('click',AmericanSportsQuestionsTracker);

//Array for 'state capitals' to keep track of questions answered
var americansportsArr=[];  

//click category and next question buttons for 'state capitals/keep track of questions asked'  

function AmericanSportsQuestionsTracker(){

if(!americansportsArr[0]){
  AmericanSports_1.keepTrackOfQuestions(AmericanSports_1,americansportsArr,CurrentLetterCount);
  AmericanSports_1.quessAnswer(AmericanSports_1);


} else if(!americansportsArr[1]){
  AmericanSports_2.keepTrackOfQuestions(AmericanSports_2,americansportsArr,CurrentLetterCount);
  AmericanSports_2.quessAnswer(AmericanSports_2);


}else if(!americansportsArr[2]){
  AmericanSports_3.keepTrackOfQuestions(AmericanSports_3,americansportsArr,CurrentLetterCount);
  AmericanSports_3.quessAnswer(AmericanSports_3);

}else if(!americansportsArr[3]){
  AmericanSports_4.keepTrackOfQuestions(AmericanSports_4,americansportsArr,CurrentLetterCount);
  AmericanSports_4.quessAnswer(AmericanSports_4);

}else if(!americansportsArr[4]){
  AmericanSports_5.keepTrackOfQuestions(AmericanSports_5,americansportsArr,CurrentLetterCount);
  AmericanSports_5.quessAnswer(AmericanSports_5);

}else if(!americansportsArr[5]){
  AmericanSports_6.keepTrackOfQuestions(AmericanSports_6,americansportsArr,CurrentLetterCount);
  AmericanSports_6.quessAnswer(AmericanSports_6);

}else if(!americansportsArr[6]){
  AmericanSports_7.keepTrackOfQuestions(AmericanSports_7,americansportsArr,CurrentLetterCount);
  AmericanSports_7.quessAnswer(AmericanSports_7);;

}else if(!americansportsArr[7]){
  AmericanSports_8.keepTrackOfQuestions(AmericanSports_8,americansportsArr,CurrentLetterCount);
  AmericanSports_8.quessAnswer(AmericanSports_8);

}else if(!americansportsArr[8]){
  AmericanSports_9.keepTrackOfQuestions(AmericanSports_9,americansportsArr,CurrentLetterCount);
  AmericanSports_9.quessAnswer(AmericanSports_9);
  

}else if(!americansportsArr[9]){
  AmericanSports_10.keepTrackOfQuestions(AmericanSports_10,americansportsArr,CurrentLetterCount);
  AmericanSports_10.quessAnswer(AmericanSports_10);
  
 
}else if(americansportsArr.length===10){
  hitLastQuestion();
  
}
}


//famous aauthors
 //Instances of Controller for category "famous authors"  
 FamousAuthors_1 = new Controller('Famous Authors','He wrote the famous book,"The art of war", sometime before 496 b.c.?',6,['S','U','N','T','Z','U'],1,'SUNTZU');
 FamousAuthors_2 = new Controller('Famous Authors','The last name of the author responsible for the masterpiece, "A Tale of Two Cities" written back in the 19th century',7 ,['D','I','C','K','E','N','S'],2,'DICKENS');
 FamousAuthors_3 = new Controller('Famous Authors','He wrote the book, "The Call of the Wild" about a boy lost in the willderness, with a team of sleddogs',6 ,['L','O','N','D','O','N'],3,'LONDON');
 FamousAuthors_4 = new Controller('Famous Authors','The world took a never-ending trip with this author, into his fantasy world of "Hobbits" and "Middle Earth"',7 ,['T','O','L','K','I','E','N'],4,'TOLKIEN');
 FamousAuthors_5 = new Controller('Famous Authors','Last name of this female author, who wrote 65 detective novels during the 20th century' ,8,['C','H','R','I','S','T','I','E'],5,'CHRISTIE');
 FamousAuthors_6 = new Controller('Famous Authors','He introduced the world to "The Cat in the Hat" and "Green Eggs and Ham" and created his own illustrations',5 ,['S','E','U','S','S'],6,'SEUSS');
 FamousAuthors_7 = new Controller('Famous Authors','Outer space was this author\'s fortay, for the majority of his novels, having written close to 500 stories',6 ,['A','S','I','M','O','V'],6,'ASIMOV');
 FamousAuthors_8 = new Controller('Famous Authors','This author spent alot of time, "On the Road", being part of the beatnik and hippie culture of the 1950\'s and 60\'s' ,7 ,['K','E','R','O','U','A','C'],8,'KEROUAC');
 FamousAuthors_9 = new Controller('Famous Authors','He is the absolute master of horror, having close to 50 novels published and a host of movies made from them ',4 ,['K','I','N','G'],9,'KING');
 FamousAuthors_10 = new Controller('Famous Authors','Each of this world-famous author\'s book were made into a movie about a boy-magician, named "Harry Potter"',7 ,['R','O','W','L','I','N','G'],10,'ROWLING');

document.querySelector('.famousauthors').addEventListener('click',testforLastQuestion);
document.querySelector('.nextBox').addEventListener('click',endCategory);
document.querySelector('.famousauthors').addEventListener('click',FamousAuthorsQuestionsTracker);

//Array for 'famous authors' to keep track of questions answered
var famousauthorsArr=[];  

//click category and next question buttons for 'famous authors/keep track of questions asked'  

function FamousAuthorsQuestionsTracker(){

if(!famousauthorsArr[0]){
  FamousAuthors_1.keepTrackOfQuestions(FamousAuthors_1,famousauthorsArr,CurrentLetterCount);
  FamousAuthors_1.quessAnswer(FamousAuthors_1);

} else if(!famousauthorsArr[1]){
  FamousAuthors_2.keepTrackOfQuestions(FamousAuthors_2,famousauthorsArr,CurrentLetterCount);
  FamousAuthors_2.quessAnswer(FamousAuthors_2);

}else if(!famousauthorsArr[2]){
  FamousAuthors_3.keepTrackOfQuestions(FamousAuthors_3,famousauthorsArr,CurrentLetterCount);
  FamousAuthors_3.quessAnswer(FamousAuthors_3);

}else if(!famousauthorsArr[3]){
  FamousAuthors_4.keepTrackOfQuestions(FamousAuthors_4,famousauthorsArr,CurrentLetterCount);
  FamousAuthors_4.quessAnswer(FamousAuthors_4);

}else if(!famousauthorsArr[4]){
  FamousAuthors_5.keepTrackOfQuestions(FamousAuthors_5,famousauthorsArr,CurrentLetterCount);
  FamousAuthors_5.quessAnswer(FamousAuthors_5);

}else if(!famousauthorsArr[5]){
  FamousAuthors_6.keepTrackOfQuestions(FamousAuthors_6,famousauthorsArr,CurrentLetterCount);
  FamousAuthors_6.quessAnswer(FamousAuthors_6);

}else if(!famousauthorsArr[6]){
  FamousAuthors_7.keepTrackOfQuestions(FamousAuthors_7,famousauthorsArr,CurrentLetterCount);
  FamousAuthors_7.quessAnswer(FamousAuthors_7);;

}else if(!famousauthorsArr[7]){
  FamousAuthors_8.keepTrackOfQuestions(FamousAuthors_8,famousauthorsArr,CurrentLetterCount);
  FamousAuthors_8.quessAnswer(FamousAuthors_8);

}else if(!famousauthorsArr[8]){
  FamousAuthors_9.keepTrackOfQuestions(FamousAuthors_9,famousauthorsArr,CurrentLetterCount);
  FamousAuthors_9.quessAnswer(FamousAuthors_9);
  

}else if(!famousauthorsArr[9]){
  FamousAuthors_10.keepTrackOfQuestions(FamousAuthors_10,famousauthorsArr,CurrentLetterCount);
  FamousAuthors_10.quessAnswer(FamousAuthors_10);
  
 
}else if(famousauthorsArr.length===10){
  hitLastQuestion();
  
}
}


//vacation spots
 //Instances of Controller for category "vacation spots"  
 VacationSpots_1 = new Controller('Vacation Spots','What is the number one vacation spot/state in the United States ?',6,['H','A','W','A','I','I'],1,'HAWAII');
 VacationSpots_2 = new Controller('Vacation Spots','This  Indonesian tropical island retreat is nicknamed,"The Island of the Gods"',4 ,['B','A','L','I'],2,'BALI');
 VacationSpots_3 = new Controller('Vacation Spots','This island paradise is isolated from much of the world, in the middle of the pacific ocean',8 ,['B','O','R','A','B','O','R','A'],3,'BORABORA');
 VacationSpots_4 = new Controller('Vacation Spots','ThIS southern state in the United States, has one of the most popular cities, that families love to vacation in',7 ,['O','R','L','A','N','D','O'],4,'ORLANDO');
 VacationSpots_5 = new Controller('Vacation Spots','This New England state, has one of the most popular cities to view the fall foilage in' ,7,['B','R','I','S','T','O','L'],5,'BRISTOL');
 VacationSpots_6 = new Controller('Vacation Spots','This California city, offers a great, budget friendly vacation spot for families to visit',8 ,['Y','O','S','E','M','I','T','E'],6,'YOSEMITE');
 VacationSpots_7 = new Controller('Vacation Spots','This tropical island retreat, offers one of the best budget vacation destination for 2 people',6 ,['C','A','Y','M','A','N'],6,'CAYMAN');
 VacationSpots_8 = new Controller('Vacation Spots','The number one country to visit in 2020 is ?' ,6 ,['B','H','U','T','A','N'],8,'BHUTAN');
 VacationSpots_9 = new Controller('Vacation Spots','The number one city in the United States that people from all over the world, want to visit',7 ,['N','E','W','Y','O','R','K'],9,'NEWYORK');
 VacationSpots_10 = new Controller('Vacation Spots','The number one destination on people\'s bucket lists, of places they want to visit is?',4 ,['B','A','L','I'],10,'BALI');

document.querySelector('.vacationspots').addEventListener('click',testforLastQuestion);
document.querySelector('.nextBox').addEventListener('click',endCategory);
document.querySelector('.vacationspots').addEventListener('click',VacationSpotsQuestionsTracker);

//Array for 'vacation spots' to keep track of questions answered
var vacationspotsArr=[];  

//click category and next question buttons for 'vacation spots/keep track of questions asked'  

function VacationSpotsQuestionsTracker(){

if(!vacationspotsArr[0]){
  VacationSpots_1.keepTrackOfQuestions(VacationSpots_1,vacationspotsArr,CurrentLetterCount);
  VacationSpots_1.quessAnswer(VacationSpots_1);

} else if(!vacationspotsArr[1]){
  VacationSpots_2.keepTrackOfQuestions(VacationSpots_2,vacationspotsArr,CurrentLetterCount);
  VacationSpots_2.quessAnswer(VacationSpots_2);

}else if(!vacationspotsArr[2]){
  VacationSpots_3.keepTrackOfQuestions(VacationSpots_3,vacationspotsArr,CurrentLetterCount);
  VacationSpots_3.quessAnswer(VacationSpots_3);

}else if(!vacationspotsArr[3]){
  VacationSpots_4.keepTrackOfQuestions(VacationSpots_4,vacationspotsArr,CurrentLetterCount);
  VacationSpots_4.quessAnswer(VacationSpots_4);

}else if(!vacationspotsArr[4]){
  VacationSpots_5.keepTrackOfQuestions(VacationSpots_5,vacationspotsArr,CurrentLetterCount);
  VacationSpots_5.quessAnswer(VacationSpots_5);

}else if(!vacationspotsArr[5]){
  VacationSpots_6.keepTrackOfQuestions(VacationSpots_6,vacationspotsArr,CurrentLetterCount);
  VacationSpots_6.quessAnswer(VacationSpots_6);

}else if(!vacationspotsArr[6]){
  VacationSpots_7.keepTrackOfQuestions(VacationSpots_7,vacationspotsArr,CurrentLetterCount);
  VacationSpots_7.quessAnswer(VacationSpots_7);;

}else if(!vacationspotsArr[7]){
  VacationSpots_8.keepTrackOfQuestions(VacationSpots_8,vacationspotsArr,CurrentLetterCount);
  VacationSpots_8.quessAnswer(VacationSpots_8);

}else if(!vacationspotsArr[8]){
  VacationSpots_9.keepTrackOfQuestions(VacationSpots_9,vacationspotsArr,CurrentLetterCount);
  VacationSpots_9.quessAnswer(VacationSpots_9);
  

}else if(!vacationspotsArr[9]){
  VacationSpots_10.keepTrackOfQuestions(VacationSpots_10,vacationspotsArr,CurrentLetterCount);
  VacationSpots_10.quessAnswer(VacationSpots_10);
  
 
}else if(vacationspotsArr.length===10){
  hitLastQuestion();
  
}
}

//one hit wonders
 //Instances of Controller for category "one hit wonders"  
 OneHitWonders_1 = new Controller('One Hit Wonders','English artist Gary Neuman, had his one big hit in the 1980\'S, with this song about ?',4,['C','A','R','S'],1,'CARS');
 OneHitWonders_2 = new Controller('One Hit Wonders','The song "Tainted Love" was the one big hit for what alternative 80\'s band?',8 ,['S','O','F','T','C','E','L','L'],2,'SOFTCELL');
 OneHitWonders_3 = new Controller('One Hit Wonders','What is the last name of the recording artist, who had his one big hit, with the song,"Electric Avenue"?',5 ,['G','R','A','N','T'],3,'GRANT');
 OneHitWonders_4 = new Controller('One Hit Wonders','ThIS 80\'s band were,"Turning Japanese", with their one big hit of the same name in the 1980\'s',6 ,['V','A','P','O','R','S'],4,'VAPORS');
 OneHitWonders_5 = new Controller('One Hit Wonders','She had her big, one hit in the 1980\'s, with the song,"Two of Hearts"' ,7,['S','T','A','C','E','Y','Q'],5,'STACEYQ');
 OneHitWonders_6 = new Controller('One Hit Wonders','iN 1963, the band,"The Surfaris", had a huge hit with this song ',7 ,['W','I','P','E','O','U','T'],6,'YWIPEOUT');
 OneHitWonders_7 = new Controller('One Hit Wonders','The band,"Looking Glass" had a big hit in 1972, with this song about a girl named ?',6 ,['B','R','A','N','D','Y'],6,'BRANDY');
 OneHitWonders_8 = new Controller('One Hit Wonders','The band,"Pilot", had their one and only big hit in 1974. Whhat was that song?' ,5 ,['M','A','G','I','C'],8,'MAGIC');
 OneHitWonders_9 = new Controller('One Hit Wonders','The song,"My Shaorna" was the one and only hit for the band,"The',5 ,['K','N','A','C','K'],9,'KNACK');
 OneHitWonders_10 = new Controller('One Hit Wonders','In 1983 the song,"99 Luftballons", was the one and only hit for this band',4 ,['N','E','N','A'],10,'NENA');

document.querySelector('.onehitwonders').addEventListener('click',testforLastQuestion);
document.querySelector('.nextBox').addEventListener('click',endCategory);
document.querySelector('.onehitwonders').addEventListener('click',OneHitWondersQuestionsTracker);

//Array for 'vacation spots' to keep track of questions answered
var onehitwondersArr=[];  

//click category and next question buttons for 'vacation spots/keep track of questions asked'  

function OneHitWondersQuestionsTracker(){

if(!onehitwondersArr[0]){
  OneHitWonders_1.keepTrackOfQuestions(OneHitWonders_1,onehitwondersArr,CurrentLetterCount);
  OneHitWonders_1.quessAnswer(OneHitWonders_1);

} else if(!onehitwondersArr[1]){
  OneHitWonders_2.keepTrackOfQuestions(OneHitWonders_2,onehitwondersArr,CurrentLetterCount);
  OneHitWonders_2.quessAnswer(OneHitWonders_2);

}else if(!onehitwondersArr[2]){
  OneHitWonders_3.keepTrackOfQuestions(OneHitWonders_3,onehitwondersArr,CurrentLetterCount);
  OneHitWonders_3.quessAnswer(OneHitWonders_3);

}else if(!onehitwondersArr[3]){
  OneHitWonders_4.keepTrackOfQuestions(OneHitWonders_4,onehitwondersArr,CurrentLetterCount);
  OneHitWonders_4.quessAnswer(OneHitWonders_4);

}else if(!onehitwondersArr[4]){
  OneHitWonders_5.keepTrackOfQuestions(OneHitWonders_5,onehitwondersArr,CurrentLetterCount);
  OneHitWonders_5.quessAnswer(OneHitWonders_5);

}else if(!onehitwondersArr[5]){
  OneHitWonders_6.keepTrackOfQuestions(OneHitWonders_6,onehitwondersArr,CurrentLetterCount);
  OneHitWonders_6.quessAnswer(OneHitWonders_6);

}else if(!onehitwondersArr[6]){
  OneHitWonders_7.keepTrackOfQuestions(OneHitWonders_7,onehitwondersArr,CurrentLetterCount);
  OneHitWonders_7.quessAnswer(OneHitWonders_7);;

}else if(!onehitwondersArr[7]){
  OneHitWonders_8.keepTrackOfQuestions(OneHitWonders_8,onehitwondersArr,CurrentLetterCount);
  OneHitWonders_8.quessAnswer(OneHitWonders_8);

}else if(!onehitwondersArr[8]){
  OneHitWonders_9.keepTrackOfQuestions(OneHitWonders_9,onehitwondersArr,CurrentLetterCount);
  OneHitWonders_9.quessAnswer(OneHitWonders_9);
  

}else if(!onehitwondersArr[9]){
  OneHitWonders_10.keepTrackOfQuestions(OneHitWonders_10,onehitwondersArr,CurrentLetterCount);
  OneHitWonders_10.quessAnswer(OneHitWonders_10);
  
 
}else if(onehitwondersArr.length===10){
  hitLastQuestion();
  
}
}

//famous places
 //Instances of Controller for category "famous places"  
 FamousPlaces_1 = new Controller('Famous Places','This clock tower in London is famous the world over, Known as ?',6,['B','I','G','B','E','N'],1,'BIGBEN');
 FamousPlaces_2 = new Controller('Famous Places','Sydney, Australia has one of the world\'s most recognizable buildings.What takes place there? ',5 ,['O','P','E','R','A'],2,'OPERA');
 FamousPlaces_3 = new Controller('Famous Places','This tower in France, is known as the ___ tower?.The entire world knows this landmark',6 ,['E','I','F','F','E','L'],3,'EIFFEL');
 FamousPlaces_4 = new Controller('Famous Places','This is one of the most recognizable buildings from India, known around the world as the ?',8 ,['T','A','J','M','A','H','A','L'],4,'TAJMAHAL');
 FamousPlaces_5 = new Controller('Famous Places','South Dakota has this famous mountain, with the faces of U.S. presidents carved into it' ,8,['R','U','S','H','M','O','R','E'],5,'RUSHMORE');
 FamousPlaces_6 = new Controller('Famous Places','This island off the coast of Chile, is famous for all the stone carvings, sprawled across it\'s terrain ',6 ,['E','A','S','T','E','R'],6,'EASTER');
 FamousPlaces_7 = new Controller('Famous Places','In Italy, there is a famous tower, which is leaning at an angle. Where is it located?',4 ,['P','I','Z','A'],6,'PIZA');
 FamousPlaces_8 = new Controller('Famous Places','In Egypt there is a great pyramid, located in Cairo. What is it\'s name?' ,4 ,['G','I','Z','A'],8,'GIZA');
 FamousPlaces_9 = new Controller('Famous Places','In Moscow, Russia, it is prehaps the most famous building in the entire country',7 ,['K','R','E','M','L','I','N'],9,'KREMLIN');
 FamousPlaces_10 = new Controller('Famous Places','This cathedral in Moscow, Russia is known around the world for it\'s stunning architecture',7 ,['S','T','B','A','S','I','L'],10,'STBASIL');

document.querySelector('.famousplaces').addEventListener('click',testforLastQuestion);
document.querySelector('.nextBox').addEventListener('click',endCategory);
document.querySelector('.famousplaces').addEventListener('click',FamousPlacesQuestionsTracker);

//Array for 'vacation spots' to keep track of questions answered
var famousplacesArr=[];  

//click category and next question buttons for 'vacation spots/keep track of questions asked'  

function FamousPlacesQuestionsTracker(){

if(!famousplacesArr[0]){
  FamousPlaces_1.keepTrackOfQuestions(FamousPlaces_1,famousplacesArr,CurrentLetterCount);
  FamousPlaces_1.quessAnswer(FamousPlaces_1);

} else if(!famousplacesArr[1]){
  FamousPlaces_2.keepTrackOfQuestions(FamousPlaces_2,famousplacesArr,CurrentLetterCount);
  FamousPlaces_2.quessAnswer(FamousPlaces_2);

}else if(!famousplacesArr[2]){
  FamousPlaces_3.keepTrackOfQuestions(FamousPlaces_3,famousplacesArr,CurrentLetterCount);
  FamousPlaces_3.quessAnswer(FamousPlaces_3);

}else if(!famousplacesArr[3]){
  FamousPlaces_4.keepTrackOfQuestions(FamousPlaces_4,famousplacesArr,CurrentLetterCount);
  FamousPlaces_4.quessAnswer(FamousPlaces_4);

}else if(!famousplacesArr[4]){
  FamousPlaces_5.keepTrackOfQuestions(FamousPlaces_5,famousplacesArr,CurrentLetterCount);
  FamousPlaces_5.quessAnswer(FamousPlaces_5);

}else if(!famousplacesArr[5]){
  FamousPlaces_6.keepTrackOfQuestions(FamousPlaces_6,famousplacesArr,CurrentLetterCount);
  FamousPlaces_6.quessAnswer(FamousPlaces_6);

}else if(!famousplacesArr[6]){
  FamousPlaces_7.keepTrackOfQuestions(FamousPlaces_7,famousplacesArr,CurrentLetterCount);
  FamousPlaces_7.quessAnswer(FamousPlaces_7);;

}else if(!famousplacesArr[7]){
  FamousPlaces_8.keepTrackOfQuestions(FamousPlaces_8,famousplacesArr,CurrentLetterCount);
  FamousPlaces_8.quessAnswer(FamousPlaces_8);

}else if(!famousplacesArr[8]){
  FamousPlaces_9.keepTrackOfQuestions(FamousPlaces_9,famousplacesArr,CurrentLetterCount);
  FamousPlaces_9.quessAnswer(FamousPlaces_9);
  

}else if(!famousplacesArr[9]){
  FamousPlaces_10.keepTrackOfQuestions(FamousPlaces_10,famousplacesArr,CurrentLetterCount);
  FamousPlaces_10.quessAnswer(FamousPlaces_10);
  
 
}else if(famousplacesArr.length===10){
  hitLastQuestion();
  
}
}

//fast food
 //Instances of Controller for category "fast food"  
 FastFood_1 = new Controller('Fast Food','What is the number one, most popular menu item of any of the fast food resturaunts today',7,['W','H','O','P','P','E','R'],1,'WHOPPER');
 FastFood_2 = new Controller('Fast Food','What is an alternative name for a submarine sandwhich ? ',6 ,['H','O','A','G','I','E'],2,'HOAGIE');
 FastFood_3 = new Controller('Fast Food','The first fAST food resturaunt was opened in 1921. It is still around today and it is called "White ?',6 ,['C','A','S','T','L','E'],3,'CASTLE');
 FastFood_4 = new Controller('Fast Food','Kentucky Fried Chicken was started by Col. Sanders. What was his first name?',7,['H','A','R','L','A','N','D'],4,'HARLAND');
 FastFood_5 = new Controller('Fast Food','What is the most popular menu item, on Mcdonald\'s resturaunt menu?' ,5,['F','R','I','E','S'],5,'FRIES');
 FastFood_6 = new Controller('Fast Food','What is Starbuck\'s most popular coffee item, on it\'s menu? ',5 ,['L','A','T','T','E'],6,'LATTE');
 FastFood_7 = new Controller('Fast Food','Which fast food resturaunt has the largest amount of locations?',6 ,['S','U','B','W','A','Y'],6,'SUBWAY');
 FastFood_8 = new Controller('Fast Food','This mexican restaurant chain is ranked #25, as being one of the best fast food chains in America' ,5 ,['Q','D','O','B','A'],8,'QDOBA');
 FastFood_9 = new Controller('Fast Food','This fast food chain was started by a man and his 4 sons and has been giving, McDonald\'s a run for it\'s money',8 ,['F','I','V','E','G','U','Y','S'],9,'FIVEGUYS');
 FastFood_10 = new Controller('Fast Food','What fast food chain was voted the least popular by consumers in America',8 ,['T','A','C','O','B','E','L','L'],10,'TACOBELL');

document.querySelector('.fastfood').addEventListener('click',testforLastQuestion);
document.querySelector('.nextBox').addEventListener('click',endCategory);
document.querySelector('.fastfood').addEventListener('click',FastFoodQuestionsTracker);

//Array for 'vacation spots' to keep track of questions answered
var fastfoodArr=[];  

//click category and next question buttons for 'vacation spots/keep track of questions asked'  

function FastFoodQuestionsTracker(){

if(!fastfoodArr[0]){
  FastFood_1.keepTrackOfQuestions(FastFood_1,fastfoodArr,CurrentLetterCount);
  FastFood_1.quessAnswer(FastFood_1);

} else if(!fastfoodArr[1]){
  FastFood_2.keepTrackOfQuestions(FastFood_2,fastfoodArr,CurrentLetterCount);
  FastFood_2.quessAnswer(FastFood_2);

}else if(!fastfoodArr[2]){
  FastFood_3.keepTrackOfQuestions(FastFood_3,fastfoodArr,CurrentLetterCount);
  FastFood_3.quessAnswer(FastFood_3);

}else if(!fastfoodArr[3]){
  FastFood_4.keepTrackOfQuestions(FastFood_4,fastfoodArr,CurrentLetterCount);
  FastFood_4.quessAnswer(FastFood_4);

}else if(!fastfoodArr[4]){
  FastFood_5.keepTrackOfQuestions(FastFood_5,fastfoodArr,CurrentLetterCount);
  FastFood_5.quessAnswer(FastFood_5);

}else if(!fastfoodArr[5]){
  FastFood_6.keepTrackOfQuestions(FastFood_6,fastfoodArr,CurrentLetterCount);
  FastFood_6.quessAnswer(FastFood_6);

}else if(!fastfoodArr[6]){
  FastFood_7.keepTrackOfQuestions(FastFood_7,fastfoodArr,CurrentLetterCount);
  FastFood_7.quessAnswer(FastFood_7);;

}else if(!fastfoodArr[7]){
  FastFood_8.keepTrackOfQuestions(FastFood_8,fastfoodArr,CurrentLetterCount);
  FastFood_8.quessAnswer(FastFood_8);

}else if(!fastfoodArr[8]){
  FastFood_9.keepTrackOfQuestions(FastFood_9,fastfoodArr,CurrentLetterCount);
  FastFood_9.quessAnswer(FastFood_9);
  

}else if(!fastfoodArr[9]){
  FastFood_10.keepTrackOfQuestions(FastFood_10,fastfoodArr,CurrentLetterCount);
  FastFood_10.quessAnswer(FastFood_10);
  
 
}else if(fastfoodArr.length===10){
  hitLastQuestion();
  
}
}



///end of game categories




//beginning of tracking amount of questions to end category in play

 function testforLastQuestion(){
  $(".question_box ").show();
  $(".players_box ").show();
  $(".logo_holder ").show();
  $(".rules_back_button ").hide();
  $(".logo_holder_1 ").hide();
  $(".time_control ").show();
  $(".categories_box").hide();
  $(".middle_paragraph").hide();
  $(".start_button").hide();
  $(".place_bet_box ").show();
  $(".cover ").show();
  $(".question_gone").show();
  $(".nextBox").show();
  $(".no_more_questions").hide();
 
  
 }

function hitLastQuestion(){
 if(statecapitalsArr.length===10&&category_chosen==='State Capitals'){
  
  $(".place_bet_box ").hide();
  $(".cover ").hide();
  $(".no_more_questions").show();
  $(".question_gone").hide();
  $(".time_control ").hide();


 }else if(rockband60sArr.length===10&&category_chosen==='60\'s Rock Bands'){
 
  $(".place_bet_box ").hide();
  $(".cover ").hide();
  $(".no_more_questions").show();
  $(".question_gone").hide();
  $(".time_control ").hide();


   }else if(worldhistoryArr.length===10&&category_chosen==='World History'){
   
    $(".place_bet_box ").hide();
    $(".cover ").hide();
    $(".no_more_questions").show();
    $(".question_gone").hide();
    $(".time_control ").hide();
  
  
    }else if(americansportsArr.length===10&&category_chosen==='American Sports'){
     
      $(".place_bet_box ").hide();
      $(".cover ").hide();
      $(".no_more_questions").show();
      $(".question_gone").hide();
      $(".time_control ").hide();
    
    
       }else if(famousauthorsArr.length===10&&category_chosen==='Famous Authors'){
        
        $(".place_bet_box ").hide();
        $(".cover ").hide();
        $(".no_more_questions").show();
        $(".question_gone").hide();
        $(".time_control ").hide();
      
      
     }else if(vacationspotsArr.length===10&&category_chosen==='Vacation Spots'){
         
          $(".place_bet_box ").hide();
          $(".cover ").hide();
          $(".no_more_questions").show();
          $(".question_gone").hide();
          $(".time_control ").hide();
        
        
       }else if(onehitwondersArr.length===10&&category_chosen==='One Hit Wonders'){
        
        $(".place_bet_box ").hide();
        $(".cover ").hide();
        $(".no_more_questions").show();
        $(".question_gone").hide();
        $(".time_control ").hide();
      
      
     }else if(famousplacesArr.length===10&&category_chosen==='Famous Places'){
      
      $(".place_bet_box ").hide();
      $(".cover ").hide();
      $(".no_more_questions").show();
      $(".question_gone").hide();
      $(".time_control ").hide();
    
    
   }else if(fastfoodArr.length===10&&category_chosen==='Fast Food'){
    
    $(".place_bet_box ").hide();
    $(".cover ").hide();
    $(".no_more_questions").show();
    $(".question_gone").hide();
    $(".time_control ").hide();
  
  
 }
    
    
  }
  


function endCategory(){
 if(statecapitalsArr.length===9){
  $(".nextBox ").hide();
  
  document.querySelector('.returnBox').classList.add('category_return_boost');


 }else if(rockband60sArr.length===9){
  $(".nextBox ").hide();
  
  document.querySelector('.returnBox').classList.add('category_return_boost');


 }else if(worldhistoryArr.length===9){
    $(".nextBox ").hide();
    
    document.querySelector('.returnBox').classList.add('category_return_boost');
  
  
  }else if(americansportsArr.length===9){
      $(".nextBox ").hide();
      
   document.querySelector('.returnBox').classList.add('category_return_boost');
    
    
   }else if(famousauthorsArr.length===9){
    $(".nextBox ").hide();
    
 document.querySelector('.returnBox').classList.add('category_return_boost');
  
  
 }else if(vacationspotsArr.length===9){
  $(".nextBox ").hide();
  
document.querySelector('.returnBox').classList.add('category_return_boost');


}else if(onehitwondersArr.length===9){
  $(".nextBox ").hide();
  
document.querySelector('.returnBox').classList.add('category_return_boost');


}else if(famousplacesArr.length===9){
  $(".nextBox ").hide();
  
document.querySelector('.returnBox').classList.add('category_return_boost');


}else if(fastfoodArr.length===9){
  $(".nextBox ").hide();
  
document.querySelector('.returnBox').classList.add('category_return_boost');


}
 
 

 }
  
  
//end of tracking amount of questions to end category in play









     


score=document.querySelector('.score_card_1').innerHTML=100;
main_score=score;

percentage=0;
total_percent=percentage;

letter_total=0;
letter_count=letter_total;



 
  //Get value from input for letters/word answers in letter boxes
  
  function getValueInput(){
    
     letter_input=document.querySelector('.type_answer').value.toUpperCase();
    
    
    var n= letter_input.length;
    
    
       charac_1=letter_input.charAt(0);
       charac_2=letter_input.charAt(1);
       charac_3=letter_input.charAt(2);
       charac_4=letter_input.charAt(3);
       charac_5=letter_input.charAt(4);
       charac_6=letter_input.charAt(5);
       charac_7=letter_input.charAt(6);
       charac_8=letter_input.charAt(7);
      
    
    document.querySelector('.number_of_letters_typed').classList.add('hide_boxes');
 document.querySelector('.amount_of_letters').classList.add('hide_boxes');
  document.querySelector('.close_button').classList.add('hide_boxes');
  

    
if(n===amount_of_letters && n===3){
  isPaused=true;
  clock_pause();
  clearTimeout(timerId);
  if(charac_1===letter_3_1){
    var cash_3_1= Math.round((.33 * questionCash));
    var  cash_3_1_minus=0;
    var first_letter=document.querySelector('.write_box_3_3').childNodes[1].innerHTML=charac_1;
    findI();
    removeI();
    findM();
    removeM();
    findJ();
    removeJ();
    findW();
    removeW();
    
  }if(charac_1 != letter_3_1){
    var cash_3_1_minus= -Math.round((.33 * questionCash));
    var cash_3_1=0;
    var first_letter=document.querySelector('.write_box_3_3').childNodes[1].innerHTML='x';
    
    
  }if(charac_2===letter_3_2){
    var cash_3_2= Math.round((.33 * questionCash));
    var cash_3_2_minus=0;
    var second_letter=document.querySelector('.write_box_3_3').childNodes[3].innerHTML=charac_2;
    findI();
    removeI();
    findM();
    removeM();
    findJ();
    removeJ();
    findW();
    removeW();
    
  }if(charac_2 != letter_3_2){
    var cash_3_2_minus= -Math.round((.33 * questionCash));
    var cash_3_2=0;
    var second_letter=document.querySelector('.write_box_3_3').childNodes[3].innerHTML='x';
  }if(charac_3===letter_3_3){
    var cash_3_3= Math.round((.33 * questionCash));
    var cash_3_3_minus=0;
  } if(cash_3_1 && cash_3_2 && cash_3_3){
    totalQuestionCash3=(cash_3_1 + cash_3_2 + cash_3_3);
   final_3_cash_final= '$' + totalQuestionCash3;
  document.querySelector('.points').innerHTML=final_3_cash_final;
   document.querySelector('.points').classList.add('cash_green');
  main_score=main_score+totalQuestionCash3;
  
  
   
    document.querySelector('.score_card_1').innerHTML=main_score;
  

   var sixth_letter=document.querySelector('.write_box_3_3').childNodes[5].innerHTML=charac_4;
  
   findI();
   removeI();
   findM();
   removeM();
   findJ();
   removeJ();
   findW();
   removeW();



    
  }if(charac_3 != letter_3_3){
    var cash_3_3_minus= -Math.round((.33 * questionCash));
    var cash_3_3=0;
    
  }if(cash_3_1_minus || cash_3_2_minus || cash_3_3_minus ){
    totalQuestionCash3=(cash_3_1_minus + cash_3_2_minus + cash_3_3_minus);
   final_3_cash_final= '$' + totalQuestionCash3;
  document.querySelector('.points').innerHTML=final_3_cash_final;
   document.querySelector('.points').classList.add('cash_green');
  
    main_score=main_score+totalQuestionCash3;
    if(main_score <10){
      document.querySelector('.score_card_1').classList.add('score_card_1_padding');
    }else if(main_score <100){
     document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
     document.querySelector('.score_card_1').classList.add('score_card_10_padding');
    }else if(main_score<1000){
     document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
     document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
     document.querySelector('.score_card_1').classList.add('score_card_100_padding');
    }
  
   
    document.querySelector('.score_card_1').innerHTML=main_score;

  


}


    
    }else if(n===amount_of_letters&&n===4){
      isPaused=true;
      clock_pause();
      clearTimeout(timerId);
      gsap.to(".time_control", {duration: 3, x: 300, opacity: 0, scale: 0.5});
      gsap.to(".disappear", {duration: 3, x: 300, opacity: 0, scale: 0.5});
  if(charac_1===letter_4_1){
    var cash_4_1= Math.round((.25 * questionCash));
    var cash_4_1_minus=0;
    var total_4_percent_1=1;
    gsap.timeline().from(".box_4_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
    document.querySelector('.box_4_1').classList.add('border_green');
    var first_letter=document.querySelector('.write_box_4_4').childNodes[1].innerHTML=charac_1;
    findI();
    removeI();
    findM();
    removeM();
    findJ();
    removeJ();
    findW();
    removeW();
    
  }if(charac_1 != letter_4_1){
    var cash_4_1_minus= -Math.round((.25 * questionCash));
    var cash_4_1=0;
    var total_4_percent_1=0;
    gsap.timeline().from(".box_4_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:wrongLetterTone_1});
    gsap.timeline().from(".box_4_1",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_4_1').classList.add('border_red');
      document.querySelector('.box_4_1').classList.add('cash_red');
      var first_letter=document.querySelector('.box_4_1').innerHTML='x';


    }});

    gsap.timeline().from(".box_4_1",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:.4,onStart:function(){
      document.querySelector('.box_4_1').innerHTML='';
      document.querySelector('.box_4_1').classList.add('border_red');
      document.querySelector('.box_4_1').classList.remove('cash_red');
      if(letter_4_1==='M'){
        document.querySelector('.box_4_1').classList.add('letter_m');
        var first_letter=document.querySelector('.box_4_1').innerHTML=letter_4_1;
      }else if(letter_4_1==='I'){
        document.querySelector('.box_4_1').classList.add('letter_i');
        var first_letter=document.querySelector('.box_4_1').innerHTML=letter_4_1;
      }else if(letter_4_1==='J'){
        document.querySelector('.box_4_1').classList.add('letter_j');
        var first_letter=document.querySelector('.box_4_1').innerHTML=letter_4_1;
      }else if(letter_4_1==='W'){
        document.querySelector('.box_4_1').classList.add('letter_w');
        var first_letter=document.querySelector('.box_4_1').innerHTML=letter_4_1;
      }else{
        var first_letter=document.querySelector('.box_4_1').innerHTML=letter_4_1;
      }
      


    }});
  }if(charac_2===letter_4_2){
    var cash_4_2= Math.round((.25 * questionCash));
    var cash_4_2_minus=0;
    var total_4_percent_2=1;
    gsap.timeline().from(".box_4_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.4,onStart:correctLetterTone_2});
    document.querySelector('.box_4_2').classList.add('border_green');
    var second_letter=document.querySelector('.write_box_4_4').childNodes[3].innerHTML=charac_2;
    findI();
    removeI();
    findM();
    removeM();
    findJ();
    removeJ();
    findW();
    removeW();
    
  }if(charac_2 != letter_4_2){
    var cash_4_2_minus= -Math.round((.25 * questionCash));
    var cash_4_2=0;
    var total_4_percent_2=0;
    gsap.timeline().from(".box_4_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.4,onStart:wrongLetterTone_2});
    gsap.timeline().from(".box_4_2",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_4_2').classList.add('border_red');
      document.querySelector('.box_4_2').classList.add('cash_red');
      var first_letter=document.querySelector('.box_4_2').innerHTML='x';


    }});

    gsap.timeline().from(".box_4_2",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:.7,onStart:function(){
      document.querySelector('.box_4_2').innerHTML='';
      document.querySelector('.box_4_2').classList.add('border_red');
      document.querySelector('.box_4_2').classList.remove('cash_red');
      if(letter_4_2==='M'){
        document.querySelector('.box_4_2').classList.add('letter_m');
        var first_letter=document.querySelector('.box_4_2').innerHTML=letter_4_2;
      }else if(letter_4_2==='I'){
        document.querySelector('.box_4_2').classList.add('letter_i');
        var first_letter=document.querySelector('.box_4_2').innerHTML=letter_4_2;
      }else if(letter_4_2==='J'){
        document.querySelector('.box_4_2').classList.add('letter_j');
        var first_letter=document.querySelector('.box_4_2').innerHTML=letter_4_2;
      }else if(letter_4_2==='W'){
        document.querySelector('.box_4_2').classList.add('letter_w');
        var first_letter=document.querySelector('.box_4_2').innerHTML=letter_4_2;
      }else{
        var first_letter=document.querySelector('.box_4_2').innerHTML=letter_4_2;
      }
      


    }});
  }if(charac_3===letter_4_3){
    var cash_4_3= Math.round((.25 * questionCash));
    var cash_4_3_minus=0;
    var total_4_percent_3=1;
    gsap.timeline().from(".box_4_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.7,onStart:correctLetterTone_3});
    document.querySelector('.box_4_3').classList.add('border_green');
    var third_letter=document.querySelector('.write_box_4_4').childNodes[5].innerHTML=charac_3;
    findI();
    removeI();
    findM();
    removeM();
    findJ();
    removeJ();
    findW();
    removeW();
    
  }if(charac_3 != letter_4_3){
    var cash_4_3_minus= -Math.round((.25 * questionCash));
    var cash_4_3=0;
    var total_4_percent_3=0;
    gsap.timeline().from(".box_4_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.7,onStart:wrongLetterTone_3});
    gsap.timeline().from(".box_4_3",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_4_3').classList.add('border_red');
      document.querySelector('.box_4_3').classList.add('cash_red');
      var first_letter=document.querySelector('.box_4_3').innerHTML='x';


    }});

    gsap.timeline().from(".box_4_3",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1,onStart:function(){
      document.querySelector('.box_4_3').innerHTML='';
      document.querySelector('.box_4_3').classList.add('border_red');
      document.querySelector('.box_4_3').classList.remove('cash_red');
      if(letter_4_3==='M'){
        document.querySelector('.box_4_3').classList.add('letter_m');
        var first_letter=document.querySelector('.box_4_3').innerHTML=letter_4_3;
      }else if(letter_4_3==='I'){
        document.querySelector('.box_4_3').classList.add('letter_i');
        var first_letter=document.querySelector('.box_4_3').innerHTML=letter_4_3;
      }else if(letter_4_3==='J'){
        document.querySelector('.box_4_3').classList.add('letter_j');
        var first_letter=document.querySelector('.box_4_3').innerHTML=letter_4_3;
      }else if(letter_4_3==='W'){
        document.querySelector('.box_4_3').classList.add('letter_w');
        var first_letter=document.querySelector('.box_4_3').innerHTML=letter_4_3;
      }else{
        var first_letter=document.querySelector('.box_4_3').innerHTML=letter_4_3;
      }
      


    }});
  
  
}if(charac_4!=letter_4_4 ){
  var cash_4_4_minus= -Math.round((.25 * questionCash));
  var cash_4_4=0;
  var total_4_percent_4=0;
  gsap.timeline().from(".box_4_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1,onStart:wrongLetterTone_4});
  gsap.timeline().from(".box_4_4",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
    document.querySelector('.box_4_4').classList.add('border_red');
    document.querySelector('.box_4_4').classList.add('cash_red');
    var first_letter=document.querySelector('.box_4_4').innerHTML='x';


  }});

  gsap.timeline().from(".box_4_4",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1.3,onStart:function(){
    document.querySelector('.box_4_4').innerHTML='';
    document.querySelector('.box_4_4').classList.add('border_red');
    document.querySelector('.box_4_4').classList.remove('cash_red');
    if(letter_4_4==='M'){
      document.querySelector('.box_4_4').classList.add('letter_m');
      var first_letter=document.querySelector('.box_4_4').innerHTML=letter_4_4;
    }else if(letter_4_4==='I'){
      document.querySelector('.box_4_4').classList.add('letter_i');
      var first_letter=document.querySelector('.box_4_4').innerHTML=letter_4_4;
    }else if(letter_4_4==='J'){
      document.querySelector('.box_4_4').classList.add('letter_j');
      var first_letter=document.querySelector('.box_4_4').innerHTML=letter_4_4;
    }else if(letter_4_4==='W'){
      document.querySelector('.box_4_4').classList.add('letter_w');
      var first_letter=document.querySelector('.box_4_4').innerHTML=letter_4_4;
    }else{
      var first_letter=document.querySelector('.box_4_4').innerHTML=letter_4_4;
    }
    


  }});
  
  if(cash_4_1_minus || cash_4_2_minus || cash_4_3_minus || cash_4_4_minus ){
     total4cashMinus=(cash_4_1_minus+cash_4_2_minus+cash_4_3_minus+cash_4_4_minus);
    
      audienceMinusTone();
      gsap.timeline().from(".points",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:2.7});
      gsap.timeline().to(".points",{duration:1,opacity:1,scale:0,x:0,ease:"back",delay:2.7,onStart:loseMoneyTone});

    
   
      
    
      

    
   
    document.querySelector('.points').innerHTML='-'+'$'+-total4cashMinus;
    
    document.querySelector('.points').classList.add('cash_red');
  
    main_score= Math.ceil(main_score+total4cashMinus);
    
    
    if(main_score<=5){
      console.log('game over');
      $(".cover ").show();
        $(".game_over ").show();
        document.querySelector('.start_over').addEventListener('click',function(){
          location.reload(true);
        });
    }if(main_score <10){
      document.querySelector('.score_card_1').classList.add('score_card_1_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;
    }else if(main_score>=10 && main_score<100){
      document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
      document.querySelector('.score_card_1').classList.add('score_card_10_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;
    }else if(main_score>=100 && main_score<1000){
      document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
      document.querySelector('.score_card_1').classList.add('score_card_100_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;
    }else if(main_score>=1000 && main_score<=10000){
      document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
      document.querySelector('.score_card_1').classList.add('score_card_1000_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;
    }else if(main_score>=10000 && main_score<=100000){
      document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_1000_padding');
      document.querySelector('.score_card_1').classList.add('score_card_10000_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;

    }
  document.querySelector('.players_cash').innerHTML='$'+main_score;
  document.querySelector('.players_cash_1').innerHTML=' '+'$'+main_score;

  var seventh_letter=document.querySelector('.write_box_4_4').childNodes[7].innerHTML="x";
}
   
} if(charac_4===letter_4_4){
   
  var cash_4_4= Math.round((.25 * questionCash));
  var cash_4_4_minus=0;
  var total_4_percent_4=1;
  gsap.timeline().from(".box_4_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1,onStart:correctLetterTone_4});
  document.querySelector('.box_4_4').classList.add('border_green');
    
  document.querySelector('.write_box_4_4').childNodes[7].innerHTML=charac_4;
  } 
 
 }if(cash_4_1 && cash_4_2 && cash_4_3 && cash_4_4 ){
     totalQuestionCash4=(cash_4_1 + cash_4_2 + cash_4_3 + cash_4_4);
     percentage_4_plus=(total_4_percent_1 + total_4_percent_2 + total_4_percent_3 + total_4_percent_4 );  
     audiencePlusTone();
       gsap.timeline().from(".points",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1.6});
           gsap.timeline().to(".points",{duration:1,opacity:1,scale:0,x:0,ease:"back",delay:1.6,onStart:playMoneyTone}); 
       
     letter_total=4;
     letter_count=letter_total+letter_count;
     console.log(letter_count);
  total_percent =total_percent+percentage_4_plus;
  var percent_total=document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100);
    if(percent_total===0 || percent_total<10){
      document.querySelector('.score_card').classList.remove('percent_padding_100');
      document.querySelector('.score_card').classList.remove('percent_padding_10');
      console.log('padding1-10');
      document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
    }else if(percent_total>10 && percent_total<99){
      document.querySelector('.score_card').classList.add('percent_padding_10');
      document.querySelector('.score_card').classList.remove('percent_padding_100');
      console.log('padding10-100');
      document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
    }else if(percent_total===100){
      document.querySelector('.score_card').classList.add('percent_padding_100');
      document.querySelector('.score_card').classList.remove('percent_padding_10');
      console.log('padding100');
      document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
    }
     var total_score_4=totalQuestionCash4 + (totalQuestionCash4 * .5);
    document.querySelector('.points').innerHTML= '$' +(totalQuestionCash4+ (totalQuestionCash4 * .5));
    document.querySelector('.points').classList.add('cash_green');
    
    main_score=Math.ceil(main_score+total_score_4);    
   
    if(main_score<=5){
      
      $(".cover ").show();
        $(".game_over ").show();
        document.querySelector('.start_over').addEventListener('click',function(){
          location.reload(true);
        });
    }if(main_score <10){
      document.querySelector('.score_card_1').classList.add('score_card_1_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;
    }else if(main_score>=10 && main_score<100){
      document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
      document.querySelector('.score_card_1').classList.add('score_card_10_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;
    }else if(main_score>=100 && main_score<1000){
      document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
      document.querySelector('.score_card_1').classList.add('score_card_100_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;
    }else if(main_score>=1000 && main_score<=10000){
      document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
      document.querySelector('.score_card_1').classList.add('score_card_1000_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;
    }else if(main_score>=10000 && main_score<=100000){
      document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_1000_padding');
      document.querySelector('.score_card_1').classList.add('score_card_10000_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;

    }
     document.querySelector('.players_cash').innerHTML=''+'$'+main_score;
     document.querySelector('.players_cash_1').innerHTML=' '+'$'+main_score;
    
    document.querySelector('.write_box_5_5').childNodes[7].innerHTML=charac_4;

    findI();
removeI();
findM();
removeM();
findJ();
removeJ();
findW();
removeW();
 }
if(cash_4_1_minus || cash_4_2_minus || cash_4_3_minus && cash_4_4){
  cash_4_4=0; 
total4cashMinus=(cash_4_1_minus+cash_4_2_minus+cash_4_3_minus+cash_4_4);
percentage_4_minus=(total_4_percent_1 + total_4_percent_2 + total_4_percent_3 + total_4_percent_4 );  


  audienceMinusTone();
  gsap.timeline().from(".points",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:2.7});
  gsap.timeline().to(".points",{duration:1,opacity:1,scale:0,x:0,ease:"back",delay:2.7,onStart:loseMoneyTone});




   
       
letter_total=4;
letter_count=letter_total+letter_count;

total_percent =total_percent+percentage_4_minus;
var percent_total=document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100);
    if(percent_total===0 || percent_total<10){
      document.querySelector('.score_card').classList.remove('percent_padding_100');
      document.querySelector('.score_card').classList.remove('percent_padding_10');
      
      document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
    }else if(percent_total>10 && percent_total<99){
      document.querySelector('.score_card').classList.add('percent_padding_10');
      document.querySelector('.score_card').classList.remove('percent_padding_100');
     
      document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
    }else if(percent_total===100){
      document.querySelector('.score_card').classList.add('percent_padding_100');
      document.querySelector('.score_card').classList.remove('percent_padding_10');
      
      document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
    }
  
if(cash_4_4_minus){
  final_4_display=-+total4cashMinus+Math.round((.25 * questionCash));
  
document.querySelector('.points').innerHTML='-'+ '$'+final_4_display;
  document.querySelector('.points').classList.add('cash_red');

if(main_score<=5){
  
  $(".cover ").show();
    $(".game_over ").show();
    document.querySelector('.start_over').addEventListener('click',function(){
      location.reload(true);
    });
}if(main_score <10){
  document.querySelector('.score_card_1').classList.add('score_card_1_padding');
  document.querySelector('.score_card_1').innerHTML=main_score;
}else if(main_score>=10 && main_score<100){
  document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
  document.querySelector('.score_card_1').classList.add('score_card_10_padding');
  document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
  document.querySelector('.score_card_1').innerHTML=main_score;
}else if(main_score>=100 && main_score<1000){
  document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
  document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
  document.querySelector('.score_card_1').classList.add('score_card_100_padding');
  document.querySelector('.score_card_1').innerHTML=main_score;
}else if(main_score>=1000 && main_score<=10000){
  document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
  document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
  document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
  document.querySelector('.score_card_1').classList.add('score_card_1000_padding');
  document.querySelector('.score_card_1').innerHTML=main_score;
}else if(main_score>=10000 && main_score<=100000){
  document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
  document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
  document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
  document.querySelector('.score_card_1').classList.remove('score_card_1000_padding');
  document.querySelector('.score_card_1').classList.add('score_card_10000_padding');
  document.querySelector('.score_card_1').innerHTML=main_score;

}
  document.querySelector('.players_cash').innerHTML=''+'$'+main_score;
  document.querySelector('.players_cash_1').innerHTML=' '+'$'+main_score;
 

}else if(!cash_4_4_minus){
  final_4_display=-+total4cashMinus;
  
document.querySelector('.points').innerHTML='-'+ '$'+final_4_display;
  document.querySelector('.points').classList.add('cash_red');
main_score= Math.ceil(main_score-final_4_display);
if(main_score<=5){
  
  $(".cover ").show();
    $(".game_over ").show();
    document.querySelector('.start_over').addEventListener('click',function(){
      location.reload(true);
    });
}if(main_score <10){
  document.querySelector('.score_card_1').classList.add('score_card_1_padding');
  document.querySelector('.score_card_1').innerHTML=main_score;
}else if(main_score>=10 && main_score<100){
  document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
  document.querySelector('.score_card_1').classList.add('score_card_10_padding');
  document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
  document.querySelector('.score_card_1').innerHTML=main_score;
}else if(main_score>=100 && main_score<1000){
  document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
  document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
  document.querySelector('.score_card_1').classList.add('score_card_100_padding');
  document.querySelector('.score_card_1').innerHTML=main_score;
}else if(main_score>=1000 && main_score<=10000){
  document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
  document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
  document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
  document.querySelector('.score_card_1').classList.add('score_card_1000_padding');
  document.querySelector('.score_card_1').innerHTML=main_score;
}else if(main_score>=10000 && main_score<=100000){
  document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
  document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
  document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
  document.querySelector('.score_card_1').classList.remove('score_card_1000_padding');
  document.querySelector('.score_card_1').classList.add('score_card_10000_padding');
  document.querySelector('.score_card_1').innerHTML=main_score;

}



} 
 
    

document.querySelector('.players_cash').innerHTML=''+'$'+main_score;
document.querySelector('.players_cash_1').innerHTML=' '+'$'+main_score;

  
 


 
  
}else if(n===amount_of_letters&&n===5){
  isPaused=true;
  clock_pause();
  clearTimeout(timerId);
  
  gsap.to(".time_control", {duration: 3, x: 300, opacity: 0, scale: 0.5});
  gsap.to(".disappear", {duration: 3, x: 300, opacity: 0, scale: 0.5});
  if(charac_1===letter_5_1){
    var cash_5_1= Math.round((.20 * questionCash));
    var cash_5_1_minus=0;
    var total_5_percent_1=1;
    gsap.timeline().from(".box_5_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.4,onStart:correctLetterTone_1});
    document.querySelector('.box_5_1').classList.add('border_green');
    document.querySelector('.write_box_5_5').childNodes[1].innerHTML=charac_1;
    
    findI();
    removeI();
    findM();
    removeM();
    findJ();
    removeJ();
    findW();
    removeW();
    
    
  }if(charac_1 != letter_5_1){
    var cash_5_1_minus= -Math.round((.20 * questionCash));
    var cash_5_1=0;
    var total_5_percent_1=0;
    gsap.timeline().from(".box_5_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:wrongLetterTone_1});
    gsap.timeline().from(".box_5_1",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_5_1').classList.add('border_red');
      document.querySelector('.box_5_1').classList.add('cash_red');
      document.querySelector('.write_box_5_5').childNodes[1].innerHTML='x';


    }});

    gsap.timeline().from(".box_5_1",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:.4,onStart:function(){
      document.querySelector('.box_5_1').innerHTML='';
      document.querySelector('.box_5_1').classList.add('border_red');
      document.querySelector('.box_5_1').classList.remove('cash_red');
      if(letter_5_1==='M'){
        document.querySelector('.box_5_1').classList.add('letter_m');
        var first_letter=document.querySelector('.box_5_1').innerHTML=letter_5_1;
      }else if(letter_5_1==='I'){
        document.querySelector('.box_5_1').classList.add('letter_i');
        var first_letter=document.querySelector('.box_5_1').innerHTML=letter_5_1;
      }else if(letter_5_1==='J'){
        document.querySelector('.box_5_1').classList.add('letter_j');
        var first_letter=document.querySelector('.box_5_1').innerHTML=letter_5_1;
      }else if(letter_5_1==='W'){
        document.querySelector('.box_5_1').classList.add('letter_w');
        var first_letter=document.querySelector('.box_5_1').innerHTML=letter_5_1;
      }else{
        var first_letter=document.querySelector('.box_5_1').innerHTML=letter_5_1;
      }
      


    }});
  }if(charac_2===letter_5_2){
    var cash_5_2= Math.round((.20 * questionCash));
    var cash_5_2_minus=0;
    var total_5_percent_2=1;
    gsap.timeline().from(".box_5_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.4,onStart:correctLetterTone_2});
    document.querySelector('.box_5_2').classList.add('border_green');
    var second_letter=document.querySelector('.write_box_5_5').childNodes[3].innerHTML=charac_2;
    findI();
    removeI();
    findM();
    removeM();
    findJ();
    removeJ();
    findW();
    removeW();
    
    
  }if(charac_2 != letter_5_2){
    var cash_5_2_minus= -Math.round((.20 * questionCash));
    var cash_5_2=0;
    var total_5_percent_2=0;
    gsap.timeline().from(".box_5_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.4,onStart:wrongLetterTone_2});
    gsap.timeline().from(".box_5_2",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_5_2').classList.add('border_red');
      document.querySelector('.box_5_2').classList.add('cash_red');
      var first_letter=document.querySelector('.box_5_2').innerHTML='x';


    }});

    gsap.timeline().from(".box_5_2",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:.7,onStart:function(){
      document.querySelector('.box_5_2').innerHTML='';
      document.querySelector('.box_5_2').classList.add('border_red');
      document.querySelector('.box_5_2').classList.remove('cash_red');
      if(letter_5_2==='M'){
        document.querySelector('.box_5_2').classList.add('letter_m');
        var first_letter=document.querySelector('.box_5_2').innerHTML=letter_5_2;
      }else if(letter_5_2==='I'){
        document.querySelector('.box_5_2').classList.add('letter_i');
        var first_letter=document.querySelector('.box_5_2').innerHTML=letter_5_2;
      }else if(letter_5_2==='J'){
        document.querySelector('.box_5_2').classList.add('letter_j');
        var first_letter=document.querySelector('.box_5_2').innerHTML=letter_5_2;
      }else if(letter_5_2==='W'){
        document.querySelector('.box_5_2').classList.add('letter_w');
        var first_letter=document.querySelector('.box_5_2').innerHTML=letter_5_2;
      }else{
        var first_letter=document.querySelector('.box_5_2').innerHTML=letter_5_2;
      }
      


    }});
  }if(charac_3===letter_5_3){
    var cash_5_3= Math.round((.20 * questionCash));
    var cash_5_3_minus=0;
    var total_5_percent_3=1;
    gsap.timeline().from(".box_5_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.7,onStart:correctLetterTone_3});
    document.querySelector('.box_5_3').classList.add('border_green');
    var third_letter=document.querySelector('.write_box_5_5').childNodes[5].innerHTML=charac_3;
    findI();
    removeI();
    findM();
    removeM();
    findJ();
    removeJ();
    findW();
    removeW();
    
  }if(charac_3 != letter_5_3){
    var cash_5_3_minus= -Math.round((.20 * questionCash));
    var cash_5_4=0;
    var total_5_percent_3=0;
    gsap.timeline().from(".box_5_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.7,onStart:wrongLetterTone_3});
    gsap.timeline().from(".box_5_3",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_5_3').classList.add('border_red');
      document.querySelector('.box_5_3').classList.add('cash_red');
      var first_letter=document.querySelector('.box_5_3').innerHTML='x';


    }});

    gsap.timeline().from(".box_5_3",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1,onStart:function(){
      document.querySelector('.box_5_3').innerHTML='';
      document.querySelector('.box_5_3').classList.add('border_red');
      document.querySelector('.box_5_3').classList.remove('cash_red');
      if(letter_5_3==='M'){
        document.querySelector('.box_5_3').classList.add('letter_m');
        var first_letter=document.querySelector('.box_5_3').innerHTML=letter_5_3;
      }else if(letter_5_3==='I'){
        document.querySelector('.box_5_3').classList.add('letter_i');
        var first_letter=document.querySelector('.box_5_3').innerHTML=letter_5_3;
      }else if(letter_5_3==='J'){
        document.querySelector('.box_5_3').classList.add('letter_j');
        var first_letter=document.querySelector('.box_5_3').innerHTML=letter_5_3;
      }else if(letter_5_3==='W'){
        document.querySelector('.box_5_3').classList.add('letter_w');
        var first_letter=document.querySelector('.box_5_3').innerHTML=letter_5_3;
      }else{
        var first_letter=document.querySelector('.box_5_3').innerHTML=letter_5_3;
      }
      


    }});
  }if(charac_4===letter_5_4){
    var cash_5_4= Math.round((.20 * questionCash));
    var cash_5_4_minus=0;
    var total_5_percent_4=1;
    gsap.timeline().from(".box_5_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1,onStart:correctLetterTone_4});
    document.querySelector('.box_5_4').classList.add('border_green');
    var fourth_letter=document.querySelector('.write_box_5_5').childNodes[7].innerHTML=charac_4;
    findI();
    removeI();
    findM();
    removeM();
    findJ();
    removeJ();
    findW();
    removeW();
    
  }if(charac_4 != letter_5_4){
    var cash_5_4_minus= -Math.round((.20 * questionCash));
      var cash_5_4=0;
      var total_5_percent_4=0;
      gsap.timeline().from(".box_5_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1,onStart:wrongLetterTone_4});
      gsap.timeline().from(".box_5_4",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
        document.querySelector('.box_5_4').classList.add('border_red');
        document.querySelector('.box_5_4').classList.add('cash_red');
        var first_letter=document.querySelector('.box_5_4').innerHTML='x';
  
  
      }});
  
      gsap.timeline().from(".box_5_4",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1.3,onStart:function(){
        document.querySelector('.box_5_4').innerHTML='';
        document.querySelector('.box_5_4').classList.add('border_red');
        document.querySelector('.box_5_4').classList.remove('cash_red');
        if(letter_5_4==='M'){
          document.querySelector('.box_5_4').classList.add('letter_m');
          var first_letter=document.querySelector('.box_5_4').innerHTML=letter_5_4;
        }else if(letter_5_4==='I'){
          document.querySelector('.box_5_4').classList.add('letter_i');
          var first_letter=document.querySelector('.box_5_4').innerHTML=letter_5_4;
        }else if(letter_5_4==='J'){
          document.querySelector('.box_5_4').classList.add('letter_j');
          var first_letter=document.querySelector('.box_5_4').innerHTML=letter_5_4;
        }else if(letter_5_4==='W'){
          document.querySelector('.box_5_4').classList.add('letter_w');
          var first_letter=document.querySelector('.box_5_4').innerHTML=letter_5_4;
        }else{
          var first_letter=document.querySelector('.box_5_4').innerHTML=letter_5_4;
        }
        
  
  
      }});
  
  }if(charac_5!=letter_5_5 ){
      var cash_5_5_minus= -Math.round((.20 * questionCash));
      var cash_5_5=0;
      var total_5_percent_5=0;
      gsap.timeline().from(".box_5_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1.3,onStart:wrongLetterTone_5});
      gsap.timeline().from(".box_5_5",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
        document.querySelector('.box_5_5').classList.add('border_red');
        document.querySelector('.box_5_5').classList.add('cash_red');
        var first_letter=document.querySelector('.box_5_5').innerHTML='x';
  
  
      }});
  
      gsap.timeline().from(".box_5_5",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1.6,onStart:function(){
        document.querySelector('.box_5_5').innerHTML='';
        document.querySelector('.box_5_5').classList.add('border_red');
        document.querySelector('.box_5_5').classList.remove('cash_red');
        if(letter_5_5==='M'){
          document.querySelector('.box_5_5').classList.add('letter_m');
          var first_letter=document.querySelector('.box_5_5').innerHTML=letter_5_5;
        }else if(letter_5_5==='I'){
          document.querySelector('.box_5_5').classList.add('letter_i');
          var first_letter=document.querySelector('.box_5_5').innerHTML=letter_5_5;
        }else if(letter_5_5==='J'){
          document.querySelector('.box_5_5').classList.add('letter_j');
          var first_letter=document.querySelector('.box_5_5').innerHTML=letter_5_5;
        }else if(letter_5_5==='W'){
          document.querySelector('.box_5_5').classList.add('letter_w');
          var first_letter=document.querySelector('.box_5_5').innerHTML=letter_5_5;
        }else{
          var first_letter=document.querySelector('.box_5_5').innerHTML=letter_5_5;
        }
        
  
  
      }});
      
      if(cash_5_1_minus || cash_5_2_minus || cash_5_3_minus || cash_5_4_minus || cash_5_5_minus ){
         total5cashMinus=(cash_5_1_minus+cash_5_2_minus+cash_5_3_minus+cash_5_4_minus+cash_5_5_minus);
        
         
        
          audienceMinusTone();
          gsap.timeline().from(".points",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:2.7});
          gsap.timeline().to(".points",{duration:1,opacity:1,scale:0,x:0,ease:"back",delay:2.7,onStart:loseMoneyTone});
    
        
        
  
        
       
        document.querySelector('.points').innerHTML='-'+'$'+-total5cashMinus;
        
        document.querySelector('.points').classList.add('cash_red');
      
        main_score= Math.ceil(main_score+total5cashMinus);
        
        
        if(main_score<=5){
          
          $(".cover ").show();
            $(".game_over ").show();
            document.querySelector('.start_over').addEventListener('click',function(){
              location.reload(true);
            });
        }if(main_score <10){
          document.querySelector('.score_card_1').classList.add('score_card_1_padding');
          document.querySelector('.score_card_1').innerHTML=main_score;
        }else if(main_score>=10 && main_score<100){
          document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
          document.querySelector('.score_card_1').classList.add('score_card_10_padding');
          document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
          document.querySelector('.score_card_1').innerHTML=main_score;
        }else if(main_score>=100 && main_score<1000){
          document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
          document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
          document.querySelector('.score_card_1').classList.add('score_card_100_padding');
          document.querySelector('.score_card_1').innerHTML=main_score;
        }else if(main_score>=1000 && main_score<=10000){
          document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
          document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
          document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
          document.querySelector('.score_card_1').classList.add('score_card_1000_padding');
          document.querySelector('.score_card_1').innerHTML=main_score;
        }else if(main_score>=10000 && main_score<=100000){
          document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
          document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
          document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
          document.querySelector('.score_card_1').classList.remove('score_card_1000_padding');
          document.querySelector('.score_card_1').classList.add('score_card_10000_padding');
          document.querySelector('.score_card_1').innerHTML=main_score;
    
        }
      document.querySelector('.players_cash').innerHTML=''+'$'+main_score;
      document.querySelector('.players_cash_1').innerHTML=' '+'$'+main_score;
    
      var seventh_letter=document.querySelector('.write_box_5_5').childNodes[9].innerHTML="x";
    }
       
    } if(charac_5===letter_5_5){
       
      var cash_5_5= Math.round((.20 * questionCash));
      var cash_5_5_minus=0;
      var total_5_percent_5=1;
      gsap.timeline().from(".box_5_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1.3,onStart:correctLetterTone_5});
      document.querySelector('.box_5_5').classList.add('border_green');
      
      document.querySelector('.write_box_5_5').childNodes[9].innerHTML=charac_5;
      } 
     
     }if(cash_5_1 && cash_5_2 && cash_5_3 && cash_5_4 && cash_5_5 ){
         totalQuestionCash5=(cash_5_1 + cash_5_2 + cash_5_3 + cash_5_4 + cash_5_5 );
         percentage_5_plus=(total_5_percent_1 + total_5_percent_2 + total_5_percent_3 + total_5_percent_4 + total_5_percent_5 );  
         audiencePlusTone();
         gsap.timeline().from(".points",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:2});
             gsap.timeline().to(".points",{duration:1,opacity:1,scale:0,x:0,ease:"back",delay:2,onStart:playMoneyTone});
       
       letter_total=5;
       letter_count=letter_total+letter_count;
       console.log(letter_count);
    total_percent =total_percent+percentage_5_plus;
    var percent_total=document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100);
    if(percent_total===0 || percent_total<10){
      document.querySelector('.score_card').classList.remove('percent_padding_100');
      document.querySelector('.score_card').classList.remove('percent_padding_10');
      
      document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
    }else if(percent_total>10 && percent_total<99){
      document.querySelector('.score_card').classList.add('percent_padding_10');
      document.querySelector('.score_card').classList.remove('percent_padding_100');
      
      document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
    }else if(percent_total===100){
      document.querySelector('.score_card').classList.add('percent_padding_100');
      document.querySelector('.score_card').classList.remove('percent_padding_10');
      
      document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
    }
         var total_score_5=totalQuestionCash5 + (totalQuestionCash5 * .5);
        final_5_cash_final= '$' + totalQuestionCash5 +(totalQuestionCash5 * .5);
        document.querySelector('.points').innerHTML= '$' +(totalQuestionCash5+(totalQuestionCash5 * .5));
        document.querySelector('.points').classList.add('cash_green');
        
        main_score=Math.ceil(main_score+total_score_5);    
       
        if(main_score<=5){
          
          $(".cover ").show();
            $(".game_over ").show();
            document.querySelector('.start_over').addEventListener('click',function(){
              location.reload(true);
            });
        }if(main_score <10){
          document.querySelector('.score_card_1').classList.add('score_card_1_padding');
          document.querySelector('.score_card_1').innerHTML=main_score;
        }else if(main_score>=10 && main_score<100){
          document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
          document.querySelector('.score_card_1').classList.add('score_card_10_padding');
          document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
          document.querySelector('.score_card_1').innerHTML=main_score;
        }else if(main_score>=100 && main_score<1000){
          document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
          document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
          document.querySelector('.score_card_1').classList.add('score_card_100_padding');
          document.querySelector('.score_card_1').innerHTML=main_score;
        }else if(main_score>=1000 && main_score<=10000){
          document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
          document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
          document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
          document.querySelector('.score_card_1').classList.add('score_card_1000_padding');
          document.querySelector('.score_card_1').innerHTML=main_score;
        }else if(main_score>=10000 && main_score<=100000){
          document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
          document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
          document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
          document.querySelector('.score_card_1').classList.remove('score_card_1000_padding');
          document.querySelector('.score_card_1').classList.add('score_card_10000_padding');
          document.querySelector('.score_card_1').innerHTML=main_score;
    
        }
         document.querySelector('.players_cash').innerHTML=''+'$'+main_score;
         document.querySelector('.players_cash_1').innerHTML=' '+'$'+main_score;
        
        document.querySelector('.write_box_5_5').childNodes[9].innerHTML=charac_5;
  
        findI();
    removeI();
    findM();
    removeM();
    findJ();
    removeJ();
    findW();
    removeW();
     }
    if(cash_5_1_minus || cash_5_2_minus || cash_5_3_minus || cash_5_4_minus  && cash_5_5){
      cash_5_5=0; 
    total5cashMinus=(cash_5_1_minus+cash_5_2_minus+cash_5_3_minus+cash_5_4_minus+cash_5_5);
    percentage_5_minus=(total_5_percent_1 + total_5_percent_2 + total_5_percent_3 + total_5_percent_4 + total_5_percent_5 );  
    
    
    
      audienceMinusTone();
      gsap.timeline().from(".points",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:2.7});
      gsap.timeline().to(".points",{duration:1,opacity:1,scale:0,x:0,ease:"back",delay:2.7,onStart:loseMoneyTone});

    
    

    
       
       letter_total=5;
       letter_count=letter_total+letter_count;
       
    total_percent =total_percent+percentage_5_minus;
    var percent_total=document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100);
    if(percent_total===0 || percent_total<10){
      document.querySelector('.score_card').classList.remove('percent_padding_100');
      document.querySelector('.score_card').classList.remove('percent_padding_10');
      console.log('padding1-10');
      document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
    }else if(percent_total>10 && percent_total<99){
      document.querySelector('.score_card').classList.add('percent_padding_10');
      document.querySelector('.score_card').classList.remove('percent_padding_100');
      console.log('padding10-100');
      document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
    }else if(percent_total===100){
      document.querySelector('.score_card').classList.add('percent_padding_100');
      document.querySelector('.score_card').classList.remove('percent_padding_10');
      console.log('padding100');
      document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
    }
      
    if(cash_5_5_minus){
      final_5_display=-+total5cashMinus+Math.round((.20 * questionCash));
      document.querySelector('.points').innerHTML='-'+ '$'+final_5_display;
      document.querySelector('.points').classList.add('cash_red');
      document.querySelector('.score_card_1').innerHTML=main_score;
      document.querySelector('.players_cash').innerHTML=''+'$'+main_score;
      document.querySelector('.players_cash_1').innerHTML=' '+'$'+main_score;
     
  
    }else if(!cash_5_5_minus){
      final_5_display=-+total5cashMinus;
      document.querySelector('.points').innerHTML='-'+ '$'+final_5_display;
      document.querySelector('.points').classList.add('cash_red');
    main_score= Math.ceil(main_score-final_5_display);
    if(main_score<=5){
      
      $(".cover ").show();
        $(".game_over ").show();
        document.querySelector('.start_over').addEventListener('click',function(){
          location.reload(true);
        });
    }if(main_score <10){
      document.querySelector('.score_card_1').classList.add('score_card_1_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;
    }else if(main_score>=10 && main_score<100){
      document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
      document.querySelector('.score_card_1').classList.add('score_card_10_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;
    }else if(main_score>=100 && main_score<1000){
      document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
      document.querySelector('.score_card_1').classList.add('score_card_100_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;
    }else if(main_score>=1000 && main_score<=10000){
      document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
      document.querySelector('.score_card_1').classList.add('score_card_1000_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;
    }else if(main_score>=10000 && main_score<=100000){
      document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_1000_padding');
      document.querySelector('.score_card_1').classList.add('score_card_10000_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;

    }
      
      
  
  
  
    } 
     
        
  
  document.querySelector('.players_cash').innerHTML=''+'$'+main_score;
  document.querySelector('.players_cash_1').innerHTML=' '+'$'+main_score;
  
  
  
}else if(n===amount_of_letters&&n===6){
  isPaused=true;
  clock_pause();
  clearTimeout(timerId);
  gsap.to(".time_control", {duration: 3, x: 300, opacity: 0, scale: 0.5});
  gsap.to(".disappear", {duration: 3, x: 300, opacity: 0, scale: 0.5});
    if(charac_1 === letter_6_1){
     var cash_6_1= Math.round((.16 * questionCash));
     var cash_6_1_minus= 0;
     var total_6_percent_1=1;
     gsap.timeline().from(".box_6_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
     document.querySelector('.box_6_1').classList.add('border_green');
      
     var first_letter=document.querySelector('.write_box_6_6').childNodes[1].innerHTML=charac_1;
     findI();
     removeI();
     findM();
     removeM();
     findJ();
     removeJ();
     findW();
     removeW();
     
   }if(charac_1 != letter_6_1){
    var cash_6_1_minus=  -Math.round((.16 * questionCash));
    var cash_6_1= 0;
    var total_6_percent_1=0;
    gsap.timeline().from(".box_6_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:wrongLetterTone_1});
    gsap.timeline().from(".box_6_1",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_6_1').classList.add('border_red');
      document.querySelector('.box_6_1').classList.add('cash_red');
      var first_letter=document.querySelector('.box_6_1').innerHTML='x';


    }});

    gsap.timeline().from(".box_6_1",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:.4,onStart:function(){
      document.querySelector('.box_6_1').innerHTML='';
      document.querySelector('.box_6_1').classList.add('border_red');
      document.querySelector('.box_6_1').classList.remove('cash_red');
      if(letter_6_1==='M'){
        document.querySelector('.box_6_1').classList.add('letter_m');
        var first_letter=document.querySelector('.box_6_1').innerHTML=letter_6_1;
      }else if(letter_6_1==='I'){
        document.querySelector('.box_6_1').classList.add('letter_i');
        var first_letter=document.querySelector('.box_6_1').innerHTML=letter_6_1;
      }else if(letter_6_1==='J'){
        document.querySelector('.box_6_1').classList.add('letter_j');
        var first_letter=document.querySelector('.box_6_1').innerHTML=letter_6_1;
      }else if(letter_6_1==='W'){
        document.querySelector('.box_6_1').classList.add('letter_w');
        var first_letter=document.querySelector('.box_6_1').innerHTML=letter_6_1;
      }else{
        var first_letter=document.querySelector('.box_6_1').innerHTML=letter_6_1;
      }
      


    }});
   }if(charac_2 === letter_6_2){
     var cash_6_2= Math.round((.16 * questionCash));
     var cash_6_2_minus=0;
     var total_6_percent_2=1;
     gsap.timeline().from(".box_6_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.4,onStart:correctLetterTone_2});
     document.querySelector('.box_6_2').classList.add('border_green');
     var second_letter=document.querySelector('.write_box_6_6').childNodes[3].innerHTML=charac_2;
     findI();
     removeI();
     findM();
     removeM();
     findJ();
     removeJ();
     findW();
     removeW();
     
     
   }if(charac_2 != letter_6_2){
    var cash_6_2_minus= -Math.round((.16 * questionCash));
    var cash_6_2=0;
    var total_6_percent_2=0;
    gsap.timeline().from(".box_6_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.4,onStart:wrongLetterTone_2});
    gsap.timeline().from(".box_6_2",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_6_2').classList.add('border_red');
      document.querySelector('.box_6_2').classList.add('cash_red');
      var first_letter=document.querySelector('.box_6_2').innerHTML='x';


    }});

    gsap.timeline().from(".box_6_2",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:.7,onStart:function(){
      document.querySelector('.box_6_2').innerHTML='';
      document.querySelector('.box_6_2').classList.add('border_red');
      document.querySelector('.box_6_2').classList.remove('cash_red');
      if(letter_6_2==='M'){
        document.querySelector('.box_6_2').classList.add('letter_m');
        var first_letter=document.querySelector('.box_6_2').innerHTML=letter_6_2;
      }else if(letter_6_2==='I'){
        document.querySelector('.box_6_2').classList.add('letter_i');
        var first_letter=document.querySelector('.box_6_2').innerHTML=letter_6_2;
      }else if(letter_6_2==='J'){
        document.querySelector('.box_6_2').classList.add('letter_j');
        var first_letter=document.querySelector('.box_6_2').innerHTML=letter_6_2;
      }else if(letter_6_2==='W'){
        document.querySelector('.box_6_2').classList.add('letter_w');
        var first_letter=document.querySelector('.box_6_2').innerHTML=letter_6_2;
      }else{
        var first_letter=document.querySelector('.box_6_2').innerHTML=letter_6_2;
      }
      


    }});
   
   }if(charac_3 === letter_6_3){
     var cash_6_3= Math.round((.16 * questionCash));
     var cash_6_3_minus=0;
     var total_6_percent_3=1;
     gsap.timeline().from(".box_6_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.7,onStart:correctLetterTone_3});
     document.querySelector('.box_6_3').classList.add('border_green');
     var third_letter=document.querySelector('.write_box_6_6').childNodes[5].innerHTML=charac_3;
     findI();
     removeI();
     findM();
     removeM();
     findJ();
     removeJ();
     findW();
     removeW();
     
     
   }if(charac_3 != letter_6_3){
    var cash_6_3_minus=  -Math.round((.16 * questionCash));
    var cash_6_3=0;
    var total_6_percent_3=0;
    gsap.timeline().from(".box_6_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.7,onStart:wrongLetterTone_3});
    gsap.timeline().from(".box_6_3",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_6_3').classList.add('border_red');
      document.querySelector('.box_6_3').classList.add('cash_red');
      var first_letter=document.querySelector('.box_6_3').innerHTML='x';


    }});

    gsap.timeline().from(".box_6_3",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1,onStart:function(){
      document.querySelector('.box_6_3').innerHTML='';
      document.querySelector('.box_6_3').classList.add('border_red');
      document.querySelector('.box_6_3').classList.remove('cash_red');
      if(letter_6_3==='M'){
        document.querySelector('.box_6_3').classList.add('letter_m');
        var first_letter=document.querySelector('.box_6_3').innerHTML=letter_6_3;
      }else if(letter_6_3==='I'){
        document.querySelector('.box_6_3').classList.add('letter_i');
        var first_letter=document.querySelector('.box_6_3').innerHTML=letter_6_3;
      }else if(letter_6_3==='J'){
        document.querySelector('.box_6_3').classList.add('letter_j');
        var first_letter=document.querySelector('.box_6_3').innerHTML=letter_6_3;
      }else if(letter_6_3==='W'){
        document.querySelector('.box_6_3').classList.add('letter_w');
        var first_letter=document.querySelector('.box_6_3').innerHTML=letter_6_3;
      }else{
        var first_letter=document.querySelector('.box_6_3').innerHTML=letter_6_3;
      }
      


    }});
   }if(charac_4 === letter_6_4){
     var cash_6_4= Math.round((.16 * questionCash));
     var cash_6_4_minus=0;
     var total_6_percent_4=1;
     gsap.timeline().from(".box_6_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1,onStart:correctLetterTone_4});
     document.querySelector('.box_6_4').classList.add('border_green');
     var fourth_letter=document.querySelector('.write_box_6_6').childNodes[7].innerHTML=charac_4;
     findI();
     removeI();
     findM();
     removeM();
     findJ();
     removeJ();
     findW();
     removeW();
     
     
   }if(charac_4 != letter_6_4){
    var cash_6_4_minus=  -Math.round((.16 * questionCash));
    var cash_6_4=  0;
    var total_6_percent_4=0;
    gsap.timeline().from(".box_6_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1,onStart:wrongLetterTone_4});
    gsap.timeline().from(".box_6_4",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_6_4').classList.add('border_red');
      document.querySelector('.box_6_4').classList.add('cash_red');
      var first_letter=document.querySelector('.box_6_4').innerHTML='x';


    }});

    gsap.timeline().from(".box_6_4",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1.3,onStart:function(){
      document.querySelector('.box_6_4').innerHTML='';
      document.querySelector('.box_6_4').classList.add('border_red');
      document.querySelector('.box_6_4').classList.remove('cash_red');
      if(letter_6_4==='M'){
        document.querySelector('.box_6_4').classList.add('letter_m');
        var first_letter=document.querySelector('.box_6_4').innerHTML=letter_6_4;
      }else if(letter_6_4==='I'){
        document.querySelector('.box_6_4').classList.add('letter_i');
        var first_letter=document.querySelector('.box_6_4').innerHTML=letter_6_4;
      }else if(letter_6_4==='J'){
        document.querySelector('.box_6_4').classList.add('letter_j');
        var first_letter=document.querySelector('.box_6_4').innerHTML=letter_6_4;
      }else if(letter_6_4==='W'){
        document.querySelector('.box_6_4').classList.add('letter_w');
        var first_letter=document.querySelector('.box_6_4').innerHTML=letter_6_4;
      }else{
        var first_letter=document.querySelector('.box_6_4').innerHTML=letter_6_4;
      }
      


    }});
   }if(charac_5 === letter_6_5){
     var cash_6_5= Math.round((.16 * questionCash));
     var cash_6_5_minus=0;
     var total_6_percent_5=1;
     gsap.timeline().from(".box_6_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1.3,onStart:correctLetterTone_5});
     document.querySelector('.box_6_5').classList.add('border_green');
     var fifth_letter=document.querySelector('.write_box_6_6').childNodes[9].innerHTML=charac_5;
     findI();
     removeI();
     findM();
     removeM();
     findJ();
     removeJ();
     findW();
     removeW();
     
     
   }if(charac_5 != letter_6_5){
    var cash_6_5_minus= -Math.round((.16 * questionCash));
    var cash_6_5=0;
    var total_6_percent_5=0;
    gsap.timeline().from(".box_6_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1.3,onStart:wrongLetterTone_5});
    gsap.timeline().from(".box_6_5",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_6_5').classList.add('border_red');
      document.querySelector('.box_6_5').classList.add('cash_red');
      var first_letter=document.querySelector('.box_6_5').innerHTML='x';


    }});

    gsap.timeline().from(".box_6_5",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1.6,onStart:function(){
      document.querySelector('.box_6_5').innerHTML='';
      document.querySelector('.box_6_5').classList.add('border_red');
      document.querySelector('.box_6_5').classList.remove('cash_red');
      if(letter_6_5==='M'){
        document.querySelector('.box_6_5').classList.add('letter_m');
        var first_letter=document.querySelector('.box_6_5').innerHTML=letter_6_5;
      }else if(letter_6_5==='I'){
        document.querySelector('.box_6_5').classList.add('letter_i');
        var first_letter=document.querySelector('.box_6_5').innerHTML=letter_6_5;
      }else if(letter_6_5==='J'){
        document.querySelector('.box_6_5').classList.add('letter_j');
        var first_letter=document.querySelector('.box_6_5').innerHTML=letter_6_5;
      }else if(letter_6_5==='W'){
        document.querySelector('.box_6_5').classList.add('letter_w');
        var first_letter=document.querySelector('.box_6_5').innerHTML=letter_6_5;
      }else{
        var first_letter=document.querySelector('.box_6_5').innerHTML=letter_6_5;
      }
      


    }});
   } 
   if(charac_6!=letter_6_6 ){
    var cash_6_6_minus= -Math.round((.16 * questionCash));
    var cash_6_6=0;
    var total_6_percent_6=0;
    gsap.timeline().from(".box_6_6",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1.6,onStart:wrongLetterTone_6});
    gsap.timeline().from(".box_6_6",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_6_6').classList.add('border_red');
      document.querySelector('.box_6_6').classList.add('cash_red');
      var first_letter=document.querySelector('.box_6_6').innerHTML='x';


    }});

    gsap.timeline().from(".box_6_6",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:2,onStart:function(){
      document.querySelector('.box_6_6').innerHTML='';
      document.querySelector('.box_6_6').classList.add('border_red');
      document.querySelector('.box_6_6').classList.remove('cash_red');
      if(letter_6_6==='M'){
        document.querySelector('.box_6_6').classList.add('letter_m');
        var first_letter=document.querySelector('.box_6_6').innerHTML=letter_6_6;
      }else if(letter_6_6==='I'){
        document.querySelector('.box_6_6').classList.add('letter_i');
        var first_letter=document.querySelector('.box_6_6').innerHTML=letter_6_6;
      }else if(letter_6_6==='J'){
        document.querySelector('.box_6_6').classList.add('letter_j');
        var first_letter=document.querySelector('.box_6_6').innerHTML=letter_6_6;
      }else if(letter_6_6==='W'){
        document.querySelector('.box_6_6').classList.add('letter_w');
        var first_letter=document.querySelector('.box_6_6').innerHTML=letter_6_6;
      }else{
        var first_letter=document.querySelector('.box_6_6').innerHTML=letter_6_6;
      }
      


    }});
    
    if(cash_6_1_minus || cash_6_2_minus || cash_6_3_minus || cash_6_4_minus || cash_6_5_minus || cash_6_6_minus ){
       total6cashMinus=(cash_6_1_minus+cash_6_2_minus+cash_6_3_minus+cash_6_4_minus+cash_6_5_minus+cash_6_6_minus );
     
       
  
      console.log(total6cashMinus);
     
      
      
        audienceMinusTone();
        gsap.timeline().from(".points",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:2.7});
        gsap.timeline().to(".points",{duration:1,opacity:1,scale:0,x:0,ease:"back",delay:2.7,onStart:loseMoneyTone});
  
      
      

      
    
      
    document.querySelector('.points').innerHTML=total6cashMinus;
      
      document.querySelector('.points').classList.add('cash_red');
    
      main_score= Math.ceil(main_score+total6cashMinus);
      console.log(main_score);
      if(main_score<=5){
        
        $(".cover ").show();
          $(".game_over ").show();
          document.querySelector('.start_over').addEventListener('click',function(){
            location.reload(true);
          });
      }if(main_score <10){
        document.querySelector('.score_card_1').classList.add('score_card_1_padding');
        document.querySelector('.score_card_1').innerHTML=main_score;
      }else if(main_score>=10 && main_score<100){
        document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
        document.querySelector('.score_card_1').classList.add('score_card_10_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
        document.querySelector('.score_card_1').innerHTML=main_score;
      }else if(main_score>=100 && main_score<1000){
        document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
        document.querySelector('.score_card_1').classList.add('score_card_100_padding');
        document.querySelector('.score_card_1').innerHTML=main_score;
      }else if(main_score>=1000 && main_score<=10000){
        document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
        document.querySelector('.score_card_1').classList.add('score_card_1000_padding');
        document.querySelector('.score_card_1').innerHTML=main_score;
      }else if(main_score>=10000 && main_score<=100000){
        document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_1000_padding');
        document.querySelector('.score_card_1').classList.add('score_card_10000_padding');
        document.querySelector('.score_card_1').innerHTML=main_score;
  
      }
      
    
   var cash3= document.querySelector('.players_cash').innerHTML=''+'$'+main_score;
  var cash4=  document.querySelector('.players_cash_1').innerHTML=' '+'$'+main_score;
 
    var seventh_letter=document.querySelector('.write_box_6_6').childNodes[11].innerHTML="x";
  
    

    

    
    
    }
     
  } if(charac_6===letter_6_6){
     
    var cash_6_6= Math.round((.16 * questionCash));
    var cash_6_6_minus=0;
    var total_6_percent_6=1;
    gsap.timeline().from(".box_6_6",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1.6,onStart:correctLetterTone_6});
    document.querySelector('.box_6_6').classList.add('border_green');
    var seventh_letter=document.querySelector('.write_box_6_6').childNodes[11].innerHTML=charac_6;
    } 
   
   }if(cash_6_1 && cash_6_2 && cash_6_3 && cash_6_4 && cash_6_5 && cash_6_6){
       totalQuestionCash6=(cash_6_1 + cash_6_2 + cash_6_3 + cash_6_4 + cash_6_5 + cash_6_6 );
       percentage_6_plus=(total_6_percent_1 + total_6_percent_2 + total_6_percent_3 + total_6_percent_4 + total_6_percent_5 + total_6_percent_6);  
       audiencePlusTone();
       gsap.timeline().from(".points",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:2.8});
           gsap.timeline().to(".points",{duration:1,opacity:1,scale:0,x:0,ease:"back",delay:2.8,onStart:playMoneyTone});
       
       letter_total=6;
       letter_count=letter_total+letter_count;
       
    total_percent =total_percent+percentage_6_plus;
    var percent_total=document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100);
    if(percent_total===0 || percent_total<10){
      document.querySelector('.score_card').classList.remove('percent_padding_100');
      document.querySelector('.score_card').classList.remove('percent_padding_10');
      
      document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
    }else if(percent_total>10 && percent_total<99){
      document.querySelector('.score_card').classList.add('percent_padding_10');
      document.querySelector('.score_card').classList.remove('percent_padding_100');
      
      document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
    }else if(percent_total===100){
      document.querySelector('.score_card').classList.add('percent_padding_100');
      document.querySelector('.score_card').classList.remove('percent_padding_10');
     
      document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
    }
       var total_score_6=totalQuestionCash6 + (totalQuestionCash6 * .5);
      final_6_cash_final= '$' + totalQuestionCash6;
      document.querySelector('.points').innerHTML= '$' +(totalQuestionCash6 + (totalQuestionCash6 * .5));
      document.querySelector('.points').classList.add('cash_green');
      
      main_score=Math.ceil(main_score+total_score_6);    
     
      if(main_score<=5){
       
        $(".cover ").show();
          $(".game_over ").show();
          document.querySelector('.start_over').addEventListener('click',function(){
            location.reload(true);
          });
      }if(main_score <10){
        document.querySelector('.score_card_1').classList.add('score_card_1_padding');
        document.querySelector('.score_card_1').innerHTML=main_score;
      }else if(main_score>=10 && main_score<100){
        document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
        document.querySelector('.score_card_1').classList.add('score_card_10_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
        document.querySelector('.score_card_1').innerHTML=main_score;
      }else if(main_score>=100 && main_score<1000){
        document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
        document.querySelector('.score_card_1').classList.add('score_card_100_padding');
        document.querySelector('.score_card_1').innerHTML=main_score;
      }else if(main_score>=1000 && main_score<=10000){
        document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
        document.querySelector('.score_card_1').classList.add('score_card_1000_padding');
        document.querySelector('.score_card_1').innerHTML=main_score;
      }else if(main_score>=10000 && main_score<=100000){
        document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_1000_padding');
        document.querySelector('.score_card_1').classList.add('score_card_10000_padding');
        document.querySelector('.score_card_1').innerHTML=main_score;
  
      }
       document.querySelector('.players_cash').innerHTML=''+'$'+main_score;
       document.querySelector('.players_cash_1').innerHTML=' '+'$'+main_score;
      
      var seventh_letter=document.querySelector('.write_box_6_6').childNodes[11].innerHTML=charac_6;

      findI();
  removeI();
  findM();
  removeM();
  findJ();
  removeJ();
  findW();
  removeW();
   }
  if(cash_6_1_minus || cash_6_2_minus || cash_6_3_minus || cash_6_4_minus || cash_6_5_minus && cash_6_6){
    cash_6_6=0; 
  total6cashMinus=(cash_6_1_minus+cash_6_2_minus+cash_6_3_minus+cash_6_4_minus+cash_6_5_minus+cash_6_6);
  percentage_6_minus=(total_6_percent_1 + total_6_percent_2 + total_6_percent_3 + total_6_percent_4 + total_6_percent_5 + total_6_percent_6);  
  
  
  
    audienceMinusTone();
    gsap.timeline().from(".points",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:2.7});
    gsap.timeline().to(".points",{duration:1,opacity:1,scale:0,x:0,ease:"back",delay:2.7,onStart:loseMoneyTone});

  
  

  
       
  letter_total=6;
  letter_count=letter_total+letter_count;
  
 total_percent =total_percent+percentage_6_minus;
 var percent_total=document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100);
    if(percent_total===0 || percent_total<=10){
      document.querySelector('.score_card').classList.remove('percent_padding_100');
      document.querySelector('.score_card').classList.remove('percent_padding_10');
      console.log('padding1-10');
      document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
    }else if(percent_total>=10 && percent_total<99){
      document.querySelector('.score_card').classList.add('percent_padding_10');
      document.querySelector('.score_card').classList.remove('percent_padding_100');
      console.log('padding10-100');
      document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
    }else if(percent_total===100){
      document.querySelector('.score_card').classList.add('percent_padding_100');
      document.querySelector('.score_card').classList.remove('percent_padding_10');
      console.log('padding100');
      document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
    }
    
  if(cash_6_6_minus){
    final_6_display=-+total6cashMinus+Math.round((.16 * questionCash));
    
  document.querySelector('.points').innerHTML='-'+ '$'+final_6_display;
    document.querySelector('.points').classList.add('cash_red');
  
    document.querySelector('.score_card_1').innerHTML=main_score;
    document.querySelector('.players_cash').innerHTML=''+'$'+main_score;
    document.querySelector('.players_cash_1').innerHTML=' '+'$'+main_score;
   

  }else if(!cash_6_6_minus){
    final_6_display=-+total6cashMinus;
    ;
  document.querySelector('.points').innerHTML='-'+ '$'+final_6_display;
    document.querySelector('.points').classList.add('cash_red');
  main_score= Math.ceil(main_score-final_6_display);
  
  if(main_score<=5){
    
    $(".cover ").show();
      $(".game_over ").show();
      document.querySelector('.start_over').addEventListener('click',function(){
        location.reload(true);
      });
  }if(main_score <10){
    document.querySelector('.score_card_1').classList.add('score_card_1_padding');
    document.querySelector('.score_card_1').innerHTML=main_score;
  }else if(main_score>=10 && main_score<100){
    document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
    document.querySelector('.score_card_1').classList.add('score_card_10_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
    document.querySelector('.score_card_1').innerHTML=main_score;
  }else if(main_score>=100 && main_score<1000){
    document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
    document.querySelector('.score_card_1').classList.add('score_card_100_padding');
    document.querySelector('.score_card_1').innerHTML=main_score;
  }else if(main_score>=1000 && main_score<=10000){
    document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
    document.querySelector('.score_card_1').classList.add('score_card_1000_padding');
    document.querySelector('.score_card_1').innerHTML=main_score;
  }else if(main_score>=10000 && main_score<=100000){
    document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_1000_padding');
    document.querySelector('.score_card_1').classList.add('score_card_10000_padding');
    document.querySelector('.score_card_1').innerHTML=main_score;

  }
    



  } 
   
      

document.querySelector('.players_cash').innerHTML=''+'$'+main_score;
document.querySelector('.players_cash_1').innerHTML=' '+'$'+main_score;
   

  



  
  

}else if(n===amount_of_letters&& n===7){
  isPaused=true;
  clock_pause();
  clearTimeout(timerId);
  gsap.to(".time_control", {duration: 5, x: 300, opacity: 0, scale: 0.5});
  gsap.to(".disappear", {duration: 3, x: 300, opacity: 0, scale: 0.5});
    if(charac_1===letter_7_1 ){
      var cash_7_1= Math.round((.14 * questionCash));
      var cash_7_1_minus= 0;
      var total_7_percent_1=1;
      gsap.timeline().from(".box_7_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
      document.querySelector('.box_7_1').classList.add('border_green');
      var first_letter=document.querySelector('.box_7_1').innerHTML=charac_1;
    findI();
    removeI();
    findM();
    removeM();
    findJ();
    removeJ();
    findW();
    removeW();
    
    } if(charac_1!=letter_7_1 ){
      var cash_7_1_minus=  -Math.round((.14 * questionCash));
      var cash_7_1= 0;
      var total_7_percent_1=0;
      
      gsap.timeline().from(".box_7_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:wrongLetterTone_1});
      gsap.timeline().from(".box_7_1",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
        document.querySelector('.box_7_1').classList.add('border_red');
        document.querySelector('.box_7_1').classList.add('cash_red');
        var first_letter=document.querySelector('.box_7_1').innerHTML='x';


      }});

      gsap.timeline().from(".box_7_1",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:.4,onStart:function(){
        document.querySelector('.box_7_1').innerHTML='';
        document.querySelector('.box_7_1').classList.add('border_red');
        document.querySelector('.box_7_1').classList.remove('cash_red');
        
        
        if(letter_7_1==='M'){
          document.querySelector('.box_7_1').classList.add('letter_m');
          var first_letter=document.querySelector('.box_7_1').innerHTML=letter_7_1;
        }else if(letter_7_1==='I'){
          document.querySelector('.box_7_1').classList.add('letter_i');
          var first_letter=document.querySelector('.box_7_1').innerHTML=letter_7_1;
        }else if(letter_7_1==='J'){
          document.querySelector('.box_7_1').classList.add('letter_j');
          var first_letter=document.querySelector('.box_7_1').innerHTML=letter_7_1;
        }else if(letter_7_1==='W'){
          document.querySelector('.box_7_1').classList.add('letter_w');
          var first_letter=document.querySelector('.box_7_1').innerHTML=letter_7_1;
        }else{
          var first_letter=document.querySelector('.box_7_1').innerHTML=letter_7_1;
        }


      }});
      
     
        
      
      
      
    } if(charac_2===letter_7_2 ){
      var cash_7_2= Math.round((.14 * questionCash));
      var cash_7_2_minus= 0;
      var total_7_percent_2=1;
      gsap.timeline().from(".box_7_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.4,onStart:correctLetterTone_2});
      document.querySelector('.box_7_2').classList.add('border_green');
      var second_letter=document.querySelector('.write_box_7_7').childNodes[3].innerHTML=charac_2;
    findI();
    removeI();
    findM();
    removeM();
    findJ();
    removeJ();
    findW();
    removeW();
      
  } if(charac_2!=letter_7_2 ){
      var cash_7_2_minus= -Math.round((.14 * questionCash));
      var cash_7_2=0;
      var total_7_percent_2=0;
      
      gsap.timeline().from(".box_7_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.4,onStart:wrongLetterTone_2});
      gsap.timeline().from(".box_7_2",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
        document.querySelector('.box_7_2').classList.add('border_red');
        document.querySelector('.box_7_2').classList.add('cash_red');
        var first_letter=document.querySelector('.box_7_2').innerHTML='x';


      }});

      gsap.timeline().from(".box_7_2",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:.7,onStart:function(){
        document.querySelector('.box_7_2').innerHTML='';
        document.querySelector('.box_7_2').classList.add('border_red');
        document.querySelector('.box_7_2').classList.remove('cash_red');
        
        if(letter_7_2==='M'){
          document.querySelector('.box_7_2').classList.add('letter_m');
          var first_letter=document.querySelector('.box_7_2').innerHTML=letter_7_2;
        }else if(letter_7_2==='I'){
          document.querySelector('.box_7_2').classList.add('letter_i');
          var first_letter=document.querySelector('.box_7_2').innerHTML=letter_7_2;
        }else if(letter_7_2==='J'){
          document.querySelector('.box_7_2').classList.add('letter_j');
          var first_letter=document.querySelector('.box_7_2').innerHTML=letter_7_2;
        }else if(letter_7_2==='W'){
          document.querySelector('.box_7_2').classList.add('letter_w');
          var first_letter=document.querySelector('.box_7_2').innerHTML=letter_7_2;
        }else{
          var first_letter=document.querySelector('.box_7_2').innerHTML=letter_7_2;
        }


      }});
    }if(charac_3===letter_7_3 ){
      var cash_7_3= Math.round((.14 * questionCash));
      var cash_7_3_minus= 0;
      var total_7_percent_3=1;
      gsap.timeline().from(".box_7_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.7,onStart:correctLetterTone_3});
      document.querySelector('.box_7_3').classList.add('border_green');
      var third_letter=document.querySelector('.write_box_7_7').childNodes[5].innerHTML=charac_3;
      findI();
      removeI();
      findM();
      removeM();
      findJ();
      removeJ();
      findW();
      removeW();
    } if(charac_3!=letter_7_3 ){
      var cash_7_3_minus= -Math.round((.14 * questionCash));
      var cash_7_3= 0;
      var total_7_percent_3=0;
      
      gsap.timeline().from(".box_7_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.7,onStart:wrongLetterTone_3});
      gsap.timeline().from(".box_7_3",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
        document.querySelector('.box_7_3').classList.add('border_red');
        document.querySelector('.box_7_3').classList.add('cash_red');
        var first_letter=document.querySelector('.box_7_3').innerHTML='x';


      }});

      gsap.timeline().from(".box_7_3",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1,onStart:function(){
        document.querySelector('.box_7_3').innerHTML='';
        document.querySelector('.box_7_3').classList.add('border_red');
        document.querySelector('.box_7_3').classList.remove('cash_red');
        if(letter_7_3==='M'){
          document.querySelector('.box_7_3').classList.add('letter_m');
          var first_letter=document.querySelector('.box_7_3').innerHTML=letter_7_3;
        }else if(letter_7_3==='I'){
          document.querySelector('.box_7_3').classList.add('letter_i');
          var first_letter=document.querySelector('.box_7_3').innerHTML=letter_7_3;
        }else if(letter_7_3==='J'){
          document.querySelector('.box_7_3').classList.add('letter_j');
          var first_letter=document.querySelector('.box_7_3').innerHTML=letter_7_3;
        }else if(letter_7_3==='W'){
          document.querySelector('.box_7_3').classList.add('letter_w');
          var first_letter=document.querySelector('.box_7_3').innerHTML=letter_7_3;
        }else{
          var first_letter=document.querySelector('.box_7_3').innerHTML=letter_7_3;
        }
        
        


      }});
      
    }if(charac_4===letter_7_4 ){
      var cash_7_4= Math.round((.14 * questionCash));
      var cash_7_4_minus=0;
      var total_7_percent_4=1;
      gsap.timeline().from(".box_7_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1,onStart:correctLetterTone_4});
      document.querySelector('.box_7_4').classList.add('border_green');
      var fourth_letter=document.querySelector('.write_box_7_7').childNodes[7].innerHTML=charac_4;
    findI();
    removeI();
    findM();
    removeM();
    findJ();
    removeJ();
    findW();
    removeW();
      
  } if(charac_4!=letter_7_4 ){
      var cash_7_4_minus= -Math.round((.14 * questionCash));
      var cash_7_4= 0;
      var total_7_percent_4=0;
      
      gsap.timeline().from(".box_7_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1,onStart:wrongLetterTone_4});
      gsap.timeline().from(".box_7_4",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
        document.querySelector('.box_7_4').classList.add('border_red');
        document.querySelector('.box_7_4').classList.add('cash_red');
        var first_letter=document.querySelector('.box_7_4').innerHTML='x';


      }});

      gsap.timeline().from(".box_7_4",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1.3,onStart:function(){
        document.querySelector('.box_7_4').innerHTML='';
        document.querySelector('.box_7_4').classList.add('border_red');
        document.querySelector('.box_7_4').classList.remove('cash_red');
        if(letter_7_4==='M'){
          document.querySelector('.box_7_4').classList.add('letter_m');
          var first_letter=document.querySelector('.box_7_4').innerHTML=letter_7_4;
        }else if(letter_7_4==='I'){
          document.querySelector('.box_7_4').classList.add('letter_i');
          var first_letter=document.querySelector('.box_7_4').innerHTML=letter_7_4;
        }else if(letter_7_4==='J'){
          document.querySelector('.box_7_4').classList.add('letter_j');
          var first_letter=document.querySelector('.box_7_4').innerHTML=letter_7_4;
        }else if(letter_7_4==='W'){
          document.querySelector('.box_7_4').classList.add('letter_w');
          var first_letter=document.querySelector('.box_7_4').innerHTML=letter_7_4;
        }else{
          var first_letter=document.querySelector('.box_7_4').innerHTML=letter_7_4;
        }
        
        


      }});
     
    }if(charac_5===letter_7_5 ){
      var cash_7_5= Math.round((.14 * questionCash));
      var cash_7_5_minus= 0;
      var total_7_percent_5=1;
      gsap.timeline().from(".box_7_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1.3,onStart:correctLetterTone_5});
      document.querySelector('.box_7_5').classList.add('border_green');
     var fifth_letter=document.querySelector('.box_7_5').innerHTML=charac_5;
    findI();
    removeI();
    findM();
    removeM();
    findJ();
    removeJ();
    findW();
    removeW();
      
  } if(charac_5!=letter_7_5 ){
      var cash_7_5_minus= -Math.round((.14 * questionCash));
      var cash_7_5=0;
      var total_7_percent_5=0;
      gsap.timeline().from(".box_7_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1.3,onStart:wrongLetterTone_5});
      gsap.timeline().from(".box_7_5",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
        document.querySelector('.box_7_5').classList.add('border_red');
        document.querySelector('.box_7_5').classList.add('cash_red');
        var first_letter=document.querySelector('.box_7_5').innerHTML='x';


      }});

      gsap.timeline().from(".box_7_5",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1.6,onStart:function(){
        document.querySelector('.box_7_5').innerHTML='';
        document.querySelector('.box_7_5').classList.add('border_red');
        document.querySelector('.box_7_5').classList.remove('cash_red');
      
        if(letter_7_5==='M'){
          document.querySelector('.box_7_5').classList.add('letter_m');
          var first_letter=document.querySelector('.box_7_5').innerHTML=letter_7_5;
        }else if(letter_7_5==='I'){
          document.querySelector('.box_7_5').classList.add('letter_i');
          var first_letter=document.querySelector('.box_7_5').innerHTML=letter_7_5;
        }else if(letter_7_5==='J'){
          document.querySelector('.box_7_5').classList.add('letter_j');
          var first_letter=document.querySelector('.box_7_5').innerHTML=letter_7_5;
        }else if(letter_7_5==='W'){
          document.querySelector('.box_7_3').classList.add('letter_w');
          var first_letter=document.querySelector('.box_7_5').innerHTML=letter_7_5;
        }else{
          var first_letter=document.querySelector('.box_7_5').innerHTML=letter_7_5;
        }


      }});
    }if(charac_6===letter_7_6 ){
      var cash_7_6= Math.round((.14 * questionCash));
      var cash_7_6_minus=0;
      var total_7_percent_6=1;
      gsap.timeline().from(".box_7_6",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1.6,onStart:correctLetterTone_6});
      document.querySelector('.box_7_6').classList.add('border_green');
      var sixth_letter=document.querySelector('.write_box_7_7').childNodes[11].innerHTML=charac_6;
      
    findI();
    removeI();
    findM();
    removeM();
    findJ();
    removeJ();
    findW();
    removeW();
     } if(charac_6!=letter_7_6 ){
      var cash_7_6_minus= -Math.round((.14 * questionCash));
      var cash_7_6=0;
      var total_7_percent_6=0;
      gsap.timeline().from(".box_7_6",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1.6,onStart:wrongLetterTone_6});
      gsap.timeline().from(".box_7_6",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
        document.querySelector('.box_7_6').classList.add('border_red');
        document.querySelector('.box_7_6').classList.add('cash_red');
        var first_letter=document.querySelector('.box_7_6').innerHTML='x';


      }});

      gsap.timeline().from(".box_7_6",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:2,onStart:function(){
        document.querySelector('.box_7_6').innerHTML='';
        document.querySelector('.box_7_6').classList.add('border_red');
        document.querySelector('.box_7_6').classList.remove('cash_red');
        if(letter_7_6==='M'){
          document.querySelector('.box_7_6').classList.add('letter_m');
          var first_letter=document.querySelector('.box_7_6').innerHTML=letter_7_6;
        }else if(letter_7_6==='I'){
          document.querySelector('.box_7_6').classList.add('letter_i');
          var first_letter=document.querySelector('.box_7_6').innerHTML=letter_7_6;
        }else if(letter_7_6==='J'){
          document.querySelector('.box_7_6').classList.add('letter_j');
          var first_letter=document.querySelector('.box_7_6').innerHTML=letter_7_6;
        }else if(letter_7_6==='W'){
          document.querySelector('.box_7_6').classList.add('letter_w');
          var first_letter=document.querySelector('.box_7_6').innerHTML=letter_7_6;
        }else{
          var first_letter=document.querySelector('.box_7_6').innerHTML=letter_7_6;
        }
        


      }});
    }
    
    
    
    
    
    
    if(charac_7!=letter_7_7 ){
    var cash_7_7_minus= -Math.round((.14 * questionCash));
    var cash_7_7=0;
    var total_7_percent_7=0;
    gsap.timeline().from(".box_7_7",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:2,onStart:wrongLetterTone_7});
    gsap.timeline().from(".box_7_7",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_7_7').classList.add('border_red');
      document.querySelector('.box_7_7').classList.add('cash_red');
      var first_letter=document.querySelector('.box_7_7').innerHTML='x';


    }});

    gsap.timeline().from(".box_7_7",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:2.3,onStart:function(){
      document.querySelector('.box_7_7').innerHTML='';
      document.querySelector('.box_7_7').classList.add('border_red');
      document.querySelector('.box_7_7').classList.remove('cash_red');
      if(letter_7_7==='M'){
        document.querySelector('.box_7_7').classList.add('letter_m');
        var first_letter=document.querySelector('.box_7_7').innerHTML=letter_7_7;
      }else if(letter_7_7==='I'){
        document.querySelector('.box_7_7').classList.add('letter_i');
        var first_letter=document.querySelector('.box_7_7').innerHTML=letter_7_7;
      }else if(letter_7_7==='J'){
        document.querySelector('.box_7_7').classList.add('letter_j');
        var first_letter=document.querySelector('.box_7_7').innerHTML=letter_7_7;
      }else if(letter_7_7==='W'){
        document.querySelector('.box_7_7').classList.add('letter_w');
        var first_letter=document.querySelector('.box_7_7').innerHTML=letter_7_7;
      }else{
        var first_letter=document.querySelector('.box_7_7').innerHTML=letter_7_7;
      }
      


    }});
    
    
    if(cash_7_1_minus || cash_7_2_minus || cash_7_3_minus || cash_7_4_minus || cash_7_5_minus || cash_7_6_minus|| cash_7_7_minus ){
       total7cashMinus=(cash_7_1_minus+cash_7_2_minus+cash_7_3_minus+cash_7_4_minus+cash_7_5_minus+cash_7_6_minus + cash_7_7_minus);
      
       
    
      
      
      
     
      
        audienceMinusTone();
        gsap.timeline().from(".points",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:2.7});
        gsap.timeline().to(".points",{duration:1,opacity:1,scale:0,x:0,ease:"back",delay:2.7,onStart:loseMoneyTone});

      
        
  
      
      
       
      

     
      
    
    document.querySelector('.points').innerHTML=total7cashMinus;
      
      document.querySelector('.points').classList.add('cash_red');
    
      main_score= Math.ceil(main_score+total7cashMinus);
      
      
   
    if(main_score<=5){
      
      $(".cover ").show();
        $(".game_over ").show();
        document.querySelector('.start_over').addEventListener('click',function(){
          location.reload(true);
        });
    }if(main_score <10){
      document.querySelector('.score_card_1').classList.add('score_card_1_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;
    }else if(main_score>=10 && main_score<100){
      document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
      document.querySelector('.score_card_1').classList.add('score_card_10_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;
    }else if(main_score>=100 && main_score<1000){
      document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
      document.querySelector('.score_card_1').classList.add('score_card_100_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;
    }else if(main_score>=1000 && main_score<=10000){
      document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
      document.querySelector('.score_card_1').classList.add('score_card_1000_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;
    }else if(main_score>=10000 && main_score<=100000){
      document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_1000_padding');
      document.querySelector('.score_card_1').classList.add('score_card_10000_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;

    }
    
   var cash1= document.querySelector('.players_cash').innerHTML=' '+'$'+main_score;
   var cash2= document.querySelector('.players_cash_1').innerHTML=' '+'$'+main_score;
   
  
    var seventh_letter=document.querySelector('.write_box_7_7').childNodes[13].innerHTML="x";
  }
  
    
     
  } if(charac_7===letter_7_7 ){
    
     
    var cash_7_7= Math.round((.14 * questionCash));
    var cash_7_7_minus=0;
    var total_7_percent_7=1;
    gsap.timeline().from(".box_7_7",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1.9,onStart:correctLetterTone_7});
    document.querySelector('.box_7_7').classList.add('border_green');
    var seventh_letter=document.querySelector('.write_box_7_7').childNodes[13].innerHTML=charac_7;
    
  } 
   
   }if(cash_7_1 && cash_7_2 && cash_7_3 && cash_7_4 && cash_7_5 && cash_7_6 && cash_7_7 ){
       totalQuestionCash7=(cash_7_1 + cash_7_2 + cash_7_3 + cash_7_4 + cash_7_5 + cash_7_6 + cash_7_7);
       percentage_7_plus=(total_7_percent_1 + total_7_percent_2 + total_7_percent_3 + total_7_percent_4 + total_7_percent_5 + total_7_percent_6 + total_7_percent_7);  
       audiencePlusTone();
       gsap.timeline().from(".points",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:2.8});
           gsap.timeline().to(".points",{duration:1,opacity:1,scale:0,x:0,ease:"back",delay:2.8,onStart:playMoneyTone});
       
       letter_total=7;
       letter_count=letter_total+letter_count;
       
    total_percent =total_percent+percentage_7_plus;
    var percent_total=document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100);
    if(percent_total===0 || percent_total<10){
      document.querySelector('.score_card').classList.remove('percent_padding_100');
      document.querySelector('.score_card').classList.remove('percent_padding_10');
      
      document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
    }else if(percent_total>10 && percent_total<99){
      document.querySelector('.score_card').classList.add('percent_padding_10');
      document.querySelector('.score_card').classList.remove('percent_padding_100');
      
      document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
    }else if(percent_total===100){
      document.querySelector('.score_card').classList.add('percent_padding_100');
      document.querySelector('.score_card').classList.remove('percent_padding_10');
     
      document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
    }
      
       
       
       
       var total_score_7=totalQuestionCash7 + (totalQuestionCash7 *.5);
      final_7_cash_final= '$' + totalQuestionCash7;
      
     document.querySelector('.points').innerHTML= '$' + (totalQuestionCash7 +(totalQuestionCash7 *.5));
      document.querySelector('.points').classList.add('cash_green');
      
      main_score=Math.ceil(main_score+total_score_7);    
    
       
       if(main_score<=5){
       
        $(".cover ").show();
        $(".game_over ").show();
        document.querySelector('.start_over').addEventListener('click',function(){
          location.reload(true);
        });
      }if(main_score <10){
        document.querySelector('.score_card_1').classList.add('score_card_1_padding');
        document.querySelector('.score_card_1').innerHTML=main_score;
      }else if(main_score>=10 && main_score<100){
        document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
        document.querySelector('.score_card_1').classList.add('score_card_10_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
        document.querySelector('.score_card_1').innerHTML=main_score;
        
      }else if(main_score>=100 && main_score<1000){
        document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
        document.querySelector('.score_card_1').classList.add('score_card_100_padding');
        document.querySelector('.score_card_1').innerHTML=main_score;
        
      }else if(main_score>=1000 && main_score<=10000){
        document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
        document.querySelector('.score_card_1').classList.add('score_card_1000_padding');
        document.querySelector('.score_card_1').innerHTML=main_score;
  
      }else if(main_score>=10000 && main_score<=100000){
        document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_1000_padding');
        document.querySelector('.score_card_1').classList.add('score_card_10000_padding');
        document.querySelector('.score_card_1').innerHTML=main_score;
  
      }
     
       document.querySelector('.players_cash').innerHTML=' '+'$'+main_score;
       document.querySelector('.players_cash_1').innerHTML=' '+'$'+main_score;
      
      var seventh_letter=document.querySelector('.write_box_7_7').childNodes[13].innerHTML=charac_7;

      findI();
  removeI();
  findM();
  removeM();
  findJ();
  removeJ();
  findW();
  removeW();
   }

  


  
   if(cash_7_1_minus || cash_7_2_minus || cash_7_3_minus || cash_7_4_minus || cash_7_5_minus || cash_7_6_minus && cash_7_7){
    cash_7_7=0; 
  total7cashMinus=(cash_7_1_minus+cash_7_2_minus+cash_7_3_minus+cash_7_4_minus+cash_7_5_minus+cash_7_6_minus+cash_7_7);
  percentage_7_minus=(total_7_percent_1 + total_7_percent_2 + total_7_percent_3 + total_7_percent_4 + total_7_percent_5 + total_7_percent_6 + total_7_percent_7  );  
  
  
  
    audienceMinusTone();
    gsap.timeline().from(".points",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:2.7});
    gsap.timeline().to(".points",{duration:1,opacity:1,scale:0,x:0,ease:"back",delay:2.7,onStart:loseMoneyTone});

  
  

  
     
     letter_total=7;
     letter_count=letter_total+letter_count;
     console.log(letter_count);
  total_percent =total_percent+percentage_7_minus;
  var percent_total=document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100);
  if(percent_total===0 || percent_total<10){
    document.querySelector('.score_card').classList.remove('percent_padding_100');
    document.querySelector('.score_card').classList.remove('percent_padding_10');
    console.log('padding1-10');
    document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
  }else if(percent_total>10 && percent_total<99){
    document.querySelector('.score_card').classList.add('percent_padding_10');
    document.querySelector('.score_card').classList.remove('percent_padding_100');
    console.log('padding10-100');
    document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
  }else if(percent_total===100){
    document.querySelector('.score_card').classList.add('percent_padding_100');
    document.querySelector('.score_card').classList.remove('percent_padding_10');
    console.log('padding100');
    document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
  }
    
  if(cash_7_7_minus){
    final_7_display=-+total7cashMinus+Math.round((.14 * questionCash));
    document.querySelector('.points').innerHTML='-'+ '$'+final_7_display;
    document.querySelector('.points').classList.add('cash_red');
    document.querySelector('.score_card_1').innerHTML=main_score;
    document.querySelector('.players_cash').innerHTML=''+'$'+main_score;
    document.querySelector('.players_cash_1').innerHTML=' '+'$'+main_score;
   

  }else if(!cash_7_7_minus){
    final_7_display=-+total7cashMinus;
    document.querySelector('.points').innerHTML='-'+ '$'+final_7_display;
    document.querySelector('.points').classList.add('cash_red');
    main_score= Math.ceil(main_score-final_7_display);
  if(main_score<=5){
    console.log('game over');
    $(".cover ").show();
      $(".game_over ").show();
      document.querySelector('.start_over').addEventListener('click',function(){
        location.reload(true);
      });
  }if(main_score <10){
    document.querySelector('.score_card_1').classList.add('score_card_1_padding');
    document.querySelector('.score_card_1').innerHTML=main_score;
  }else if(main_score>=10 && main_score<100){
    document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
    document.querySelector('.score_card_1').classList.add('score_card_10_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
    document.querySelector('.score_card_1').innerHTML=main_score;
  }else if(main_score>=100 && main_score<1000){
    document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
    document.querySelector('.score_card_1').classList.add('score_card_100_padding');
    document.querySelector('.score_card_1').innerHTML=main_score;
  }else if(main_score>=1000 && main_score<=10000){
    document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
    document.querySelector('.score_card_1').classList.add('score_card_1000_padding');
    document.querySelector('.score_card_1').innerHTML=main_score;
  }else if(main_score>=10000 && main_score<=100000){
    document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_1000_padding');
    document.querySelector('.score_card_1').classList.add('score_card_10000_padding');
    document.querySelector('.score_card_1').innerHTML=main_score;

  }
    
    



  } 
   
      

document.querySelector('.players_cash').innerHTML=''+'$'+main_score;
document.querySelector('.players_cash_1').innerHTML=' '+'$'+main_score;

if(cash_7_7){
  document.querySelector('.write_box_7-7').childNodes[9].innerHTML=charac_5;
}else if(cash_7_7_minus){
  
  var seventh_letter=document.querySelector('.write_box_7_7').childNodes[9].innerHTML="x";
}
  

  


  
  
}else if(n===amount_of_letters && n===8){
  isPaused=true;
  clock_pause();
  clearTimeout(timerId);
  gsap.to(".time_control", {duration: 3, x: 300, opacity: 0, scale: 0.5});
  gsap.to(".disappear", {duration: 3, x: 300, opacity: 0, scale: 0.5});
  if(charac_1===letter_8_1){
    var cash_8_1= Math.round((.12 * questionCash));
    var cash_8_1_minus=0;
    var total_8_percent_1=1;
    gsap.timeline().from(".box_8_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
    document.querySelector('.box_8_1').classList.add('border_green');
    var first_letter=document.querySelector('.write_box_8_8').childNodes[1].innerHTML=charac_1;
  findI();
  removeI();
  findM();
  removeM();
  findJ();
  removeJ();
  findW();
  removeW();
   
    
  }if(charac_1!=letter_8_1){
    var cash_8_1_minus= -Math.round((.12 * questionCash));
    var cash_8_1=0;
    var total_8_percent_1=0;
    gsap.timeline().from(".box_8_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:wrongLetterTone_1});
    gsap.timeline().from(".box_8_1",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_8_1').classList.add('border_red');
      document.querySelector('.box_8_1').classList.add('cash_red');
      var first_letter=document.querySelector('.box_8_1').innerHTML='x';


    }});

    gsap.timeline().from(".box_8_1",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:.4,onStart:function(){
      document.querySelector('.box_8_1').innerHTML='';
      document.querySelector('.box_8_1').classList.add('border_red');
      document.querySelector('.box_8_1').classList.remove('cash_red');
      if(letter_8_1==='M'){
        document.querySelector('.box_8_1').classList.add('letter_m');
        var first_letter=document.querySelector('.box_8_1').innerHTML=letter_8_1;
      }else if(letter_8_1==='I'){
        document.querySelector('.box_8_1').classList.add('letter_i');
        var first_letter=document.querySelector('.box_8_1').innerHTML=letter_8_1;
      }else if(letter_8_1==='J'){
        document.querySelector('.box_8_1').classList.add('letter_j');
        var first_letter=document.querySelector('.box_8_1').innerHTML=letter_8_1;
      }else if(letter_8_1==='W'){
        document.querySelector('.box_8_1').classList.add('letter_w');
        var first_letter=document.querySelector('.box_8_1').innerHTML=letter_8_1;
      }else{
        var first_letter=document.querySelector('.box_8_1').innerHTML=letter_8_1;
      }
      


    }});
  }if(charac_2===letter_8_2){
    var cash_8_2= Math.round((.12 * questionCash));
    var cash_8_2_minus=0;
    var total_8_percent_2=1;
    gsap.timeline().from(".box_8_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.4,onStart:correctLetterTone_2});
    document.querySelector('.box_8_2').classList.add('border_green');
    var second_letter=document.querySelector('.write_box_8_8').childNodes[3].innerHTML=charac_2;
  findI();
  removeI();
  findM();
  removeM();
  findJ();
  removeJ();
  findW();
  removeW();
  }if(charac_2!=letter_8_2){
    var cash_8_2_minus= -Math.round((.12 * questionCash));
    var cash_8_2=0;
    var total_8_percent_2=0;
    gsap.timeline().from(".box_8_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.4,onStart:wrongLetterTone_2});
    gsap.timeline().from(".box_8_2",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_8_2').classList.add('border_red');
      document.querySelector('.box_8_2').classList.add('cash_red');
      var first_letter=document.querySelector('.box_8_2').innerHTML='x';


    }});

    gsap.timeline().from(".box_8_2",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:.7,onStart:function(){
      document.querySelector('.box_8_2').innerHTML='';
      document.querySelector('.box_8_2').classList.add('border_red');
      document.querySelector('.box_8_2').classList.remove('cash_red');
      if(letter_8_2==='M'){
        document.querySelector('.box_8_2').classList.add('letter_m');
        var first_letter=document.querySelector('.box_8_2').innerHTML=letter_8_2;
      }else if(letter_8_2==='I'){
        document.querySelector('.box_8_2').classList.add('letter_i');
        var first_letter=document.querySelector('.box_8_2').innerHTML=letter_8_2;
      }else if(letter_8_2==='J'){
        document.querySelector('.box_8_2').classList.add('letter_j');
        var first_letter=document.querySelector('.box_8_2').innerHTML=letter_8_2;
      }else if(letter_8_2==='W'){
        document.querySelector('.box_8_2').classList.add('letter_w');
        var first_letter=document.querySelector('.box_8_2').innerHTML=letter_8_2;
      }else{
        var first_letter=document.querySelector('.box_8_2').innerHTML=letter_8_2;
      }
      


    }});
  }if(charac_3===letter_8_3){
    var cash_8_3= Math.round((.12 * questionCash));
    var cash_8_3_minus=0;
    var total_8_percent_3=1;
    gsap.timeline().from(".box_8_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.7,onStart:correctLetterTone_3});
    document.querySelector('.box_8_3').classList.add('border_green');
    var third_letter=document.querySelector('.write_box_8_8').childNodes[5].innerHTML=charac_3;
  findI();
  removeI();
  findM();
  removeM();
  findJ();
  removeJ();
  findW();
  removeW();
  }if(charac_3!=letter_8_3){
    var cash_8_3_minus= -Math.round((.12 * questionCash));
    var cash_8_3=0;
    var total_8_percent_3=0;
    gsap.timeline().from(".box_8_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.7,onStart:wrongLetterTone_3});
    gsap.timeline().from(".box_8_3",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_8_3').classList.add('border_red');
      document.querySelector('.box_8_3').classList.add('cash_red');
      var first_letter=document.querySelector('.box_8_3').innerHTML='x';


    }});

    gsap.timeline().from(".box_8_3",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1,onStart:function(){
      document.querySelector('.box_8_3').innerHTML='';
      document.querySelector('.box_8_3').classList.add('border_red');
      document.querySelector('.box_8_3').classList.remove('cash_red');
      if(letter_8_3==='M'){
        document.querySelector('.box_8_3').classList.add('letter_m');
        var first_letter=document.querySelector('.box_8_3').innerHTML=letter_8_3;
      }else if(letter_8_3==='I'){
        document.querySelector('.box_8_3').classList.add('letter_i');
        var first_letter=document.querySelector('.box_8_3').innerHTML=letter_8_3;
      }else if(letter_8_3==='J'){
        document.querySelector('.box_8_3').classList.add('letter_j');
        var first_letter=document.querySelector('.box_8_1').innerHTML=letter_8_3;
      }else if(letter_8_3==='W'){
        document.querySelector('.box_8_3').classList.add('letter_w');
        var first_letter=document.querySelector('.box_8_3').innerHTML=letter_8_3;
      }else{
        var first_letter=document.querySelector('.box_8_3').innerHTML=letter_8_3;
      }
      


    }});
    
  }if(charac_4===letter_8_4){
    var cash_8_4= Math.round((.12 * questionCash));
    var cash_8_4_minus=0;
    var total_8_percent_4=1;
    gsap.timeline().from(".box_8_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1,onStart:correctLetterTone_4});
    document.querySelector('.box_8_4').classList.add('border_green');
    var fourth_letter=document.querySelector('.write_box_8_8').childNodes[7].innerHTML=charac_4;
  findI();
  removeI();
  findM();
  removeM();
  findJ();
  removeJ();
  findW();
  removeW();
  }if(charac_4!=letter_8_4){
    var cash_8_4_minus= -Math.round((.12 * questionCash));
    var cash_8_4=0;
    var total_8_percent_4=0;
    gsap.timeline().from(".box_8_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1,onStart:wrongLetterTone_4});
    gsap.timeline().from(".box_8_4",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_8_4').classList.add('border_red');
      document.querySelector('.box_8_4').classList.add('cash_red');
      var first_letter=document.querySelector('.box_8_4').innerHTML='x';


    }});

    gsap.timeline().from(".box_8_4",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1.3,onStart:function(){
      document.querySelector('.box_8_4').innerHTML='';
      document.querySelector('.box_8_4').classList.add('border_red');
      document.querySelector('.box_8_4').classList.remove('cash_red');
      if(letter_8_4==='M'){
        document.querySelector('.box_8_4').classList.add('letter_m');
        var first_letter=document.querySelector('.box_8_4').innerHTML=letter_8_4;
      }else if(letter_8_4==='I'){
        document.querySelector('.box_8_4').classList.add('letter_i');
        var first_letter=document.querySelector('.box_8_4').innerHTML=letter_8_4;
      }else if(letter_8_4==='J'){
        document.querySelector('.box_8_4').classList.add('letter_j');
        var first_letter=document.querySelector('.box_8_4').innerHTML=letter_8_4;
      }else if(letter_8_4==='W'){
        document.querySelector('.box_8_4').classList.add('letter_w');
        var first_letter=document.querySelector('.box_8_4').innerHTML=letter_8_4;
      }else{
        var first_letter=document.querySelector('.box_8_4').innerHTML=letter_8_4;
      }
      


    }});
 
  }if(charac_5===letter_8_5){
    var cash_8_5= Math.round((.12 * questionCash));
    var cash_8_5_minus=0;
    var total_8_percent_5=1;
    gsap.timeline().from(".box_8_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1.3,onStart:correctLetterTone_5});
    document.querySelector('.box_8_5').classList.add('border_green');
    var fifth_letter=document.querySelector('.write_box_8_8').childNodes[9].innerHTML=charac_5;
  findI();
  removeI();
  findM();
  removeM();
  findJ();
  removeJ();
  findW();
  removeW();
  }if(charac_5!=letter_8_5){
    var cash_8_5_minus= -Math.round((.12 * questionCash));
    var cash_8_5=0;
    var total_8_percent_5=0;
    gsap.timeline().from(".box_8_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1.3,onStart:wrongLetterTone_5});
    gsap.timeline().from(".box_8_5",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_8_5').classList.add('border_red');
      document.querySelector('.box_8_5').classList.add('cash_red');
      var first_letter=document.querySelector('.box_8_5').innerHTML='x';


    }});

    gsap.timeline().from(".box_8_5",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1.6,onStart:function(){
      document.querySelector('.box_8_5').innerHTML='';
      document.querySelector('.box_8_5').classList.add('border_red');
      document.querySelector('.box_8_5').classList.remove('cash_red');
      if(letter_8_5==='M'){
        document.querySelector('.box_8_5').classList.add('letter_m');
        var first_letter=document.querySelector('.box_8_5').innerHTML=letter_8_5;
      }else if(letter_8_5==='I'){
        document.querySelector('.box_8_5').classList.add('letter_i');
        var first_letter=document.querySelector('.box_8_5').innerHTML=letter_8_5;
      }else if(letter_8_5==='J'){
        document.querySelector('.box_8_5').classList.add('letter_j');
        var first_letter=document.querySelector('.box_8_5').innerHTML=letter_8_5;
      }else if(letter_8_5==='W'){
        document.querySelector('.box_8_5').classList.add('letter_w');
        var first_letter=document.querySelector('.box_8_5').innerHTML=letter_8_5;
      }else{
        var first_letter=document.querySelector('.box_8_5').innerHTML=letter_8_5;
      }
      


    }});
    
  }if(charac_6===letter_8_6){
    var cash_8_6= Math.round((.12 * questionCash));
    var cash_8_6_minus=0;
    var total_8_percent_6=1;
    gsap.timeline().from(".box_8_6",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1.6,onStart:correctLetterTone_6});
    document.querySelector('.box_8_6').classList.add('border_green');
    var sixth_letter=document.querySelector('.box_8_6').innerHTML=charac_6;
  findI();
  removeI();
  findM();
  removeM();
  findJ();
  removeJ();
  findW();
  removeW();
   
 }if(charac_6!=letter_8_6){
  var cash_8_6_minus= -Math.round((.12 * questionCash));
  var cash_8_6=0;
  var total_8_percent_6=0;
  gsap.timeline().from(".box_8_6",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1.6,onStart:wrongLetterTone_6});
  gsap.timeline().from(".box_8_6",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
    document.querySelector('.box_8_6').classList.add('border_red');
    document.querySelector('.box_8_6').classList.add('cash_red');
    var first_letter=document.querySelector('.box_8_6').innerHTML='x';


  }});

  gsap.timeline().from(".box_8_6",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:2,onStart:function(){
    document.querySelector('.box_8_6').innerHTML='';
    document.querySelector('.box_8_6').classList.add('border_red');
    document.querySelector('.box_8_6').classList.remove('cash_red');
    if(letter_8_6==='M'){
      document.querySelector('.box_8_6').classList.add('letter_m');
      var first_letter=document.querySelector('.box_8_6').innerHTML=letter_8_6;
    }else if(letter_8_6==='I'){
      document.querySelector('.box_8_6').classList.add('letter_i');
      var first_letter=document.querySelector('.box_8_6').innerHTML=letter_8_6;
    }else if(letter_8_6==='J'){
      document.querySelector('.box_8_6').classList.add('letter_j');
      var first_letter=document.querySelector('.box_8_6').innerHTML=letter_8_6;
    }else if(letter_8_6==='W'){
      document.querySelector('.box_8_6').classList.add('letter_w');
      var first_letter=document.querySelector('.box_8_6').innerHTML=letter_8_6;
    }else{
      var first_letter=document.querySelector('.box_8_6').innerHTML=letter_8_6;
    }
    


  }});
  
}if(charac_7===letter_8_7){
  var cash_8_7= Math.round((.12 * questionCash));
  var cash_8_7_minus=0;
  var total_8_percent_7=1;
  gsap.timeline().from(".box_8_7",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:2,onStart:correctLetterTone_7});
  document.querySelector('.box_8_7').classList.add('border_green');
  var seventh_letter=document.querySelector('.box_8_7').innerHTML=charac_7;
findI();
removeI();
findM();
removeM();
findJ();
removeJ();
findW();
removeW();
}if(charac_7!=letter_8_7){
  var cash_8_7_minus= -Math.round((.12 * questionCash));
  var cash_8_7=0;
  var total_8_percent_7=0;
  gsap.timeline().from(".box_8_7",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:2,onStart:wrongLetterTone_7});
  gsap.timeline().from(".box_8_7",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
    document.querySelector('.box_8_7').classList.add('border_red');
    document.querySelector('.box_8_7').classList.add('cash_red');
    var first_letter=document.querySelector('.box_8_7').innerHTML='x';


  }});

  gsap.timeline().from(".box_8_7",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:2.3,onStart:function(){
    document.querySelector('.box_8_7').innerHTML='';
    document.querySelector('.box_8_7').classList.add('border_red');
    document.querySelector('.box_8_7').classList.remove('cash_red');
    if(letter_8_7==='M'){
      document.querySelector('.box_8_7').classList.add('letter_m');
      var first_letter=document.querySelector('.box_8_7').innerHTML=letter_8_7;
    }else if(letter_8_7==='I'){
      document.querySelector('.box_8_7').classList.add('letter_i');
      var first_letter=document.querySelector('.box_8_7').innerHTML=letter_8_7;
    }else if(letter_8_7==='J'){
      document.querySelector('.box_8_7').classList.add('letter_j');
      var first_letter=document.querySelector('.box_8_7').innerHTML=letter_8_7;
    }else if(letter_8_7==='W'){
      document.querySelector('.box_8_7').classList.add('letter_w');
      var first_letter=document.querySelector('.box_8_7').innerHTML=letter_8_7;
    }else{
      var first_letter=document.querySelector('.box_8_7').innerHTML=letter_8_7;
    }
    


  }});


} if(charac_8!=letter_8_8 ){
  var cash_8_8_minus= -Math.round((.12 * questionCash));
  var cash_8_8=0;
  var total_8_percent_8=0;
  gsap.timeline().from(".box_8_8",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:2,onStart:wrongLetterTone_8});
  gsap.timeline().from(".box_8_8",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
    document.querySelector('.box_8_8').classList.add('border_red');
    document.querySelector('.box_8_8').classList.add('cash_red');
    var first_letter=document.querySelector('.box_8_8').innerHTML='x';


  }});

  gsap.timeline().from(".box_8_8",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:2.3,onStart:function(){
    document.querySelector('.box_8_8').innerHTML='';
    document.querySelector('.box_8_8').classList.add('border_red');
    document.querySelector('.box_8_8').classList.remove('cash_red');
    if(letter_8_8==='M'){
      document.querySelector('.box_8_8').classList.add('letter_m');
      var first_letter=document.querySelector('.box_8_8').innerHTML=letter_8_8;
    }else if(letter_8_8==='I'){
      document.querySelector('.box_8_8').classList.add('letter_i');
      var first_letter=document.querySelector('.box_8_8').innerHTML=letter_8_8;
    }else if(letter_8_8==='J'){
      document.querySelector('.box_8_8').classList.add('letter_j');
      var first_letter=document.querySelector('.box_8_8').innerHTML=letter_8_8;
    }else if(letter_8_8==='W'){
      document.querySelector('.box_8_8').classList.add('letter_w');
      var first_letter=document.querySelector('.box_8_8').innerHTML=letter_8_8;
    }else{
      var first_letter=document.querySelector('.box_8_8').innerHTML=letter_8_8;
    }
    


  }});
  
  
  if(cash_8_1_minus || cash_8_2_minus || cash_8_3_minus || cash_8_4_minus || cash_8_5_minus || cash_8_6_minus|| cash_8_7_minus || cash_8_8_minus ){
     total8cashMinus=(cash_8_1_minus+cash_8_2_minus+cash_8_3_minus+cash_8_4_minus+cash_8_5_minus+cash_8_6_minus + cash_8_7_minus + cash_8_8_minus );
    
     
  
    
    
    
   
    
      audienceMinusTone();
      gsap.timeline().from(".points",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:2.7});
      gsap.timeline().to(".points",{duration:1,opacity:1,scale:0,x:0,ease:"back",delay:2.7,onStart:loseMoneyTone});

    
      

    
    
     
    

   
    
  
  document.querySelector('.points').innerHTML=total8cashMinus;
    
    document.querySelector('.points').classList.add('cash_red');
  
    main_score= Math.ceil(main_score+total8cashMinus);
    console.log(main_score);
    
    
 
  if(main_score<=5){
    
    $(".cover ").show();
      $(".game_over ").show();
      document.querySelector('.start_over').addEventListener('click',function(){
        location.reload(true);
      });
  }if(main_score <10){
    document.querySelector('.score_card_1').classList.add('score_card_1_padding');
    document.querySelector('.score_card_1').innerHTML=main_score;
  }else if(main_score>=10 && main_score<100){
    document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
    document.querySelector('.score_card_1').classList.add('score_card_10_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
    document.querySelector('.score_card_1').innerHTML=main_score;
  }else if(main_score>=100 && main_score<1000){
    document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
    document.querySelector('.score_card_1').classList.add('score_card_100_padding');
    document.querySelector('.score_card_1').innerHTML=main_score;
  }else if(main_score>=1000 && main_score<=10000){
    document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
    document.querySelector('.score_card_1').classList.add('score_card_1000_padding');
    document.querySelector('.score_card_1').innerHTML=main_score;
  }else if(main_score>=10000 && main_score<=100000){
    document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_1000_padding');
    document.querySelector('.score_card_1').classList.add('score_card_10000_padding');
    document.querySelector('.score_card_1').innerHTML=main_score;

  }
  
 var cash1= document.querySelector('.players_cash').innerHTML=' '+'$'+main_score;
 var cash2= document.querySelector('.players_cash_1').innerHTML=' '+'$'+main_score;
 

  var seventh_letter=document.querySelector('.write_box_8_8').childNodes[15].innerHTML="x";
}

  
   
} if(charac_8===letter_8_8 ){
  
   
  var cash_8_8= Math.round((.12 * questionCash));
  var cash_8_8_minus=0;
  var total_8_percent_8=1;
  gsap.timeline().from(".box_8_8",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1.9,onStart:correctLetterTone_8});
  document.querySelector('.box_8_8').classList.add('border_green');
  var seventh_letter=document.querySelector('.write_box_8_8').childNodes[15].innerHTML=charac_8;
  
} 
 
 }if(cash_8_1 && cash_8_2 && cash_8_3 && cash_8_4 && cash_8_5 && cash_8_6 && cash_8_7 && cash_8_8 ){
     totalQuestionCash8=(cash_8_1 + cash_8_2 + cash_8_3 + cash_8_4 + cash_8_5 + cash_8_6 + cash_8_7 + cash_8_8);
     percentage_8_plus=(total_8_percent_1 + total_8_percent_2 + total_8_percent_3 + total_8_percent_4 + total_8_percent_5 + total_8_percent_6 + total_8_percent_7 + total_8_percent_8);  
     audiencePlusTone();
     gsap.timeline().from(".points",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:2.8});
         gsap.timeline().to(".points",{duration:1,opacity:1,scale:0,x:0,ease:"back",delay:2.8,onStart:playMoneyTone});
     
     letter_total=8;
     letter_count=letter_total+letter_count;
     
  total_percent =total_percent+percentage_8_plus;
  var percent_total=document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100);
  if(percent_total===0 || percent_total<10){
    document.querySelector('.score_card').classList.remove('percent_padding_100');
    document.querySelector('.score_card').classList.remove('percent_padding_10');
    
    document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
  }else if(percent_total>10 && percent_total<99){
    document.querySelector('.score_card').classList.add('percent_padding_10');
    document.querySelector('.score_card').classList.remove('percent_padding_100');
    
    document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
  }else if(percent_total===100){
    document.querySelector('.score_card').classList.add('percent_padding_100');
    document.querySelector('.score_card').classList.remove('percent_padding_10');
    
    document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
  }
    
     
     
     
     var total_score_8=totalQuestionCash8 + (totalQuestionCash8 *.5);
    final_8_cash_final= '$' + totalQuestionCash8;
    
   document.querySelector('.points').innerHTML= '$' + (totalQuestionCash8 +(totalQuestionCash8 *.5));
    document.querySelector('.points').classList.add('cash_green');
    
    main_score=Math.ceil(main_score+total_score_8);    
  
     
     if(main_score<=5){
     
      $(".cover ").show();
      $(".game_over ").show();
      document.querySelector('.start_over').addEventListener('click',function(){
        location.reload(true);
      });
    }if(main_score <10){
      document.querySelector('.score_card_1').classList.add('score_card_1_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;
    }else if(main_score>=10 && main_score<100){
      document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
      document.querySelector('.score_card_1').classList.add('score_card_10_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;
      
    }else if(main_score>=100 && main_score<1000){
      document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
      document.querySelector('.score_card_1').classList.add('score_card_100_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;
      
    }else if(main_score>=1000 && main_score<=10000){
      document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
      document.querySelector('.score_card_1').classList.add('score_card_1000_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;

    }else if(main_score>=10000 && main_score<=100000){
      document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_1000_padding');
      document.querySelector('.score_card_1').classList.add('score_card_10000_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;

    }
   
     document.querySelector('.players_cash').innerHTML=' '+'$'+main_score;
     document.querySelector('.players_cash_1').innerHTML=' '+'$'+main_score;
    
    var seventh_letter=document.querySelector('.write_box_8_8').childNodes[15].innerHTML=charac_8;

    findI();
removeI();
findM();
removeM();
findJ();
removeJ();
findW();
removeW();
 }





 if(cash_8_1_minus || cash_8_2_minus || cash_8_3_minus || cash_8_4_minus || cash_8_5_minus || cash_8_6_minus || cash_8_7_minus && cash_8_8){
  cash_8_8=0; 
total8cashMinus=(cash_8_1_minus+cash_8_2_minus+cash_8_3_minus+cash_8_4_minus+cash_8_5_minus+cash_8_6_minus+cash_8_7+cash_8_8);
percentage_8_minus=(total_8_percent_1 + total_8_percent_2 + total_8_percent_3 + total_8_percent_4 + total_8_percent_5 + total_8_percent_6 + total_8_percent_7 + total_8_percent_8 );  



  audienceMinusTone();
  gsap.timeline().from(".points",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:2.7});
  gsap.timeline().to(".points",{duration:1,opacity:1,scale:0,x:0,ease:"back",delay:2.7,onStart:loseMoneyTone});





   
   letter_total=8;
   letter_count=letter_total+letter_count;
   console.log(letter_count);
total_percent =total_percent+percentage_8_minus;
var percent_total=document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100);
if(percent_total===0 || percent_total<10){
  document.querySelector('.score_card').classList.remove('percent_padding_100');
  document.querySelector('.score_card').classList.remove('percent_padding_10');
  console.log('padding1-10');
  document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
}else if(percent_total>10 && percent_total<99){
  document.querySelector('.score_card').classList.add('percent_padding_10');
  document.querySelector('.score_card').classList.remove('percent_padding_100');
  console.log('padding10-100');
  document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
}else if(percent_total===100){
  document.querySelector('.score_card').classList.add('percent_padding_100');
  document.querySelector('.score_card').classList.remove('percent_padding_10');
  console.log('padding100');
  document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
}
  
if(cash_8_8_minus){
  final_8_display=-+total8cashMinus+Math.round((.12 * questionCash));
  document.querySelector('.points').innerHTML='-'+ '$'+final_8_display;
  document.querySelector('.points').classList.add('cash_red');
  document.querySelector('.score_card_1').innerHTML=main_score;
  document.querySelector('.players_cash').innerHTML=''+'$'+main_score;
  document.querySelector('.players_cash_1').innerHTML=' '+'$'+main_score;
 

}else if(!cash_8_8_minus){
  final_8_display=-+total8cashMinus;
  document.querySelector('.points').innerHTML='-'+ '$'+final_8_display;
  document.querySelector('.points').classList.add('cash_red');
  main_score= Math.ceil(main_score-final_8_display);
 
if(main_score<=5){
  console.log('game over');
  $(".cover ").show();
    $(".game_over ").show();
    document.querySelector('.start_over').addEventListener('click',function(){
      location.reload(true);
    });
}if(main_score <10){
  document.querySelector('.score_card_1').classList.add('score_card_1_padding');
  document.querySelector('.score_card_1').innerHTML=main_score;
}else if(main_score>=10 && main_score<100){
  document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
  document.querySelector('.score_card_1').classList.add('score_card_10_padding');
  document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
  document.querySelector('.score_card_1').innerHTML=main_score;
}else if(main_score>=100 && main_score<1000){
  document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
  document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
  document.querySelector('.score_card_1').classList.add('score_card_100_padding');
  document.querySelector('.score_card_1').innerHTML=main_score;
}else if(main_score>=1000 && main_score<=10000){
  document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
  document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
  document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
  document.querySelector('.score_card_1').classList.add('score_card_1000_padding');
  document.querySelector('.score_card_1').innerHTML=main_score;
}else if(main_score>=10000 && main_score<=100000){
  document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
  document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
  document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
  document.querySelector('.score_card_1').classList.remove('score_card_1000_padding');
  document.querySelector('.score_card_1').classList.add('score_card_10000_padding');
  document.querySelector('.score_card_1').innerHTML=main_score;

}
  
  



} 
 
    

document.querySelector('.players_cash').innerHTML=''+'$'+main_score;
document.querySelector('.players_cash_1').innerHTML=' '+'$'+main_score;
/*
if(cash_8_8){
document.querySelector('.write_box_8_8').childNodes[15].innerHTML=charac_8;
}else if(cash_7_7_minus){
*/
//var seventh_letter=document.querySelector('.write_box_7_7').childNodes[15].innerHTML="x";
}

 }











//choose a vowel(s) from each question
document.querySelector('.vowel_button').addEventListener('click',function(){
  var a_vowel=document.querySelector('.check_a');
  var o_vowel=document.querySelector('.check_o');
  var e_vowel=document.querySelector('.check_e');
  var i_vowel=document.querySelector('.check_i');
  var u_vowel=document.querySelector('.check_u');
  var a_letters=10;
  var i_letters=10;
  var e_letters=10;
  var o_letters=10;
  var u_letters=10;
  var totalVowels=[];

 

if(amount_of_letters===4 && a_vowel.checked){
  totalVowels.push(a_letters);
  document.querySelector('.score_card_1').innerHTML=main_score-(totalVowels.length*10);
  console.log(totalVowels);
  if(letter_4_1==='A'){
    
    gsap.timeline().from(".box_4_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
      document.querySelector('.box_4_1').classList.add('border_green');
      var first_letter=document.querySelector('.box_4_1').innerHTML=letter_4_1;
    
  }
if(letter_4_2==='A'){
      gsap.timeline().from(".box_4_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_2});
      document.querySelector('.box_4_2').classList.add('border_green');
      var first_letter=document.querySelector('.box_4_2').innerHTML=letter_4_2;
      
}if(letter_4_3==='A'){
  gsap.timeline().from(".box_4_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_3});
  document.querySelector('.box_4_3').classList.add('border_green');
  var first_letter=document.querySelector('.box_4_3').innerHTML=letter_4_3;


}if(letter_4_4==='A'){
  gsap.timeline().from(".box_4_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_4});
  document.querySelector('.box_4_4').classList.add('border_green');
  var first_letter=document.querySelector('.box_4_4').innerHTML=letter_4_4;

}
} if(amount_of_letters===4 && i_vowel.checked){
  totalVowels.push(i_letters);
  document.querySelector('.score_card_1').innerHTML=main_score-(totalVowels.length*10);
  console.log(totalVowels);
if(letter_4_1==='I'){
    
  gsap.timeline().from(".box_4_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
    document.querySelector('.box_4_1').classList.add('border_green');
    var first_letter=document.querySelector('.box_4_1').innerHTML=letter_4_1;
  document.querySelector('.box_4_1').classList.add('letter_i');
 
}
if(letter_4_2==='I'){
    gsap.timeline().from(".box_4_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_2});
    document.querySelector('.box_4_2').classList.add('border_green');
    var first_letter=document.querySelector('.box_4_2').innerHTML=letter_4_2;
    document.querySelector('.box_4_2').classList.add('letter_i');
   
}if(letter_4_3==='I'){
gsap.timeline().from(".box_4_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_3});
document.querySelector('.box_4_3').classList.add('border_green');
var first_letter=document.querySelector('.box_4_3').innerHTML=letter_4_3;
document.querySelector('.box_4_3').classList.add('letter_i');



}if(letter_4_4==='I'){
gsap.timeline().from(".box_4_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_4});
document.querySelector('.box_4_4').classList.add('border_green');
var first_letter=document.querySelector('.box_4_4').innerHTML=letter_4_4;
document.querySelector('.box_4_4').classList.add('letter_i');

}
   

}  if(amount_of_letters===4 && o_vowel.check){
  totalVowels.push(o_letters);
  document.querySelector('.score_card_1').innerHTML=main_score-(totalVowels.length*10);
  console.log(totalVowels);
if(letter_4_1==='O'){
    
  gsap.timeline().from(".box_4_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
    document.querySelector('.box_4_1').classList.add('border_green');
    var first_letter=document.querySelector('.box_4_1').innerHTML=letter_4_1;
  
 
}
if(letter_4_2==='O'){
    gsap.timeline().from(".box_4_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_2});
    document.querySelector('.box_4_2').classList.add('border_green');
    var first_letter=document.querySelector('.box_4_2').innerHTML=letter_4_2;
    
   
}if(letter_4_3==='O'){
gsap.timeline().from(".box_4_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_3});
document.querySelector('.box_4_3').classList.add('border_green');
var first_letter=document.querySelector('.box_4_3').innerHTML=letter_4_3;




}if(letter_4_4==='O'){
gsap.timeline().from(".box_4_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_4});
document.querySelector('.box_4_4').classList.add('border_green');
var first_letter=document.querySelector('.box_4_4').innerHTML=letter_4_4;


}
   

} if(amount_of_letters===4 && e_vowel.checked){
  totalVowels.push(e_letters);
  document.querySelector('.score_card_1').innerHTML=main_score-(totalVowels.length*10);
  console.log(totalVowels);
  
if(letter_4_1==='E'){
    
  gsap.timeline().from(".box_4_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
    document.querySelector('.box_4_1').classList.add('border_green');
    var first_letter=document.querySelector('.box_4_1').innerHTML=letter_4_1;
  
 
}
if(letter_4_2==='E'){
    gsap.timeline().from(".box_4_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_2});
    document.querySelector('.box_4_2').classList.add('border_green');
    var first_letter=document.querySelector('.box_4_2').innerHTML=letter_4_2;
    
   
}if(letter_4_3==='E'){
gsap.timeline().from(".box_4_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_3});
document.querySelector('.box_4_3').classList.add('border_green');
var first_letter=document.querySelector('.box_4_3').innerHTML=letter_4_3;




}if(letter_4_4==='E'){
gsap.timeline().from(".box_4_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_4});
document.querySelector('.box_4_4').classList.add('border_green');
var first_letter=document.querySelector('.box_4_4').innerHTML=letter_4_4;


}

}  if(amount_of_letters===4 && u_vowel.checked){
  totalVowels.push(u_letters);
  document.querySelector('.score_card_1').innerHTML=main_score-(totalVowels.length*10);
  console.log(totalVowels);
if(letter_4_1==='U'){
    
  gsap.timeline().from(".box_4_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
    document.querySelector('.box_4_1').classList.add('border_green');
    var first_letter=document.querySelector('.box_4_1').innerHTML=letter_4_1;
  
 
}
if(letter_4_2==='U'){
    gsap.timeline().from(".box_4_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_2});
    document.querySelector('.box_4_2').classList.add('border_green');
    var first_letter=document.querySelector('.box_4_2').innerHTML=letter_4_2;
    
   
}if(letter_4_3==='U'){
gsap.timeline().from(".box_4_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_3});
document.querySelector('.box_4_3').classList.add('border_green');
var first_letter=document.querySelector('.box_4_3').innerHTML=letter_4_3;




}if(letter_4_4==='U'){
gsap.timeline().from(".box_4_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_4});
document.querySelector('.box_4_4').classList.add('border_green');
var first_letter=document.querySelector('.box_4_4').innerHTML=letter_4_4;


}
}
else if(amount_of_letters===5 && a_vowel.checked){
  totalVowels.push(a_letters);
  document.querySelector('.score_card_1').innerHTML=main_score-(totalVowels.length*10);
  console.log(totalVowels);
  if(letter_5_1==='A'){
    
    gsap.timeline().from(".box_5_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
      document.querySelector('.box_5_1').classList.add('border_green');
      var first_letter=document.querySelector('.box_5_1').innerHTML=letter_5_1;
    
  }
if(letter_5_2==='A'){
      gsap.timeline().from(".box_5_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_2});
      document.querySelector('.box_5_2').classList.add('border_green');
      var first_letter=document.querySelector('.box_5_2').innerHTML=letter_5_2;
      
}if(letter_5_3==='A'){
  gsap.timeline().from(".box_5_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_3});
  document.querySelector('.box_5_3').classList.add('border_green');
  var first_letter=document.querySelector('.box_5_3').innerHTML=letter_5_3;


}if(letter_5_4==='A'){
  gsap.timeline().from(".box_5_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_4});
  document.querySelector('.box_5_4').classList.add('border_green');
  var first_letter=document.querySelector('.box_5_4').innerHTML=letter_5_4;

}if(letter_5_5==='A'){
  gsap.timeline().from(".box_5_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_5});
  document.querySelector('.box_5_5').classList.add('border_green');
  var first_letter=document.querySelector('.box_5_5').innerHTML=letter_5_5;

}
} if(amount_of_letters===5 && i_vowel.checked){
  totalVowels.push(i_letters);
  document.querySelector('.score_card_1').innerHTML=main_score-(totalVowels.length*10);
  console.log(totalVowels);
  
if(letter_5_1==='I'){
    
  gsap.timeline().from(".box_5_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
    document.querySelector('.box_5_1').classList.add('border_green');
    var first_letter=document.querySelector('.box_5_1').innerHTML=letter_5_1;
  document.querySelector('.box_5_1').classList.add('letter_i');
 
}
if(letter_5_2==='I'){
    gsap.timeline().from(".box_5_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_2});
    document.querySelector('.box_5_2').classList.add('border_green');
    var first_letter=document.querySelector('.box_5_2').innerHTML=letter_5_2;
    document.querySelector('.box_5_2').classList.add('letter_i');
   
}if(letter_5_3==='I'){
gsap.timeline().from(".box_5_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_3});
document.querySelector('.box_5_3').classList.add('border_green');
var first_letter=document.querySelector('.box_5_3').innerHTML=letter_5_3;
document.querySelector('.box_5_3').classList.add('letter_i');



}if(letter_5_4==='I'){
gsap.timeline().from(".box_5_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_4});
document.querySelector('.box_5_4').classList.add('border_green');
var first_letter=document.querySelector('.box_5_4').innerHTML=letter_5_4;
document.querySelector('.box_5_4').classList.add('letter_i');

}if(letter_5_5==='I'){
gsap.timeline().from(".box_5_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_5});
document.querySelector('.box_5_5').classList.add('border_green');
var first_letter=document.querySelector('.box_5_5').innerHTML=letter_5_5;
document.querySelector('.box_5_5').classList.add('letter_i');

}
   

}  if(amount_of_letters===5 && o_vowel.checked){
  totalVowels.push(o_letters);
  document.querySelector('.score_card_1').innerHTML=main_score-(totalVowels.length*10);
  console.log(totalVowels);
if(letter_5_1==='O'){
    
  gsap.timeline().from(".box_5_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
    document.querySelector('.box_5_1').classList.add('border_green');
    var first_letter=document.querySelector('.box_5_1').innerHTML=letter_5_1;
  
 
}
if(letter_5_2==='O'){
    gsap.timeline().from(".box_5_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_2});
    document.querySelector('.box_5_2').classList.add('border_green');
    var first_letter=document.querySelector('.box_5_2').innerHTML=letter_5_2;
    
   
}if(letter_5_3==='O'){
gsap.timeline().from(".box_5_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_3});
document.querySelector('.box_5_3').classList.add('border_green');
var first_letter=document.querySelector('.box_5_3').innerHTML=letter_5_3;




}if(letter_5_4==='O'){
gsap.timeline().from(".box_5_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_4});
document.querySelector('.box_5_4').classList.add('border_green');
var first_letter=document.querySelector('.box_5_4').innerHTML=letter_5_4;


}if(letter_5_5==='O'){
gsap.timeline().from(".box_5_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_5});
document.querySelector('.box_5_5').classList.add('border_green');
var first_letter=document.querySelector('.box_5_5').innerHTML=letter_5_5;


}
   

} if(amount_of_letters===5 && e_vowel.checked){
  totalVowels.push(e_letters);
  document.querySelector('.score_card_1').innerHTML=main_score-(totalVowels.length*10);
  console.log(totalVowels);
  
if(letter_5_1==='E'){
    
  gsap.timeline().from(".box_5_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
    document.querySelector('.box_5_1').classList.add('border_green');
    var first_letter=document.querySelector('.box_5_1').innerHTML=letter_5_1;
  
 
}
if(letter_5_2==='E'){
    gsap.timeline().from(".box_5_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_2});
    document.querySelector('.box_5_2').classList.add('border_green');
    var first_letter=document.querySelector('.box_5_2').innerHTML=letter_5_2;
    
   
}if(letter_5_3==='E'){
gsap.timeline().from(".box_5_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_3});
document.querySelector('.box_5_3').classList.add('border_green');
var first_letter=document.querySelector('.box_5_3').innerHTML=letter_5_3;




}if(letter_5_4==='E'){
gsap.timeline().from(".box_5_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_4});
document.querySelector('.box_5_4').classList.add('border_green');
var first_letter=document.querySelector('.box_5_4').innerHTML=letter_5_4;


}if(letter_5_5==='E'){
gsap.timeline().from(".box_5_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_5});
document.querySelector('.box_5_5').classList.add('border_green');
var first_letter=document.querySelector('.box_5_5').innerHTML=letter_5_5;


}

}  if(amount_of_letters===5 && u_vowel.checked){
  totalVowels.push(u_letters);
  document.querySelector('.score_card_1').innerHTML=main_score-(totalVowels.length*10);
  console.log(totalVowels);
if(letter_5_1==='U'){
    
  gsap.timeline().from(".box_5_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
    document.querySelector('.box_5_1').classList.add('border_green');
    var first_letter=document.querySelector('.box_5_1').innerHTML=letter_5_1;
  
 
}
if(letter_5_2==='U'){
    gsap.timeline().from(".box_5_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_2});
    document.querySelector('.box_5_2').classList.add('border_green');
    var first_letter=document.querySelector('.box_5_2').innerHTML=letter_5_2;
    
   
}if(letter_5_3==='U'){
gsap.timeline().from(".box_5_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_3});
document.querySelector('.box_5_3').classList.add('border_green');
var first_letter=document.querySelector('.box_5_3').innerHTML=letter_5_3;




}if(letter_5_4==='U'){
gsap.timeline().from(".box_5_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_4});
document.querySelector('.box_5_4').classList.add('border_green');
var first_letter=document.querySelector('.box_5_4').innerHTML=letter_5_4;


}if(letter_5_5==='U'){
gsap.timeline().from(".box_5_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_5});
document.querySelector('.box_5_5').classList.add('border_green');
var first_letter=document.querySelector('.box_5_5').innerHTML=letter_5_5;


}
}else if(amount_of_letters===6 && a_vowel.checked){
  totalVowels.push(a_letters);
  document.querySelector('.score_card_1').innerHTML=main_score-(totalVowels.length*10);
  console.log(totalVowels);
  if(letter_6_1==='A'){
    
    gsap.timeline().from(".box_6_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
      document.querySelector('.box_6_1').classList.add('border_green');
      var first_letter=document.querySelector('.box_6_1').innerHTML=letter_6_1;
    
  }
if(letter_6_2==='A'){
      gsap.timeline().from(".box_6_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_2});
      document.querySelector('.box_6_2').classList.add('border_green');
      var first_letter=document.querySelector('.box_6_2').innerHTML=letter_6_2;
      
}if(letter_6_3==='A'){
  gsap.timeline().from(".box_6_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_3});
  document.querySelector('.box_6_3').classList.add('border_green');
  var first_letter=document.querySelector('.box_6_3').innerHTML=letter_6_3;


}if(letter_6_4==='A'){
  gsap.timeline().from(".box_6_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_4});
  document.querySelector('.box_6_4').classList.add('border_green');
  var first_letter=document.querySelector('.box_6_4').innerHTML=letter_6_4;

}if(letter_6_5==='A'){
  gsap.timeline().from(".box_6_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_5});
  document.querySelector('.box_6_5').classList.add('border_green');
  var first_letter=document.querySelector('.box_6_5').innerHTML=letter_6_5;

}if(letter_6_6==='A'){

  gsap.timeline().from(".box_6_6",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_6});
  document.querySelector('.box_6_6').classList.add('border_green');
  var first_letter=document.querySelector('.box_6_6').innerHTML=letter_6_6;


}
} if(amount_of_letters===6&&i_vowel.checked){
  totalVowels.push(i_letters);
  document.querySelector('.score_card_1').innerHTML=main_score-(totalVowels.length*10);
  console.log(totalVowels);
if(letter_6_1==='I'){
    
  gsap.timeline().from(".box_6_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
    document.querySelector('.box_6_1').classList.add('border_green');
    var first_letter=document.querySelector('.box_6_1').innerHTML=letter_6_1;
  document.querySelector('.box_6_1').classList.add('letter_i');
 
}
if(letter_6_2==='I'){
    gsap.timeline().from(".box_6_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_2});
    document.querySelector('.box_6_2').classList.add('border_green');
    var first_letter=document.querySelector('.box_6_2').innerHTML=letter_6_2;
    document.querySelector('.box_6_2').classList.add('letter_i');
   
}if(letter_6_3==='I'){
gsap.timeline().from(".box_6_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_3});
document.querySelector('.box_6_3').classList.add('border_green');
var first_letter=document.querySelector('.box_6_3').innerHTML=letter_6_3;
document.querySelector('.box_6_3').classList.add('letter_i');



}if(letter_6_4==='I'){
gsap.timeline().from(".box_6_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_4});
document.querySelector('.box_6_4').classList.add('border_green');
var first_letter=document.querySelector('.box_6_4').innerHTML=letter_6_4;
document.querySelector('.box_6_4').classList.add('letter_i');

}if(letter_6_5==='I'){
gsap.timeline().from(".box_6_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_5});
document.querySelector('.box_6_5').classList.add('border_green');
var first_letter=document.querySelector('.box_6_5').innerHTML=letter_6_5;
document.querySelector('.box_6_5').classList.add('letter_i');

}if(letter_6_6==='I'){

gsap.timeline().from(".box_6_6",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_6});
document.querySelector('.box_6_6').classList.add('border_green');
var first_letter=document.querySelector('.box_6_6').innerHTML=letter_6_6;
document.querySelector('.box_6_6').classList.add('letter_i');


}
   

}  if(amount_of_letters===6 && o_vowel.checked){

  totalVowels.push(o_letters);
  document.querySelector('.score_card_1').innerHTML=main_score-(totalVowels.length*10);
  console.log(totalVowels);
if(letter_6_1==='O'){
  
    
  gsap.timeline().from(".box_6_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
    document.querySelector('.box_6_1').classList.add('border_green');
    var first_letter=document.querySelector('.box_6_1').innerHTML=letter_6_1;
  
 
}
if(letter_6_2==='O'){
    gsap.timeline().from(".box_6_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_2});
    document.querySelector('.box_6_2').classList.add('border_green');
    var first_letter=document.querySelector('.box_6_2').innerHTML=letter_6_2;
    
   
}if(letter_6_3==='O'){
gsap.timeline().from(".box_6_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_3});
document.querySelector('.box_6_3').classList.add('border_green');
var first_letter=document.querySelector('.box_6_3').innerHTML=letter_6_3;




}if(letter_6_4==='O'){
gsap.timeline().from(".box_6_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_4});
document.querySelector('.box_6_4').classList.add('border_green');
var first_letter=document.querySelector('.box_6_4').innerHTML=letter_6_4;


}if(letter_6_5==='O'){
gsap.timeline().from(".box_6_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_5});
document.querySelector('.box_6_5').classList.add('border_green');
var first_letter=document.querySelector('.box_6_5').innerHTML=letter_6_5;


}if(letter_6_6==='O'){

gsap.timeline().from(".box_6_6",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_6});
document.querySelector('.box_6_6').classList.add('border_green');
var first_letter=document.querySelector('.box_6_6').innerHTML=letter_6_6;



}
   

} if(amount_of_letters===6 && e_vowel.checked){
  totalVowels.push(e_letters);
  document.querySelector('.score_card_1').innerHTML=main_score-(totalVowels.length*10);
  console.log(totalVowels);
  
if(letter_6_1==='E'){
    
  gsap.timeline().from(".box_6_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
    document.querySelector('.box_6_1').classList.add('border_green');
    var first_letter=document.querySelector('.box_6_1').innerHTML=letter_6_1;
  
 
}
if(letter_6_2==='E'){
    gsap.timeline().from(".box_6_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_2});
    document.querySelector('.box_6_2').classList.add('border_green');
    var first_letter=document.querySelector('.box_6_2').innerHTML=letter_6_2;
    
   
}if(letter_6_3==='E'){
gsap.timeline().from(".box_6_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_3});
document.querySelector('.box_6_3').classList.add('border_green');
var first_letter=document.querySelector('.box_6_3').innerHTML=letter_6_3;




}if(letter_6_4==='E'){
gsap.timeline().from(".box_6_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_4});
document.querySelector('.box_6_4').classList.add('border_green');
var first_letter=document.querySelector('.box_6_4').innerHTML=letter_6_4;


}if(letter_6_5==='E'){
gsap.timeline().from(".box_6_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_5});
document.querySelector('.box_6_5').classList.add('border_green');
var first_letter=document.querySelector('.box_6_5').innerHTML=letter_6_5;


}if(letter_6_6==='E'){

gsap.timeline().from(".box_6_6",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_6});
document.querySelector('.box_6_6').classList.add('border_green');
var first_letter=document.querySelector('.box_6_6').innerHTML=letter_6_6;



}

}  if(amount_of_letters===6 && u_vowel.checked){
  totalVowels.push(u_letters);
  document.querySelector('.score_card_1').innerHTML=main_score-(totalVowels.length*10);
  console.log(totalVowels);
if(letter_6_1==='U'){
    
  gsap.timeline().from(".box_6_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
    document.querySelector('.box_6_1').classList.add('border_green');
    var first_letter=document.querySelector('.box_6_1').innerHTML=letter_6_1;
  
 
}
if(letter_6_2==='U'){
    gsap.timeline().from(".box_6_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_2});
    document.querySelector('.box_6_2').classList.add('border_green');
    var first_letter=document.querySelector('.box_6_2').innerHTML=letter_6_2;
    
   
}if(letter_6_3==='U'){
gsap.timeline().from(".box_6_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_3});
document.querySelector('.box_6_3').classList.add('border_green');
var first_letter=document.querySelector('.box_6_3').innerHTML=letter_6_3;




}if(letter_6_4==='U'){
gsap.timeline().from(".box_6_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_4});
document.querySelector('.box_6_4').classList.add('border_green');
var first_letter=document.querySelector('.box_6_4').innerHTML=letter_6_4;


}if(letter_6_5==='U'){
gsap.timeline().from(".box_6_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_5});
document.querySelector('.box_6_5').classList.add('border_green');
var first_letter=document.querySelector('.box_6_5').innerHTML=letter_6_5;


}if(letter_6_6==='U'){

gsap.timeline().from(".box_6_6",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_6});
document.querySelector('.box_6_6').classList.add('border_green');
var first_letter=document.querySelector('.box_6_6').innerHTML=letter_6_6;



}  
}else if(amount_of_letters===7 && a_vowel.checked){
  totalVowels.push(a_letters);
  document.querySelector('.score_card_1').innerHTML=main_score-(totalVowels.length*10);
  console.log(totalVowels);
  
  if(letter_7_1==='A'){
    document.querySelector('.score_card_1').innerHTML=main_score-10;
    gsap.timeline().from(".box_7_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
      document.querySelector('.box_7_1').classList.add('border_green');
      var first_letter=document.querySelector('.box_7_1').innerHTML=letter_7_1;
    
  }
if(letter_7_2==='A'){
      gsap.timeline().from(".box_7_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_2});
      document.querySelector('.box_7_2').classList.add('border_green');
      var first_letter=document.querySelector('.box_7_2').innerHTML=letter_7_2;
      
}if(letter_7_3==='A'){
  gsap.timeline().from(".box_7_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_3});
  document.querySelector('.box_7_3').classList.add('border_green');
  var first_letter=document.querySelector('.box_7_3').innerHTML=letter_7_3;


}if(letter_7_4==='A'){
  gsap.timeline().from(".box_7_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_4});
  document.querySelector('.box_7_4').classList.add('border_green');
  var first_letter=document.querySelector('.box_7_4').innerHTML=letter_7_4;

}if(letter_7_5==='A'){
  gsap.timeline().from(".box_7_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_5});
  document.querySelector('.box_7_5').classList.add('border_green');
  var first_letter=document.querySelector('.box_7_5').innerHTML=letter_7_5;

}if(letter_7_6==='A'){

  gsap.timeline().from(".box_7_6",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_6});
  document.querySelector('.box_7_6').classList.add('border_green');
  var first_letter=document.querySelector('.box_7_6').innerHTML=letter_7_6;


}if(letter_7_7==='A'){
  gsap.timeline().from(".box_7_7",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_7});
      document.querySelector('.box_7_7').classList.add('border_green');
      var first_letter=document.querySelector('.box_7_7').innerHTML=letter_7_7;
    
}
} if(amount_of_letters===7 && i_vowel.checked){
  totalVowels.push(i_letters);
  document.querySelector('.score_card_1').innerHTML=main_score-(totalVowels.length*10);
  console.log(totalVowels);
if(letter_7_1==='I'){
    
  gsap.timeline().from(".box_7_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
    document.querySelector('.box_7_1').classList.add('border_green');
    var first_letter=document.querySelector('.box_7_1').innerHTML=letter_7_1;
  document.querySelector('.box_7_1').classList.add('letter_i');
 
}
if(letter_7_2==='I'){
    gsap.timeline().from(".box_7_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_2});
    document.querySelector('.box_7_2').classList.add('border_green');
    var first_letter=document.querySelector('.box_7_1').innerHTML=letter_7_2;
    document.querySelector('.box_7_2').classList.add('letter_i');
   
}if(letter_7_3==='I'){
gsap.timeline().from(".box_7_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_3});
document.querySelector('.box_7_3').classList.add('border_green');
var first_letter=document.querySelector('.box_7_3').innerHTML=letter_7_3;
document.querySelector('.box_7_3').classList.add('letter_i');



}if(letter_7_4==='I'){
gsap.timeline().from(".box_7_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_4});
document.querySelector('.box_7_4').classList.add('border_green');
var first_letter=document.querySelector('.box_7_4').innerHTML=letter_7_4;
document.querySelector('.box_7_4').classList.add('letter_i');

}if(letter_7_5==='I'){
gsap.timeline().from(".box_7_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_5});
document.querySelector('.box_7_5').classList.add('border_green');
var first_letter=document.querySelector('.box_7_5').innerHTML=letter_7_5;
document.querySelector('.box_7_5').classList.add('letter_i');

}if(letter_7_6==='I'){

gsap.timeline().from(".box_7_6",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_6});
document.querySelector('.box_7_6').classList.add('border_green');
var first_letter=document.querySelector('.box_7_6').innerHTML=letter_7_6;
document.querySelector('.box_7_6').classList.add('letter_i');


}if(letter_7_7==='I'){
gsap.timeline().from(".box_7_7",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_7});
    document.querySelector('.box_7_7').classList.add('border_green');
    var first_letter=document.querySelector('.box_7_7').innerHTML=letter_7_7;
    document.querySelector('.box_7_7').classList.add('letter_i');
  
}
   

}  if(amount_of_letters===7 && o_vowel.checked){
  totalVowels.push(o_letters);
  document.querySelector('.score_card_1').innerHTML=main_score-(totalVowels.length*10);
  console.log(totalVowels);
  
if(letter_7_1==='O'){
    
  gsap.timeline().from(".box_7_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
    document.querySelector('.box_7_1').classList.add('border_green');
    var first_letter=document.querySelector('.box_7_1').innerHTML=letter_7_1;
  
 
}
if(letter_7_2==='O'){
    gsap.timeline().from(".box_7_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_2});
    document.querySelector('.box_7_2').classList.add('border_green');
    var first_letter=document.querySelector('.box_7_2').innerHTML=letter_7_2;
    
   
}if(letter_7_3==='O'){
gsap.timeline().from(".box_7_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_3});
document.querySelector('.box_7_3').classList.add('border_green');
var first_letter=document.querySelector('.box_7_3').innerHTML=letter_7_3;




}if(letter_7_4==='O'){
gsap.timeline().from(".box_7_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_4});
document.querySelector('.box_7_4').classList.add('border_green');
var first_letter=document.querySelector('.box_7_4').innerHTML=letter_7_4;


}if(letter_7_5==='O'){
gsap.timeline().from(".box_7_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_5});
document.querySelector('.box_7_5').classList.add('border_green');
var first_letter=document.querySelector('.box_7_5').innerHTML=letter_7_5;


}if(letter_7_6==='O'){

gsap.timeline().from(".box_7_6",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_6});
document.querySelector('.box_7_6').classList.add('border_green');
var first_letter=document.querySelector('.box_7_6').innerHTML=letter_7_6;



}if(letter_7_7==='O'){
gsap.timeline().from(".box_7_7",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_7});
    document.querySelector('.box_7_7').classList.add('border_green');
    var first_letter=document.querySelector('.box_7_7').innerHTML=letter_7_7;
   
  
}
   

} if(amount_of_letters===7 && e_vowel.checked){
  totalVowels.push(e_letters);
  document.querySelector('.score_card_1').innerHTML=main_score-(totalVowels.length*10);
  console.log(totalVowels);
  
if(letter_7_1==='E'){
  document.querySelector('.score_card_1').innerHTML=main_score-10;
  gsap.timeline().from(".box_7_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
    document.querySelector('.box_7_1').classList.add('border_green');
    var first_letter=document.querySelector('.box_7_1').innerHTML=letter_7_1;
  
 
}
if(letter_7_2==='E'){
    gsap.timeline().from(".box_7_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_2});
    document.querySelector('.box_7_2').classList.add('border_green');
    var first_letter=document.querySelector('.box_7_2').innerHTML=letter_7_2;
    
   
}if(letter_7_3==='E'){
gsap.timeline().from(".box_7_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_3});
document.querySelector('.box_7_3').classList.add('border_green');
var first_letter=document.querySelector('.box_7_3').innerHTML=letter_7_3;




}if(letter_7_4==='E'){
gsap.timeline().from(".box_7_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_4});
document.querySelector('.box_7_4').classList.add('border_green');
var first_letter=document.querySelector('.box_7_4').innerHTML=letter_7_4;


}if(letter_7_5==='E'){
gsap.timeline().from(".box_7_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_5});
document.querySelector('.box_7_5').classList.add('border_green');
var first_letter=document.querySelector('.box_7_5').innerHTML=letter_7_5;


}if(letter_7_6==='E'){

gsap.timeline().from(".box_7_6",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_6});
document.querySelector('.box_7_6').classList.add('border_green');
var first_letter=document.querySelector('.box_7_6').innerHTML=letter_7_6;



}if(letter_7_7==='E'){
gsap.timeline().from(".box_7_7",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_7});
    document.querySelector('.box_7_7').classList.add('border_green');
    var first_letter=document.querySelector('.box_7_7').innerHTML=letter_7_7;
   
}  

}  if(amount_of_letters===7 && u_vowel.checked){
  totalVowels.push(u_letters);
  document.querySelector('.score_card_1').innerHTML=main_score-(totalVowels.length*10);
  console.log(totalVowels);
  
if(letter_7_1==='U'){
    
  gsap.timeline().from(".box_7_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
    document.querySelector('.box_7_1').classList.add('border_green');
    var first_letter=document.querySelector('.box_7_1').innerHTML=letter_7_1;
  
 
}
if(letter_7_2==='U'){
    gsap.timeline().from(".box_7_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_2});
    document.querySelector('.box_7_2').classList.add('border_green');
    var first_letter=document.querySelector('.box_7_2').innerHTML=letter_7_2;
    
   
}if(letter_7_3==='U'){
gsap.timeline().from(".box_7_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_3});
document.querySelector('.box_7_3').classList.add('border_green');
var first_letter=document.querySelector('.box_7_3').innerHTML=letter_7_3;




}if(letter_7_4==='U'){
gsap.timeline().from(".box_7_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_4});
document.querySelector('.box_7_4').classList.add('border_green');
var first_letter=document.querySelector('.box_7_4').innerHTML=letter_7_4;


}if(letter_7_5==='U'){
gsap.timeline().from(".box_7_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_5});
document.querySelector('.box_7_5').classList.add('border_green');
var first_letter=document.querySelector('.box_7_5').innerHTML=letter_7_5;


}if(letter_7_6==='U'){

gsap.timeline().from(".box_7_6",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_6});
document.querySelector('.box_7_6').classList.add('border_green');
var first_letter=document.querySelector('.box_7_6').innerHTML=letter_7_6;



}if(letter_7_7==='U'){
gsap.timeline().from(".box_7_7",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_7});
    document.querySelector('.box_7_7').classList.add('border_green');
    var first_letter=document.querySelector('.box_7_7').innerHTML=letter_7_7;
   
}  
}  if(amount_of_letters===8 && a_vowel.checked){
  totalVowels.push(a_letters);
  document.querySelector('.score_card_1').innerHTML=main_score-(totalVowels.length*10);
  console.log(totalVowels);
  if(letter_8_1==='A'){
    
    gsap.timeline().from(".box_8_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
      document.querySelector('.box_8_1').classList.add('border_green');
      var first_letter=document.querySelector('.box_8_1').innerHTML=letter_8_1;
    
  }
if(letter_8_2==='A'){
      gsap.timeline().from(".box_8_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_2});
      document.querySelector('.box_8_2').classList.add('border_green');
      var first_letter=document.querySelector('.box_8_2').innerHTML=letter_8_2;
      
}if(letter_8_3==='A'){
  gsap.timeline().from(".box_8_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_3});
  document.querySelector('.box_8_3').classList.add('border_green');
  var first_letter=document.querySelector('.box_8_3').innerHTML=letter_8_3;


}if(letter_8_4==='A'){
  gsap.timeline().from(".box_8_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_4});
  document.querySelector('.box_8_4').classList.add('border_green');
  var first_letter=document.querySelector('.box_8_4').innerHTML=letter_8_4;

}if(letter_8_5==='A'){
  gsap.timeline().from(".box_8_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_5});
  document.querySelector('.box_8_5').classList.add('border_green');
  var first_letter=document.querySelector('.box_8_5').innerHTML=letter_8_5;

}if(letter_8_6==='A'){

  gsap.timeline().from(".box_8_6",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_6});
  document.querySelector('.box_8_6').classList.add('border_green');
  var first_letter=document.querySelector('.box_8_6').innerHTML=letter_8_6;


}if(letter_8_7==='A'){
  gsap.timeline().from(".box_8_7",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_7});
      document.querySelector('.box_8_7').classList.add('border_green');
      var first_letter=document.querySelector('.box_8_7').innerHTML=letter_8_7;
    
}if(letter_8_8==='A'){
  gsap.timeline().from(".box_8_8",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_8});
      document.querySelector('.box_8_8').classList.add('border_green');
      var first_letter=document.querySelector('.box_8_8').innerHTML=letter_8_8;
    
}
} if(amount_of_letters===8 && i_vowel.checked){
  totalVowels.push(i_letters);
  document.querySelector('.score_card_1').innerHTML=main_score-(totalVowels.length*10);
  console.log(totalVowels);
if(letter_8_1==='I'){
    
  gsap.timeline().from(".box_8_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
    document.querySelector('.box_8_1').classList.add('border_green');
    var first_letter=document.querySelector('.box_8_1').innerHTML=letter_8_1;
  document.querySelector('.box_8_1').classList.add('letter_i');
 
}
if(letter_8_2==='I'){
    gsap.timeline().from(".box_8_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_2});
    document.querySelector('.box_8_2').classList.add('border_green');
    var first_letter=document.querySelector('.box_8_2').innerHTML=letter_8_2;
    document.querySelector('.box_8_2').classList.add('letter_i');
   
}if(letter_8_3==='I'){
gsap.timeline().from(".box_8_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_3});
document.querySelector('.box_8_3').classList.add('border_green');
var first_letter=document.querySelector('.box_8_3').innerHTML=letter_8_3;
document.querySelector('.box_8_3').classList.add('letter_i');



}if(letter_8_4==='I'){
gsap.timeline().from(".box_8_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_4});
document.querySelector('.box_8_4').classList.add('border_green');
var first_letter=document.querySelector('.box_8_4').innerHTML=letter_8_4;
document.querySelector('.box_8_4').classList.add('letter_i');

}if(letter_8_5==='I'){
gsap.timeline().from(".box_8_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_5});
document.querySelector('.box_8_5').classList.add('border_green');
var first_letter=document.querySelector('.box_8_5').innerHTML=letter_8_5;
document.querySelector('.box_8_5').classList.add('letter_i');

}if(letter_8_6==='I'){

gsap.timeline().from(".box_8_6",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_6});
document.querySelector('.box_8_6').classList.add('border_green');
var first_letter=document.querySelector('.box_8_6').innerHTML=letter_8_6;
document.querySelector('.box_8_6').classList.add('letter_i');


}if(letter_8_7==='I'){
gsap.timeline().from(".box_8_7",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_7});
    document.querySelector('.box_8_7').classList.add('border_green');
    var first_letter=document.querySelector('.box_8_7').innerHTML=letter_8_7;
    document.querySelector('.box_8_7').classList.add('letter_i');
  
}if(letter_8_8==='I'){
  gsap.timeline().from(".box_8_8",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_8});
      document.querySelector('.box_8_8').classList.add('border_green');
      var first_letter=document.querySelector('.box_8_8').innerHTML=letter_8_8;
      document.querySelector('.box_8_8').classList.add('letter_i');
    
  }
   

}  if(amount_of_letters===8 && o_vowel.checked){
  totalVowels.push(o_letters);
  document.querySelector('.score_card_1').innerHTML=main_score-(totalVowels.length*10);
  console.log(totalVowels);
if(letter_8_1==='O'){
    
  gsap.timeline().from(".box_8_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
    document.querySelector('.box_8_1').classList.add('border_green');
    var first_letter=document.querySelector('.box_8_1').innerHTML=letter_8_1;
  
 
}
if(letter_8_2==='O'){
    gsap.timeline().from(".box_8_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_2});
    document.querySelector('.box_8_2').classList.add('border_green');
    var first_letter=document.querySelector('.box_8_2').innerHTML=letter_8_2;
    
   
}if(letter_8_3==='O'){
gsap.timeline().from(".box_8_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_3});
document.querySelector('.box_8_3').classList.add('border_green');
var first_letter=document.querySelector('.box_8_3').innerHTML=letter_8_3;




}if(letter_8_4==='O'){
gsap.timeline().from(".box_8_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_4});
document.querySelector('.box_8_4').classList.add('border_green');
var first_letter=document.querySelector('.box_8_4').innerHTML=letter_8_4;


}if(letter_8_5==='O'){
gsap.timeline().from(".box_8_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_5});
document.querySelector('.box_8_5').classList.add('border_green');
var first_letter=document.querySelector('.box_8_5').innerHTML=letter_8_5;


}if(letter_8_6==='O'){

gsap.timeline().from(".box_8_6",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_6});
document.querySelector('.box_8_6').classList.add('border_green');
var first_letter=document.querySelector('.box_8_6').innerHTML=letter_8_6;



}if(letter_8_7==='O'){
gsap.timeline().from(".box_8_7",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_7});
    document.querySelector('.box_8_7').classList.add('border_green');
    var first_letter=document.querySelector('.box_8_7').innerHTML=letter_8_7;
   
  
}if(letter_8_8==='O'){
  gsap.timeline().from(".box_8_8",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_7});
      document.querySelector('.box_8_8').classList.add('border_green');
      var first_letter=document.querySelector('.box_8_8').innerHTML=letter_8_8;
     
    
  }
   

} if(amount_of_letters===8 && e_vowel.checked){
  totalVowels.push(e_letters);
  document.querySelector('.score_card_1').innerHTML=main_score-(totalVowels.length*10);
  console.log(totalVowels);
if(letter_8_1==='E'){
    
  gsap.timeline().from(".box_8_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
    document.querySelector('.box_8_1').classList.add('border_green');
    var first_letter=document.querySelector('.box_8_1').innerHTML=letter_8_1;
  
 
}
if(letter_8_2==='E'){
    gsap.timeline().from(".box_8_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_2});
    document.querySelector('.box_8_2').classList.add('border_green');
    var first_letter=document.querySelector('.box_8_2').innerHTML=letter_8_2;
    
   
}if(letter_8_3==='E'){
gsap.timeline().from(".box_8_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_3});
document.querySelector('.box_8_3').classList.add('border_green');
var first_letter=document.querySelector('.box_8_3').innerHTML=letter_8_3;




}if(letter_8_4==='E'){
gsap.timeline().from(".box_8_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_4});
document.querySelector('.box_8_4').classList.add('border_green');
var first_letter=document.querySelector('.box_8_4').innerHTML=letter_8_4;


}if(letter_8_5==='E'){
gsap.timeline().from(".box_8_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_5});
document.querySelector('.box_8_5').classList.add('border_green');
var first_letter=document.querySelector('.box_8_5').innerHTML=letter_8_5;


}if(letter_8_6==='E'){

gsap.timeline().from(".box_8_6",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_6});
document.querySelector('.box_8_6').classList.add('border_green');
var first_letter=document.querySelector('.box_8_6').innerHTML=letter_8_6;



}if(letter_8_7==='E'){
gsap.timeline().from(".box_8_7",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_7});
    document.querySelector('.box_8_7').classList.add('border_green');
    var first_letter=document.querySelector('.box_8_7').innerHTML=letter_8_7;
   
}  if(letter_8_8==='E'){
  gsap.timeline().from(".box_8_8",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_7});
      document.querySelector('.box_8_8').classList.add('border_green');
      var first_letter=document.querySelector('.box_8_8').innerHTML=letter_8_8;
     
  }

}  if(amount_of_letters===8 && u_vowel.checked){
  totalVowels.push(u_letters);
  document.querySelector('.score_card_1').innerHTML=main_score-(totalVowels.length*10);
  console.log(totalVowels);
if(letter_8_1==='U'){
    
  gsap.timeline().from(".box_8_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_1});
    document.querySelector('.box_8_1').classList.add('border_green');
    var first_letter=document.querySelector('.box_8_1').innerHTML=letter_8_1;
  
 
}
if(letter_8_2==='U'){
    gsap.timeline().from(".box_8_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_2});
    document.querySelector('.box_8_2').classList.add('border_green');
    var first_letter=document.querySelector('.box_8_2').innerHTML=letter_8_2;
    
   
}if(letter_8_3==='U'){
gsap.timeline().from(".box_8_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_3});
document.querySelector('.box_8_3').classList.add('border_green');
var first_letter=document.querySelector('.box_8_3').innerHTML=letter_8_3;




}if(letter_8_4==='U'){
gsap.timeline().from(".box_8_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_4});
document.querySelector('.box_8_4').classList.add('border_green');
var first_letter=document.querySelector('.box_8_4').innerHTML=letter_8_4;


}if(letter_8_5==='U'){
gsap.timeline().from(".box_8_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_5});
document.querySelector('.box_8_5').classList.add('border_green');
var first_letter=document.querySelector('.box_8_5').innerHTML=letter_8_5;


}if(letter_8_6==='U'){

gsap.timeline().from(".box_8_6",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_6});
document.querySelector('.box_8_6').classList.add('border_green');
var first_letter=document.querySelector('.box_8_6').innerHTML=letter_8_6;



}if(letter_8_7==='U'){
gsap.timeline().from(".box_8_7",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_7});
    document.querySelector('.box_8_7').classList.add('border_green');
    var first_letter=document.querySelector('.box_8_7').innerHTML=letter_8_7;
   
}  if(letter_8_8==='U'){
  gsap.timeline().from(".box_8_8",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:correctLetterTone_8});
      document.querySelector('.box_8_8').classList.add('border_green');
      var first_letter=document.querySelector('.box_8_8').innerHTML=letter_8_8;
     
  } 

  
}




});



function revealAnswerNoTimeLeft(){
 console.log('function activated');
  gsap.to(".disappear", {duration: 3, x: 300, opacity: 0, scale: 0.5});
  gsap.to(".time_control", {duration: 3, x: 300, opacity: 0, scale: 0.5});
  
  
   
   
if(amount_of_letters===4){
    
    var cash_4_1_minus= -Math.round((.25 * questionCash));
    var cash_4_1=0;
    var total_4_percent_1=0;
    gsap.timeline().from(".box_4_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:wrongLetterTone_1});
    gsap.timeline().from(".box_4_1",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_4_1').classList.add('border_red');
      document.querySelector('.box_4_1').classList.add('cash_red');
      var first_letter=document.querySelector('.box_4_1').innerHTML='x';


    }});

    gsap.timeline().from(".box_4_1",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:.4,onStart:function(){
      document.querySelector('.box_4_1').innerHTML='';
      document.querySelector('.box_4_1').classList.add('border_red');
      document.querySelector('.box_4_1').classList.remove('cash_red');
      if(letter_4_1==='M'){
        document.querySelector('.box_4_1').classList.add('letter_m');
        var first_letter=document.querySelector('.box_4_1').innerHTML=letter_4_1;
      }else if(letter_4_1==='I'){
        document.querySelector('.box_4_1').classList.add('letter_i');
        var first_letter=document.querySelector('.box_4_1').innerHTML=letter_4_1;
      }else if(letter_4_1==='J'){
        document.querySelector('.box_4_1').classList.add('letter_j');
        var first_letter=document.querySelector('.box_4_1').innerHTML=letter_4_1;
      }else if(letter_4_1==='W'){
        document.querySelector('.box_4_1').classList.add('letter_w');
        var first_letter=document.querySelector('.box_4_1').innerHTML=letter_4_1;
      }else{
        var first_letter=document.querySelector('.box_4_1').innerHTML=letter_4_1;
      }
      


    }});
    var cash_4_2_minus= -Math.round((.25 * questionCash));
    var cash_4_2=0;
    var total_4_percent_2=0;
    gsap.timeline().from(".box_4_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.4,onStart:wrongLetterTone_2});
    gsap.timeline().from(".box_4_2",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_4_2').classList.add('border_red');
      document.querySelector('.box_4_2').classList.add('cash_red');
      var first_letter=document.querySelector('.box_4_2').innerHTML='x';


    }});

    gsap.timeline().from(".box_4_2",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:.7,onStart:function(){
      document.querySelector('.box_4_2').innerHTML='';
      document.querySelector('.box_4_2').classList.add('border_red');
      document.querySelector('.box_4_2').classList.remove('cash_red');
      if(letter_4_2==='M'){
        document.querySelector('.box_4_2').classList.add('letter_m');
        var first_letter=document.querySelector('.box_4_2').innerHTML=letter_4_2;
      }else if(letter_4_2==='I'){
        document.querySelector('.box_4_2').classList.add('letter_i');
        var first_letter=document.querySelector('.box_4_2').innerHTML=letter_4_2;
      }else if(letter_4_2==='J'){
        document.querySelector('.box_4_2').classList.add('letter_j');
        var first_letter=document.querySelector('.box_4_2').innerHTML=letter_4_2;
      }else if(letter_4_2==='W'){
        document.querySelector('.box_4_2').classList.add('letter_w');
        var first_letter=document.querySelector('.box_4_2').innerHTML=letter_4_2;
      }else{
        var first_letter=document.querySelector('.box_4_2').innerHTML=letter_4_2;
      }
      


    }});

    var cash_4_3_minus= -Math.round((.25 * questionCash));
    var cash_4_3=0;
    var total_4_percent_3=0;
    gsap.timeline().from(".box_4_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.7,onStart:wrongLetterTone_3});
    gsap.timeline().from(".box_4_3",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_4_3').classList.add('border_red');
      document.querySelector('.box_4_3').classList.add('cash_red');
      var first_letter=document.querySelector('.box_4_3').innerHTML='x';


    }});

    gsap.timeline().from(".box_4_3",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1,onStart:function(){
      document.querySelector('.box_4_3').innerHTML='';
      document.querySelector('.box_4_3').classList.add('border_red');
      document.querySelector('.box_4_3').classList.remove('cash_red');
      if(letter_4_3==='M'){
        document.querySelector('.box_4_3').classList.add('letter_m');
        var first_letter=document.querySelector('.box_4_3').innerHTML=letter_4_3;
      }else if(letter_4_3==='I'){
        document.querySelector('.box_4_3').classList.add('letter_i');
        var first_letter=document.querySelector('.box_4_3').innerHTML=letter_4_3;
      }else if(letter_4_3==='J'){
        document.querySelector('.box_4_3').classList.add('letter_j');
        var first_letter=document.querySelector('.box_4_3').innerHTML=letter_4_3;
      }else if(letter_4_3==='W'){
        document.querySelector('.box_4_3').classList.add('letter_w');
        var first_letter=document.querySelector('.box_4_3').innerHTML=letter_4_3;
      }else{
        var first_letter=document.querySelector('.box_4_3').innerHTML=letter_4_3;
      }
      


    }});

    var cash_4_4_minus= -Math.round((.25 * questionCash));
  var cash_4_4=0;
  var total_4_percent_4=0;
  gsap.timeline().from(".box_4_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1,onStart:wrongLetterTone_4});
  gsap.timeline().from(".box_4_4",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
    document.querySelector('.box_4_4').classList.add('border_red');
    document.querySelector('.box_4_4').classList.add('cash_red');
    var first_letter=document.querySelector('.box_4_4').innerHTML='x';


  }});

  gsap.timeline().from(".box_4_4",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1.3,onStart:function(){
    document.querySelector('.box_4_4').innerHTML='';
    document.querySelector('.box_4_4').classList.add('border_red');
    document.querySelector('.box_4_4').classList.remove('cash_red');
    if(letter_4_4==='M'){
      document.querySelector('.box_4_4').classList.add('letter_m');
      var first_letter=document.querySelector('.box_4_4').innerHTML=letter_4_4;
    }else if(letter_4_4==='I'){
      document.querySelector('.box_4_4').classList.add('letter_i');
      var first_letter=document.querySelector('.box_4_4').innerHTML=letter_4_4;
    }else if(letter_4_4==='J'){
      document.querySelector('.box_4_4').classList.add('letter_j');
      var first_letter=document.querySelector('.box_4_4').innerHTML=letter_4_4;
    }else if(letter_4_4==='W'){
      document.querySelector('.box_4_4').classList.add('letter_w');
      var first_letter=document.querySelector('.box_4_4').innerHTML=letter_4_4;
    }else{
      var first_letter=document.querySelector('.box_4_4').innerHTML=letter_4_4;
    }
    


  }});
  
  
     total4cashMinus=(cash_4_1_minus+cash_4_2_minus+cash_4_3_minus+cash_4_4_minus);
     percentage_4_minus=(total_4_percent_1 + total_4_percent_2 + total_4_percent_3 + total_4_percent_4 ); 
      audienceMinusTone();
      gsap.timeline().from(".points",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:2.7});
      gsap.timeline().to(".points",{duration:1,opacity:1,scale:0,x:0,ease:"back",delay:2.7,onStart:loseMoneyTone});

    
  
      
    
      

    
   
    document.querySelector('.points').innerHTML='-'+ '$'+ -total4cashMinus;
    
    document.querySelector('.points').classList.add('cash_red');
  
    main_score= Math.ceil(main_score+total4cashMinus);

    letter_total=4;
    letter_count=letter_total+letter_count;

     total_percent =total_percent+percentage_4_minus;
     var percent_total=document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100);
    if(percent_total===0 || percent_total<10){
      document.querySelector('.score_card').classList.remove('percent_padding_100');
      document.querySelector('.score_card').classList.remove('percent_padding_10');
      console.log('padding1-10');
      document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
    }else if(percent_total>10 && percent_total<99){
      document.querySelector('.score_card').classList.add('percent_padding_10');
      document.querySelector('.score_card').classList.remove('percent_padding_100');
      console.log('padding10-100');
      document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
    }else if(percent_total===100){
      document.querySelector('.score_card').classList.add('percent_padding_100');
      document.querySelector('.score_card').classList.remove('percent_padding_10');
      console.log('padding100');
      document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
    }
    
    
    if(main_score<=5){
      
      $(".cover ").show();
        $(".game_over ").show();
        document.querySelector('.start_over').addEventListener('click',function(){
          location.reload(true);
        });
    }if(main_score <10){
      document.querySelector('.score_card_1').classList.add('score_card_1_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;
    }else if(main_score>=10 && main_score<100){
      document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
      document.querySelector('.score_card_1').classList.add('score_card_10_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;
    }else if(main_score>=100 && main_score<1000){
      document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
      document.querySelector('.score_card_1').classList.add('score_card_100_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;
    }else if(main_score>=1000 && main_score<=10000){
      document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
      document.querySelector('.score_card_1').classList.add('score_card_1000_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;
    }else if(main_score>=10000 && main_score<=100000){
      document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
      document.querySelector('.score_card_1').classList.remove('score_card_1000_padding');
      document.querySelector('.score_card_1').classList.add('score_card_10000_padding');
      document.querySelector('.score_card_1').innerHTML=main_score;

    }
  document.querySelector('.players_cash').innerHTML='$'+main_score;
  document.querySelector('.players_cash_1').innerHTML=' '+'$'+main_score;

  var seventh_letter=document.querySelector('.write_box_4_4').childNodes[7].innerHTML="x";



  }
  if(amount_of_letters===5){
    
    var cash_5_1_minus= -Math.round((.20 * questionCash));
    var cash_5_1=0;
    var total_5_percent_1=0;
    gsap.timeline().from(".box_5_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:wrongLetterTone_1});
    gsap.timeline().from(".box_5_1",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_5_1').classList.add('border_red');
      document.querySelector('.box_5_1').classList.add('cash_red');
      document.querySelector('.write_box_5_5').childNodes[1].innerHTML='x';


    }});

    gsap.timeline().from(".box_5_1",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:.4,onStart:function(){
      document.querySelector('.box_5_1').innerHTML='';
      document.querySelector('.box_5_1').classList.add('border_red');
      document.querySelector('.box_5_1').classList.remove('cash_red');
      if(letter_5_1==='M'){
        document.querySelector('.box_5_1').classList.add('letter_m');
        var first_letter=document.querySelector('.box_5_1').innerHTML=letter_5_1;
      }else if(letter_5_1==='I'){
        document.querySelector('.box_5_1').classList.add('letter_i');
        var first_letter=document.querySelector('.box_5_1').innerHTML=letter_5_1;
      }else if(letter_5_1==='J'){
        document.querySelector('.box_5_1').classList.add('letter_j');
        var first_letter=document.querySelector('.box_5_1').innerHTML=letter_5_1;
      }else if(letter_5_1==='W'){
        document.querySelector('.box_5_1').classList.add('letter_w');
        var first_letter=document.querySelector('.box_5_1').innerHTML=letter_5_1;
      }else{
        var first_letter=document.querySelector('.box_5_1').innerHTML=letter_5_1;
      }
      


    }});

    var cash_5_2_minus= -Math.round((.20 * questionCash));
    var cash_5_2=0;
    var total_5_percent_2=0;
    gsap.timeline().from(".box_5_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.4,onStart:wrongLetterTone_2});
    gsap.timeline().from(".box_5_2",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_5_2').classList.add('border_red');
      document.querySelector('.box_5_2').classList.add('cash_red');
      var first_letter=document.querySelector('.box_5_2').innerHTML='x';


    }});

    gsap.timeline().from(".box_5_2",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:.7,onStart:function(){
      document.querySelector('.box_5_2').innerHTML='';
      document.querySelector('.box_5_2').classList.add('border_red');
      document.querySelector('.box_5_2').classList.remove('cash_red');
      if(letter_5_2==='M'){
        document.querySelector('.box_5_2').classList.add('letter_m');
        var first_letter=document.querySelector('.box_5_2').innerHTML=letter_5_2;
      }else if(letter_5_2==='I'){
        document.querySelector('.box_5_2').classList.add('letter_i');
        var first_letter=document.querySelector('.box_5_2').innerHTML=letter_5_2;
      }else if(letter_5_2==='J'){
        document.querySelector('.box_5_2').classList.add('letter_j');
        var first_letter=document.querySelector('.box_5_2').innerHTML=letter_5_2;
      }else if(letter_5_2==='W'){
        document.querySelector('.box_5_2').classList.add('letter_w');
        var first_letter=document.querySelector('.box_5_2').innerHTML=letter_5_2;
      }else{
        var first_letter=document.querySelector('.box_5_2').innerHTML=letter_5_2;
      }
      


    }});

    var cash_5_3_minus= -Math.round((.20 * questionCash));
    var cash_5_4=0;
    var total_5_percent_3=0;
    gsap.timeline().from(".box_5_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.7,onStart:wrongLetterTone_3});
    gsap.timeline().from(".box_5_3",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_5_3').classList.add('border_red');
      document.querySelector('.box_5_3').classList.add('cash_red');
      var first_letter=document.querySelector('.box_5_3').innerHTML='x';


    }});

    gsap.timeline().from(".box_5_3",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1,onStart:function(){
      document.querySelector('.box_5_3').innerHTML='';
      document.querySelector('.box_5_3').classList.add('border_red');
      document.querySelector('.box_5_3').classList.remove('cash_red');
      if(letter_5_3==='M'){
        document.querySelector('.box_5_3').classList.add('letter_m');
        var first_letter=document.querySelector('.box_5_3').innerHTML=letter_5_3;
      }else if(letter_5_3==='I'){
        document.querySelector('.box_5_3').classList.add('letter_i');
        var first_letter=document.querySelector('.box_5_3').innerHTML=letter_5_3;
      }else if(letter_5_3==='J'){
        document.querySelector('.box_5_3').classList.add('letter_j');
        var first_letter=document.querySelector('.box_5_3').innerHTML=letter_5_3;
      }else if(letter_5_3==='W'){
        document.querySelector('.box_5_3').classList.add('letter_w');
        var first_letter=document.querySelector('.box_5_3').innerHTML=letter_5_3;
      }else{
        var first_letter=document.querySelector('.box_5_3').innerHTML=letter_5_3;
      }
      


    }});
    var cash_5_4_minus= -Math.round((.20 * questionCash));
      var cash_5_4=0;
      var total_5_percent_4=0;
      gsap.timeline().from(".box_5_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1,onStart:wrongLetterTone_4});
      gsap.timeline().from(".box_5_4",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
        document.querySelector('.box_5_4').classList.add('border_red');
        document.querySelector('.box_5_4').classList.add('cash_red');
        var first_letter=document.querySelector('.box_5_4').innerHTML='x';
  
  
      }});
  
      gsap.timeline().from(".box_5_4",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1.3,onStart:function(){
        document.querySelector('.box_5_4').innerHTML='';
        document.querySelector('.box_5_4').classList.add('border_red');
        document.querySelector('.box_5_4').classList.remove('cash_red');
        if(letter_5_4==='M'){
          document.querySelector('.box_5_4').classList.add('letter_m');
          var first_letter=document.querySelector('.box_5_4').innerHTML=letter_5_4;
        }else if(letter_5_4==='I'){
          document.querySelector('.box_5_4').classList.add('letter_i');
          var first_letter=document.querySelector('.box_5_4').innerHTML=letter_5_4;
        }else if(letter_5_4==='J'){
          document.querySelector('.box_5_4').classList.add('letter_j');
          var first_letter=document.querySelector('.box_5_4').innerHTML=letter_5_4;
        }else if(letter_5_4==='W'){
          document.querySelector('.box_5_4').classList.add('letter_w');
          var first_letter=document.querySelector('.box_5_4').innerHTML=letter_5_4;
        }else{
          var first_letter=document.querySelector('.box_5_4').innerHTML=letter_5_4;
        }
        
  
  
      }});

      var cash_5_5_minus= -Math.round((.20 * questionCash));
      var cash_5_5=0;
      var total_5_percent_5=0;
      gsap.timeline().from(".box_5_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1.3,onStart:wrongLetterTone_5});
      gsap.timeline().from(".box_5_5",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
        document.querySelector('.box_5_5').classList.add('border_red');
        document.querySelector('.box_5_5').classList.add('cash_red');
        var first_letter=document.querySelector('.box_5_5').innerHTML='x';
  
  
      }});
  
      gsap.timeline().from(".box_5_5",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1.6,onStart:function(){
        document.querySelector('.box_5_5').innerHTML='';
        document.querySelector('.box_5_5').classList.add('border_red');
        document.querySelector('.box_5_5').classList.remove('cash_red');
        if(letter_5_5==='M'){
          document.querySelector('.box_5_5').classList.add('letter_m');
          var first_letter=document.querySelector('.box_5_5').innerHTML=letter_5_5;
        }else if(letter_5_5==='I'){
          document.querySelector('.box_5_5').classList.add('letter_i');
          var first_letter=document.querySelector('.box_5_5').innerHTML=letter_5_5;
        }else if(letter_5_5==='J'){
          document.querySelector('.box_5_5').classList.add('letter_j');
          var first_letter=document.querySelector('.box_5_5').innerHTML=letter_5_5;
        }else if(letter_5_5==='W'){
          document.querySelector('.box_5_5').classList.add('letter_w');
          var first_letter=document.querySelector('.box_5_5').innerHTML=letter_5_5;
        }else{
          var first_letter=document.querySelector('.box_5_5').innerHTML=letter_5_5;
        }
        
  
  
      }});
      
      
         total5cashMinus=(cash_5_1_minus+cash_5_2_minus+cash_5_3_minus+cash_5_4_minus+cash_5_5_minus);
         percentage_5_minus=(total_5_percent_1 + total_5_percent_2 + total_5_percent_3 + total_5_percent_4 + total_5_percent_5 ); 
         
         
        
          audienceMinusTone();
          gsap.timeline().from(".points",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:2.7});
          gsap.timeline().to(".points",{duration:1,opacity:1,scale:0,x:0,ease:"back",delay:2.7,onStart:loseMoneyTone});
    
        
        
  
        
       
        document.querySelector('.points').innerHTML='-'+ '$'+ -total5cashMinus;
        
        document.querySelector('.points').classList.add('cash_red');
      
        main_score= Math.ceil(main_score+total5cashMinus);
        
        letter_total=5;
        letter_count=letter_total+letter_count;
        
     total_percent =total_percent+percentage_5_minus;
     var percent_total=document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100);
     if(percent_total===0 || percent_total<10){
       document.querySelector('.score_card').classList.remove('percent_padding_100');
       document.querySelector('.score_card').classList.remove('percent_padding_10');
       
       document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
     }else if(percent_total>10 && percent_total<99){
       document.querySelector('.score_card').classList.add('percent_padding_10');
       document.querySelector('.score_card').classList.remove('percent_padding_100');
       
       document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
     }else if(percent_total===100){
       document.querySelector('.score_card').classList.add('percent_padding_100');
       document.querySelector('.score_card').classList.remove('percent_padding_10');
       
       document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
     }
        
        if(main_score<=5){
          
          $(".cover ").show();
            $(".game_over ").show();
            document.querySelector('.start_over').addEventListener('click',function(){
              location.reload(true);
            });
        }if(main_score <10){
          document.querySelector('.score_card_1').classList.add('score_card_1_padding');
          document.querySelector('.score_card_1').innerHTML=main_score;
        }else if(main_score>=10 && main_score<100){
          document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
          document.querySelector('.score_card_1').classList.add('score_card_10_padding');
          document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
          document.querySelector('.score_card_1').innerHTML=main_score;
        }else if(main_score>=100 && main_score<1000){
          document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
          document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
          document.querySelector('.score_card_1').classList.add('score_card_100_padding');
          document.querySelector('.score_card_1').innerHTML=main_score;
        }else if(main_score>=1000 && main_score<=10000){
          document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
          document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
          document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
          document.querySelector('.score_card_1').classList.add('score_card_1000_padding');
          document.querySelector('.score_card_1').innerHTML=main_score;
        }else if(main_score>=10000 && main_score<=100000){
          document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
          document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
          document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
          document.querySelector('.score_card_1').classList.remove('score_card_1000_padding');
          document.querySelector('.score_card_1').classList.add('score_card_10000_padding');
          document.querySelector('.score_card_1').innerHTML=main_score;
    
        }
      document.querySelector('.players_cash').innerHTML=''+'$'+main_score;
      document.querySelector('.players_cash_1').innerHTML=' '+'$'+main_score;
    
      var seventh_letter=document.querySelector('.write_box_5_5').childNodes[9].innerHTML="x";
    
         

  }
  if(amount_of_letters===6){

    var cash_6_1_minus=  -Math.round((.16 * questionCash));
    var cash_6_1= 0;
    var total_6_percent_1=0;
    gsap.timeline().from(".box_6_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:wrongLetterTone_1});
    gsap.timeline().from(".box_6_1",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_6_1').classList.add('border_red');
      document.querySelector('.box_6_1').classList.add('cash_red');
      var first_letter=document.querySelector('.box_6_1').innerHTML='x';


    }});

    gsap.timeline().from(".box_6_1",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:.4,onStart:function(){
      document.querySelector('.box_6_1').innerHTML='';
      document.querySelector('.box_6_1').classList.add('border_red');
      document.querySelector('.box_6_1').classList.remove('cash_red');
      if(letter_6_1==='M'){
        document.querySelector('.box_6_1').classList.add('letter_m');
        var first_letter=document.querySelector('.box_6_1').innerHTML=letter_6_1;
      }else if(letter_6_1==='I'){
        document.querySelector('.box_6_1').classList.add('letter_i');
        var first_letter=document.querySelector('.box_6_1').innerHTML=letter_6_1;
      }else if(letter_6_1==='J'){
        document.querySelector('.box_6_1').classList.add('letter_j');
        var first_letter=document.querySelector('.box_6_1').innerHTML=letter_6_1;
      }else if(letter_6_1==='W'){
        document.querySelector('.box_6_1').classList.add('letter_w');
        var first_letter=document.querySelector('.box_6_1').innerHTML=letter_6_1;
      }else{
        var first_letter=document.querySelector('.box_6_1').innerHTML=letter_6_1;
      }
      


    }});

    var cash_6_2_minus= -Math.round((.16 * questionCash));
    var cash_6_2=0;
    var total_6_percent_2=0;
    gsap.timeline().from(".box_6_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.4,onStart:wrongLetterTone_2});
    gsap.timeline().from(".box_6_2",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_6_2').classList.add('border_red');
      document.querySelector('.box_6_2').classList.add('cash_red');
      var first_letter=document.querySelector('.box_6_2').innerHTML='x';


    }});

    gsap.timeline().from(".box_6_2",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:.7,onStart:function(){
      document.querySelector('.box_6_2').innerHTML='';
      document.querySelector('.box_6_2').classList.add('border_red');
      document.querySelector('.box_6_2').classList.remove('cash_red');
      if(letter_6_2==='M'){
        document.querySelector('.box_6_2').classList.add('letter_m');
        var first_letter=document.querySelector('.box_6_2').innerHTML=letter_6_2;
      }else if(letter_6_2==='I'){
        document.querySelector('.box_6_2').classList.add('letter_i');
        var first_letter=document.querySelector('.box_6_2').innerHTML=letter_6_2;
      }else if(letter_6_2==='J'){
        document.querySelector('.box_6_2').classList.add('letter_j');
        var first_letter=document.querySelector('.box_6_2').innerHTML=letter_6_2;
      }else if(letter_6_2==='W'){
        document.querySelector('.box_6_2').classList.add('letter_w');
        var first_letter=document.querySelector('.box_6_2').innerHTML=letter_6_2;
      }else{
        var first_letter=document.querySelector('.box_6_2').innerHTML=letter_6_2;
      }
      


    }});

    var cash_6_3_minus=  -Math.round((.16 * questionCash));
    var cash_6_3=0;
    var total_6_percent_3=0;
    gsap.timeline().from(".box_6_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.7,onStart:wrongLetterTone_3});
    gsap.timeline().from(".box_6_3",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_6_3').classList.add('border_red');
      document.querySelector('.box_6_3').classList.add('cash_red');
      var first_letter=document.querySelector('.box_6_3').innerHTML='x';


    }});

    gsap.timeline().from(".box_6_3",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1,onStart:function(){
      document.querySelector('.box_6_3').innerHTML='';
      document.querySelector('.box_6_3').classList.add('border_red');
      document.querySelector('.box_6_3').classList.remove('cash_red');
      if(letter_6_3==='M'){
        document.querySelector('.box_6_3').classList.add('letter_m');
        var first_letter=document.querySelector('.box_6_3').innerHTML=letter_6_3;
      }else if(letter_6_3==='I'){
        document.querySelector('.box_6_3').classList.add('letter_i');
        var first_letter=document.querySelector('.box_6_3').innerHTML=letter_6_3;
      }else if(letter_6_3==='J'){
        document.querySelector('.box_6_3').classList.add('letter_j');
        var first_letter=document.querySelector('.box_6_3').innerHTML=letter_6_3;
      }else if(letter_6_3==='W'){
        document.querySelector('.box_6_3').classList.add('letter_w');
        var first_letter=document.querySelector('.box_6_3').innerHTML=letter_6_3;
      }else{
        var first_letter=document.querySelector('.box_6_3').innerHTML=letter_6_3;
      }
      


    }});

    var cash_6_4_minus=  -Math.round((.16 * questionCash));
    var cash_6_4=  0;
    var total_6_percent_4=0;
    gsap.timeline().from(".box_6_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1,onStart:wrongLetterTone_4});
    gsap.timeline().from(".box_6_4",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_6_4').classList.add('border_red');
      document.querySelector('.box_6_4').classList.add('cash_red');
      var first_letter=document.querySelector('.box_6_4').innerHTML='x';


    }});

    gsap.timeline().from(".box_6_4",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1.3,onStart:function(){
      document.querySelector('.box_6_4').innerHTML='';
      document.querySelector('.box_6_4').classList.add('border_red');
      document.querySelector('.box_6_4').classList.remove('cash_red');
      if(letter_6_4==='M'){
        document.querySelector('.box_6_4').classList.add('letter_m');
        var first_letter=document.querySelector('.box_6_4').innerHTML=letter_6_4;
      }else if(letter_6_4==='I'){
        document.querySelector('.box_6_4').classList.add('letter_i');
        var first_letter=document.querySelector('.box_6_4').innerHTML=letter_6_4;
      }else if(letter_6_4==='J'){
        document.querySelector('.box_6_4').classList.add('letter_j');
        var first_letter=document.querySelector('.box_6_4').innerHTML=letter_6_4;
      }else if(letter_6_4==='W'){
        document.querySelector('.box_6_4').classList.add('letter_w');
        var first_letter=document.querySelector('.box_6_4').innerHTML=letter_6_4;
      }else{
        var first_letter=document.querySelector('.box_6_4').innerHTML=letter_6_4;
      }
      


    }});

    var cash_6_5_minus= -Math.round((.16 * questionCash));
    var cash_6_5=0;
    var total_6_percent_5=0;
    gsap.timeline().from(".box_6_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1.3,onStart:wrongLetterTone_5});
    gsap.timeline().from(".box_6_5",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_6_5').classList.add('border_red');
      document.querySelector('.box_6_5').classList.add('cash_red');
      var first_letter=document.querySelector('.box_6_5').innerHTML='x';


    }});

    gsap.timeline().from(".box_6_5",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1.6,onStart:function(){
      document.querySelector('.box_6_5').innerHTML='';
      document.querySelector('.box_6_5').classList.add('border_red');
      document.querySelector('.box_6_5').classList.remove('cash_red');
      if(letter_6_5==='M'){
        document.querySelector('.box_6_5').classList.add('letter_m');
        var first_letter=document.querySelector('.box_6_5').innerHTML=letter_6_5;
      }else if(letter_6_5==='I'){
        document.querySelector('.box_6_5').classList.add('letter_i');
        var first_letter=document.querySelector('.box_6_5').innerHTML=letter_6_5;
      }else if(letter_6_5==='J'){
        document.querySelector('.box_6_5').classList.add('letter_j');
        var first_letter=document.querySelector('.box_6_5').innerHTML=letter_6_5;
      }else if(letter_6_5==='W'){
        document.querySelector('.box_6_5').classList.add('letter_w');
        var first_letter=document.querySelector('.box_6_5').innerHTML=letter_6_5;
      }else{
        var first_letter=document.querySelector('.box_6_5').innerHTML=letter_6_5;
      }
      


    }});

    var cash_6_6_minus= -Math.round((.16 * questionCash));
    var cash_6_6=0;
    var total_6_percent_6=0;
    gsap.timeline().from(".box_6_6",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1.6,onStart:wrongLetterTone_6});
    gsap.timeline().from(".box_6_6",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_6_6').classList.add('border_red');
      document.querySelector('.box_6_6').classList.add('cash_red');
      var first_letter=document.querySelector('.box_6_6').innerHTML='x';


    }});

    gsap.timeline().from(".box_6_6",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:2,onStart:function(){
      document.querySelector('.box_6_6').innerHTML='';
      document.querySelector('.box_6_6').classList.add('border_red');
      document.querySelector('.box_6_6').classList.remove('cash_red');
      if(letter_6_6==='M'){
        document.querySelector('.box_6_6').classList.add('letter_m');
        var first_letter=document.querySelector('.box_6_6').innerHTML=letter_6_6;
      }else if(letter_6_6==='I'){
        document.querySelector('.box_6_6').classList.add('letter_i');
        var first_letter=document.querySelector('.box_6_6').innerHTML=letter_6_6;
      }else if(letter_6_6==='J'){
        document.querySelector('.box_6_6').classList.add('letter_j');
        var first_letter=document.querySelector('.box_6_6').innerHTML=letter_6_6;
      }else if(letter_6_6==='W'){
        document.querySelector('.box_6_6').classList.add('letter_w');
        var first_letter=document.querySelector('.box_6_6').innerHTML=letter_6_6;
      }else{
        var first_letter=document.querySelector('.box_6_6').innerHTML=letter_6_6;
      }
      


    }});
    
    
       total6cashMinus=(cash_6_1_minus+cash_6_2_minus+cash_6_3_minus+cash_6_4_minus+cash_6_5_minus+cash_6_6_minus );
       percentage_6_minus=(total_6_percent_1 + total_6_percent_2 + total_6_percent_3 + total_6_percent_4 + total_6_percent_5 + total_6_percent_6);
       
  
      
     
      
      
        audienceMinusTone();
        gsap.timeline().from(".points",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:2.7});
        gsap.timeline().to(".points",{duration:1,opacity:1,scale:0,x:0,ease:"back",delay:2.7,onStart:loseMoneyTone});
  
      
      

      
    
      
    document.querySelector('.points').innerHTML='-'+ '$'+ -total6cashMinus;
      
      document.querySelector('.points').classList.add('cash_red');
    
      main_score= Math.ceil(main_score+total6cashMinus);
      letter_total=6;
      letter_count=letter_total+letter_count;
      
     total_percent =total_percent+percentage_6_minus;
     var percent_total=document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100);
        if(percent_total===0 || percent_total<=10){
          document.querySelector('.score_card').classList.remove('percent_padding_100');
          document.querySelector('.score_card').classList.remove('percent_padding_10');
         
          document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
        }else if(percent_total>=10 && percent_total<99){
          document.querySelector('.score_card').classList.add('percent_padding_10');
          document.querySelector('.score_card').classList.remove('percent_padding_100');
          
          document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
        }else if(percent_total===100){
          document.querySelector('.score_card').classList.add('percent_padding_100');
          document.querySelector('.score_card').classList.remove('percent_padding_10');
          
          document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
        }
      if(main_score<=5){
       
        $(".cover ").show();
          $(".game_over ").show();
          document.querySelector('.start_over').addEventListener('click',function(){
            location.reload(true);
          });
      }if(main_score <10){
        document.querySelector('.score_card_1').classList.add('score_card_1_padding');
        document.querySelector('.score_card_1').innerHTML=main_score;
      }else if(main_score>=10 && main_score<100){
        document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
        document.querySelector('.score_card_1').classList.add('score_card_10_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
        document.querySelector('.score_card_1').innerHTML=main_score;
      }else if(main_score>=100 && main_score<1000){
        document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
        document.querySelector('.score_card_1').classList.add('score_card_100_padding');
        document.querySelector('.score_card_1').innerHTML=main_score;
      }else if(main_score>=1000 && main_score<=10000){
        document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
        document.querySelector('.score_card_1').classList.add('score_card_1000_padding');
        document.querySelector('.score_card_1').innerHTML=main_score;
      }else if(main_score>=10000 && main_score<=100000){
        document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_1000_padding');
        document.querySelector('.score_card_1').classList.add('score_card_10000_padding');
        document.querySelector('.score_card_1').innerHTML=main_score;
  
      }
      
    
    document.querySelector('.players_cash').innerHTML=''+'$'+main_score;
    document.querySelector('.players_cash_1').innerHTML=' '+'$'+main_score;
  
    var seventh_letter=document.querySelector('.write_box_6_6').childNodes[11].innerHTML="x";
  
    

    

    
    
    


  }
if(amount_of_letters===7){
  var cash_7_1_minus=  -Math.round((.14 * questionCash));
      var cash_7_1= 0;
      var total_7_percent_1=0;
      
      gsap.timeline().from(".box_7_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:wrongLetterTone_1});
      gsap.timeline().from(".box_7_1",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
        document.querySelector('.box_7_1').classList.add('border_red');
        document.querySelector('.box_7_1').classList.add('cash_red');
        var first_letter=document.querySelector('.box_7_1').innerHTML='x';


      }});

      gsap.timeline().from(".box_7_1",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:.4,onStart:function(){
        document.querySelector('.box_7_1').innerHTML='';
        document.querySelector('.box_7_1').classList.add('border_red');
        document.querySelector('.box_7_1').classList.remove('cash_red');
        
        
        if(letter_7_1==='M'){
          document.querySelector('.box_7_1').classList.add('letter_m');
          var first_letter=document.querySelector('.box_7_1').innerHTML=letter_7_1;
        }else if(letter_7_1==='I'){
          document.querySelector('.box_7_1').classList.add('letter_i');
          var first_letter=document.querySelector('.box_7_1').innerHTML=letter_7_1;
        }else if(letter_7_1==='J'){
          document.querySelector('.box_7_1').classList.add('letter_j');
          var first_letter=document.querySelector('.box_7_1').innerHTML=letter_7_1;
        }else if(letter_7_1==='W'){
          document.querySelector('.box_7_1').classList.add('letter_w');
          var first_letter=document.querySelector('.box_7_1').innerHTML=letter_7_1;
        }else{
          var first_letter=document.querySelector('.box_7_1').innerHTML=letter_7_1;
        }


      }});
 
      var cash_7_2_minus= -Math.round((.14 * questionCash));
      var cash_7_2_=0;
      var total_7_percent_2=0;
      
      gsap.timeline().from(".box_7_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.4,onStart:wrongLetterTone_2});
      gsap.timeline().from(".box_7_2",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
        document.querySelector('.box_7_2').classList.add('border_red');
        document.querySelector('.box_7_2').classList.add('cash_red');
        var first_letter=document.querySelector('.box_7_2').innerHTML='x';


      }});

      gsap.timeline().from(".box_7_2",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:.7,onStart:function(){
        document.querySelector('.box_7_2').innerHTML='';
        document.querySelector('.box_7_2').classList.add('border_red');
        document.querySelector('.box_7_2').classList.remove('cash_red');
        
        if(letter_7_2==='M'){
          document.querySelector('.box_7_2').classList.add('letter_m');
          var first_letter=document.querySelector('.box_7_2').innerHTML=letter_7_2;
        }else if(letter_7_2==='I'){
          document.querySelector('.box_7_2').classList.add('letter_i');
          var first_letter=document.querySelector('.box_7_2').innerHTML=letter_7_2;
        }else if(letter_7_2==='J'){
          document.querySelector('.box_7_2').classList.add('letter_j');
          var first_letter=document.querySelector('.box_7_2').innerHTML=letter_7_2;
        }else if(letter_7_2==='W'){
          document.querySelector('.box_7_2').classList.add('letter_w');
          var first_letter=document.querySelector('.box_7_2').innerHTML=letter_7_2;
        }else{
          var first_letter=document.querySelector('.box_7_2').innerHTML=letter_7_2;
        }


      }});

      var cash_7_3_minus= -Math.round((.14 * questionCash));
      var cash_7_3= 0;
      var total_7_percent_3=0;
      
      gsap.timeline().from(".box_7_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.7,onStart:wrongLetterTone_3});
      gsap.timeline().from(".box_7_3",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
        document.querySelector('.box_7_3').classList.add('border_red');
        document.querySelector('.box_7_3').classList.add('cash_red');
        var first_letter=document.querySelector('.box_7_3').innerHTML='x';


      }});

      gsap.timeline().from(".box_7_3",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1,onStart:function(){
        document.querySelector('.box_7_3').innerHTML='';
        document.querySelector('.box_7_3').classList.add('border_red');
        document.querySelector('.box_7_3').classList.remove('cash_red');
        if(letter_7_3==='M'){
          document.querySelector('.box_7_3').classList.add('letter_m');
          var first_letter=document.querySelector('.box_7_3').innerHTML=letter_7_3;
        }else if(letter_7_3==='I'){
          document.querySelector('.box_7_3').classList.add('letter_i');
          var first_letter=document.querySelector('.box_7_3').innerHTML=letter_7_3;
        }else if(letter_7_3==='J'){
          document.querySelector('.box_7_3').classList.add('letter_j');
          var first_letter=document.querySelector('.box_7_3').innerHTML=letter_7_3;
        }else if(letter_7_3==='W'){
          document.querySelector('.box_7_3').classList.add('letter_w');
          var first_letter=document.querySelector('.box_7_3').innerHTML=letter_7_3;
        }else{
          var first_letter=document.querySelector('.box_7_3').innerHTML=letter_7_3;
        }
        
        


      }});

      var cash_7_4_minus= -Math.round((.14 * questionCash));
      var cash_7_4= 0;
      var total_7_percent_4=0;
      
      gsap.timeline().from(".box_7_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1,onStart:wrongLetterTone_4});
      gsap.timeline().from(".box_7_4",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
        document.querySelector('.box_7_4').classList.add('border_red');
        document.querySelector('.box_7_4').classList.add('cash_red');
        var first_letter=document.querySelector('.box_7_4').innerHTML='x';


      }});

      gsap.timeline().from(".box_7_4",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1.3,onStart:function(){
        document.querySelector('.box_7_4').innerHTML='';
        document.querySelector('.box_7_4').classList.add('border_red');
        document.querySelector('.box_7_4').classList.remove('cash_red');
        if(letter_7_4==='M'){
          document.querySelector('.box_7_4').classList.add('letter_m');
          var first_letter=document.querySelector('.box_7_4').innerHTML=letter_7_4;
        }else if(letter_7_4==='I'){
          document.querySelector('.box_7_4').classList.add('letter_i');
          var first_letter=document.querySelector('.box_7_4').innerHTML=letter_7_4;
        }else if(letter_7_4==='J'){
          document.querySelector('.box_7_4').classList.add('letter_j');
          var first_letter=document.querySelector('.box_7_4').innerHTML=letter_7_4;
        }else if(letter_7_4==='W'){
          document.querySelector('.box_7_4').classList.add('letter_w');
          var first_letter=document.querySelector('.box_7_4').innerHTML=letter_7_4;
        }else{
          var first_letter=document.querySelector('.box_7_4').innerHTML=letter_7_4;
        }
        
        


      }});

      var cash_7_5_minus= -Math.round((.14 * questionCash));
      var cash_7_5=0;
      var total_7_percent_5=0;
      gsap.timeline().from(".box_7_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1.3,onStart:wrongLetterTone_5});
      gsap.timeline().from(".box_7_5",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
        document.querySelector('.box_7_5').classList.add('border_red');
        document.querySelector('.box_7_5').classList.add('cash_red');
        var first_letter=document.querySelector('.box_7_5').innerHTML='x';


      }});

      gsap.timeline().from(".box_7_5",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1.6,onStart:function(){
        document.querySelector('.box_7_5').innerHTML='';
        document.querySelector('.box_7_5').classList.add('border_red');
        document.querySelector('.box_7_5').classList.remove('cash_red');
      
        if(letter_7_5==='M'){
          document.querySelector('.box_7_5').classList.add('letter_m');
          var first_letter=document.querySelector('.box_7_5').innerHTML=letter_7_5;
        }else if(letter_7_5==='I'){
          document.querySelector('.box_7_5').classList.add('letter_i');
          var first_letter=document.querySelector('.box_7_5').innerHTML=letter_7_5;
        }else if(letter_7_5==='J'){
          document.querySelector('.box_7_5').classList.add('letter_j');
          var first_letter=document.querySelector('.box_7_5').innerHTML=letter_7_5;
        }else if(letter_7_5==='W'){
          document.querySelector('.box_7_3').classList.add('letter_w');
          var first_letter=document.querySelector('.box_7_5').innerHTML=letter_7_5;
        }else{
          var first_letter=document.querySelector('.box_7_5').innerHTML=letter_7_5;
        }


      }});

      var cash_7_6_minus= -Math.round((.14 * questionCash));
      var cash_7_6=0;
      var total_7_percent_6=0;
      gsap.timeline().from(".box_7_6",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1.6,onStart:wrongLetterTone_6});
      gsap.timeline().from(".box_7_6",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
        document.querySelector('.box_7_6').classList.add('border_red');
        document.querySelector('.box_7_6').classList.add('cash_red');
        var first_letter=document.querySelector('.box_7_6').innerHTML='x';


      }});

      gsap.timeline().from(".box_7_6",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:2,onStart:function(){
        document.querySelector('.box_7_6').innerHTML='';
        document.querySelector('.box_7_6').classList.add('border_red');
        document.querySelector('.box_7_6').classList.remove('cash_red');
        if(letter_7_6==='M'){
          document.querySelector('.box_7_6').classList.add('letter_m');
          var first_letter=document.querySelector('.box_7_6').innerHTML=letter_7_6;
        }else if(letter_7_6==='I'){
          document.querySelector('.box_7_6').classList.add('letter_i');
          var first_letter=document.querySelector('.box_7_6').innerHTML=letter_7_6;
        }else if(letter_7_6==='J'){
          document.querySelector('.box_7_6').classList.add('letter_j');
          var first_letter=document.querySelector('.box_7_6').innerHTML=letter_7_6;
        }else if(letter_7_6==='W'){
          document.querySelector('.box_7_6').classList.add('letter_w');
          var first_letter=document.querySelector('.box_7_6').innerHTML=letter_7_6;
        }else{
          var first_letter=document.querySelector('.box_7_6').innerHTML=letter_7_6;
        }
        


      }});

      var cash_7_7_minus= -Math.round((.14 * questionCash));
      var cash_7_7=0;
      var total_7_percent_7=0;
      gsap.timeline().from(".box_7_7",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:2,onStart:wrongLetterTone_7});
      gsap.timeline().from(".box_7_7",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
        document.querySelector('.box_7_7').classList.add('border_red');
        document.querySelector('.box_7_7').classList.add('cash_red');
        var first_letter=document.querySelector('.box_7_7').innerHTML='x';
  
  
      }});
  
      gsap.timeline().from(".box_7_7",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:2.3,onStart:function(){
        document.querySelector('.box_7_7').innerHTML='';
        document.querySelector('.box_7_7').classList.add('border_red');
        document.querySelector('.box_7_7').classList.remove('cash_red');
        if(letter_7_7==='M'){
          document.querySelector('.box_7_7').classList.add('letter_m');
          var first_letter=document.querySelector('.box_7_7').innerHTML=letter_7_7;
        }else if(letter_7_7==='I'){
          document.querySelector('.box_7_7').classList.add('letter_i');
          var first_letter=document.querySelector('.box_7_7').innerHTML=letter_7_7;
        }else if(letter_7_7==='J'){
          document.querySelector('.box_7_7').classList.add('letter_j');
          var first_letter=document.querySelector('.box_7_7').innerHTML=letter_7_7;
        }else if(letter_7_7==='W'){
          document.querySelector('.box_7_7').classList.add('letter_w');
          var first_letter=document.querySelector('.box_7_7').innerHTML=letter_7_7;
        }else{
          var first_letter=document.querySelector('.box_7_7').innerHTML=letter_7_7;
        }
        
  
  
      }});
      
      
      total7cashMinus=(cash_7_1_minus+cash_7_2_minus+cash_7_3_minus+cash_7_4_minus+cash_7_5_minus+cash_7_6_minus + cash_7_7_minus);
      percentage_7_minus=(total_7_percent_1 + total_7_percent_2 + total_7_percent_3 + total_7_percent_4 + total_7_percent_5 + total_7_percent_6 + total_7_percent_7  );  
         audienceMinusTone();
          gsap.timeline().from(".points",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:2.7});
          gsap.timeline().to(".points",{duration:1,opacity:1,scale:0,x:0,ease:"back",delay:2.7,onStart:loseMoneyTone});
  
  
          

        document.querySelector('.points').innerHTML='-'+ '$'+ -total7cashMinus;
        
        document.querySelector('.points').classList.add('cash_red');
      
        main_score= Math.ceil(main_score+total7cashMinus);
        
        letter_total=7;
        letter_count=letter_total+letter_count;
        
     total_percent =total_percent+percentage_7_minus;
     var percent_total=document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100);
     if(percent_total===0 || percent_total<10){
       document.querySelector('.score_card').classList.remove('percent_padding_100');
       document.querySelector('.score_card').classList.remove('percent_padding_10');
       
       document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
     }else if(percent_total>10 && percent_total<99){
       document.querySelector('.score_card').classList.add('percent_padding_10');
       document.querySelector('.score_card').classList.remove('percent_padding_100');
       
       document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
     }else if(percent_total===100){
       document.querySelector('.score_card').classList.add('percent_padding_100');
       document.querySelector('.score_card').classList.remove('percent_padding_10');
      
       document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
     }
        
     
      if(main_score<=5){
        
        $(".cover ").show();
          $(".game_over ").show();
          document.querySelector('.start_over').addEventListener('click',function(){
            location.reload(true);
          });
      }if(main_score <10){
        document.querySelector('.score_card_1').classList.add('score_card_1_padding');
        document.querySelector('.score_card_1').innerHTML=main_score;
      }else if(main_score>=10 && main_score<100){
        document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
        document.querySelector('.score_card_1').classList.add('score_card_10_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
        document.querySelector('.score_card_1').innerHTML=main_score;
      }else if(main_score>=100 && main_score<1000){
        document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
        document.querySelector('.score_card_1').classList.add('score_card_100_padding');
        document.querySelector('.score_card_1').innerHTML=main_score;
      }else if(main_score>=1000 && main_score<=10000){
        document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
        document.querySelector('.score_card_1').classList.add('score_card_1000_padding');
        document.querySelector('.score_card_1').innerHTML=main_score;
      }else if(main_score>=10000 && main_score<=100000){
        document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
        document.querySelector('.score_card_1').classList.remove('score_card_1000_padding');
        document.querySelector('.score_card_1').classList.add('score_card_10000_padding');
        document.querySelector('.score_card_1').innerHTML=main_score;
  
      }
      
      document.querySelector('.players_cash').innerHTML=' '+'$'+main_score;
      document.querySelector('.players_cash_1').innerHTML=' '+'$'+main_score;
    
      var seventh_letter=document.querySelector('.write_box_7_7').childNodes[13].innerHTML="x";
     letter_input=amount_of_letters;
    

}if(amount_of_letters===8){
  var cash_8_1_minus= -Math.round((.12 * questionCash));
  var cash_8_1=0;
  var total_8_percent_1=0;
  gsap.timeline().from(".box_8_1",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.1,onStart:wrongLetterTone_1});
  gsap.timeline().from(".box_8_1",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
    document.querySelector('.box_8_1').classList.add('border_red');
    document.querySelector('.box_8_1').classList.add('cash_red');
    var first_letter=document.querySelector('.box_8_1').innerHTML='x';


  }});

  gsap.timeline().from(".box_8_1",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:.4,onStart:function(){
    document.querySelector('.box_8_1').innerHTML='';
    document.querySelector('.box_8_1').classList.add('border_red');
    document.querySelector('.box_8_1').classList.remove('cash_red');
    if(letter_8_1==='M'){
      document.querySelector('.box_8_1').classList.add('letter_m');
      var first_letter=document.querySelector('.box_8_1').innerHTML=letter_8_1;
    }else if(letter_8_1==='I'){
      document.querySelector('.box_8_1').classList.add('letter_i');
      var first_letter=document.querySelector('.box_8_1').innerHTML=letter_8_1;
    }else if(letter_8_1==='J'){
      document.querySelector('.box_8_1').classList.add('letter_j');
      var first_letter=document.querySelector('.box_8_1').innerHTML=letter_8_1;
    }else if(letter_8_1==='W'){
      document.querySelector('.box_8_1').classList.add('letter_w');
      var first_letter=document.querySelector('.box_8_1').innerHTML=letter_8_1;
    }else{
      var first_letter=document.querySelector('.box_8_1').innerHTML=letter_8_1;
    }
    


  }});

  var cash_8_2_minus= -Math.round((.12 * questionCash));
    var cash_8_2=0;
    var total_8_percent_2=0;
    gsap.timeline().from(".box_8_2",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.4,onStart:wrongLetterTone_2});
    gsap.timeline().from(".box_8_2",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_8_2').classList.add('border_red');
      document.querySelector('.box_8_2').classList.add('cash_red');
      var first_letter=document.querySelector('.box_8_2').innerHTML='x';


    }});

    gsap.timeline().from(".box_8_2",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:.7,onStart:function(){
      document.querySelector('.box_8_2').innerHTML='';
      document.querySelector('.box_8_2').classList.add('border_red');
      document.querySelector('.box_8_2').classList.remove('cash_red');
      if(letter_8_2==='M'){
        document.querySelector('.box_8_2').classList.add('letter_m');
        var first_letter=document.querySelector('.box_8_2').innerHTML=letter_8_2;
      }else if(letter_8_2==='I'){
        document.querySelector('.box_8_2').classList.add('letter_i');
        var first_letter=document.querySelector('.box_8_2').innerHTML=letter_8_2;
      }else if(letter_8_2==='J'){
        document.querySelector('.box_8_2').classList.add('letter_j');
        var first_letter=document.querySelector('.box_8_2').innerHTML=letter_8_2;
      }else if(letter_8_2==='W'){
        document.querySelector('.box_8_2').classList.add('letter_w');
        var first_letter=document.querySelector('.box_8_2').innerHTML=letter_8_2;
      }else{
        var first_letter=document.querySelector('.box_8_2').innerHTML=letter_8_2;
      }
      


    }});

    var cash_8_3_minus= -Math.round((.12 * questionCash));
    var cash_8_3=0;
    var total_8_percent_3=0;
    gsap.timeline().from(".box_8_3",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:.7,onStart:wrongLetterTone_3});
    gsap.timeline().from(".box_8_3",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_8_3').classList.add('border_red');
      document.querySelector('.box_8_3').classList.add('cash_red');
      var first_letter=document.querySelector('.box_8_3').innerHTML='x';


    }});

    gsap.timeline().from(".box_8_3",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1,onStart:function(){
      document.querySelector('.box_8_3').innerHTML='';
      document.querySelector('.box_8_3').classList.add('border_red');
      document.querySelector('.box_8_3').classList.remove('cash_red');
      if(letter_8_3==='M'){
        document.querySelector('.box_8_3').classList.add('letter_m');
        var first_letter=document.querySelector('.box_8_3').innerHTML=letter_8_3;
      }else if(letter_8_3==='I'){
        document.querySelector('.box_8_3').classList.add('letter_i');
        var first_letter=document.querySelector('.box_8_3').innerHTML=letter_8_3;
      }else if(letter_8_3==='J'){
        document.querySelector('.box_8_3').classList.add('letter_j');
        var first_letter=document.querySelector('.box_8_1').innerHTML=letter_8_3;
      }else if(letter_8_3==='W'){
        document.querySelector('.box_8_3').classList.add('letter_w');
        var first_letter=document.querySelector('.box_8_3').innerHTML=letter_8_3;
      }else{
        var first_letter=document.querySelector('.box_8_3').innerHTML=letter_8_3;
      }
      


    }});
    var cash_8_4_minus= -Math.round((.12 * questionCash));
    var cash_8_4=0;
    var total_8_percent_4=0;
    gsap.timeline().from(".box_8_4",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1,onStart:wrongLetterTone_4});
    gsap.timeline().from(".box_8_4",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_8_4').classList.add('border_red');
      document.querySelector('.box_8_4').classList.add('cash_red');
      var first_letter=document.querySelector('.box_8_4').innerHTML='x';


    }});

    gsap.timeline().from(".box_8_4",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1.3,onStart:function(){
      document.querySelector('.box_8_4').innerHTML='';
      document.querySelector('.box_8_4').classList.add('border_red');
      document.querySelector('.box_8_4').classList.remove('cash_red');
      if(letter_8_4==='M'){
        document.querySelector('.box_8_4').classList.add('letter_m');
        var first_letter=document.querySelector('.box_8_4').innerHTML=letter_8_4;
      }else if(letter_8_4==='I'){
        document.querySelector('.box_8_4').classList.add('letter_i');
        var first_letter=document.querySelector('.box_8_4').innerHTML=letter_8_4;
      }else if(letter_8_4==='J'){
        document.querySelector('.box_8_4').classList.add('letter_j');
        var first_letter=document.querySelector('.box_8_4').innerHTML=letter_8_4;
      }else if(letter_8_4==='W'){
        document.querySelector('.box_8_4').classList.add('letter_w');
        var first_letter=document.querySelector('.box_8_4').innerHTML=letter_8_4;
      }else{
        var first_letter=document.querySelector('.box_8_4').innerHTML=letter_8_4;
      }
      


    }});
    var cash_8_5_minus= -Math.round((.12 * questionCash));
    var cash_8_5=0;
    var total_8_percent_5=0;
    gsap.timeline().from(".box_8_5",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1.3,onStart:wrongLetterTone_5});
    gsap.timeline().from(".box_8_5",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
      document.querySelector('.box_8_5').classList.add('border_red');
      document.querySelector('.box_8_5').classList.add('cash_red');
      var first_letter=document.querySelector('.box_8_5').innerHTML='x';


    }});

    gsap.timeline().from(".box_8_5",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:1.6,onStart:function(){
      document.querySelector('.box_8_5').innerHTML='';
      document.querySelector('.box_8_5').classList.add('border_red');
      document.querySelector('.box_8_5').classList.remove('cash_red');
      if(letter_8_5==='M'){
        document.querySelector('.box_8_5').classList.add('letter_m');
        var first_letter=document.querySelector('.box_8_5').innerHTML=letter_8_5;
      }else if(letter_8_5==='I'){
        document.querySelector('.box_8_5').classList.add('letter_i');
        var first_letter=document.querySelector('.box_8_5').innerHTML=letter_8_5;
      }else if(letter_8_5==='J'){
        document.querySelector('.box_8_5').classList.add('letter_j');
        var first_letter=document.querySelector('.box_8_5').innerHTML=letter_8_5;
      }else if(letter_8_5==='W'){
        document.querySelector('.box_8_5').classList.add('letter_w');
        var first_letter=document.querySelector('.box_8_5').innerHTML=letter_8_5;
      }else{
        var first_letter=document.querySelector('.box_8_5').innerHTML=letter_8_5;
      }
      


    }});

    var cash_8_6_minus= -Math.round((.12 * questionCash));
  var cash_8_6=0;
  var total_8_percent_6=0;
  gsap.timeline().from(".box_8_6",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:1.6,onStart:wrongLetterTone_6});
  gsap.timeline().from(".box_8_6",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
    document.querySelector('.box_8_6').classList.add('border_red');
    document.querySelector('.box_8_6').classList.add('cash_red');
    var first_letter=document.querySelector('.box_8_6').innerHTML='x';


  }});

  gsap.timeline().from(".box_8_6",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:2,onStart:function(){
    document.querySelector('.box_8_6').innerHTML='';
    document.querySelector('.box_8_6').classList.add('border_red');
    document.querySelector('.box_8_6').classList.remove('cash_red');
    if(letter_8_6==='M'){
      document.querySelector('.box_8_6').classList.add('letter_m');
      var first_letter=document.querySelector('.box_8_6').innerHTML=letter_8_6;
    }else if(letter_8_6==='I'){
      document.querySelector('.box_8_6').classList.add('letter_i');
      var first_letter=document.querySelector('.box_8_6').innerHTML=letter_8_6;
    }else if(letter_8_6==='J'){
      document.querySelector('.box_8_6').classList.add('letter_j');
      var first_letter=document.querySelector('.box_8_6').innerHTML=letter_8_6;
    }else if(letter_8_6==='W'){
      document.querySelector('.box_8_6').classList.add('letter_w');
      var first_letter=document.querySelector('.box_8_6').innerHTML=letter_8_6;
    }else{
      var first_letter=document.querySelector('.box_8_6').innerHTML=letter_8_6;
    }
    


  }});

  var cash_8_7_minus= -Math.round((.12 * questionCash));
  var cash_8_7=0;
  var total_8_percent_7=0;
  gsap.timeline().from(".box_8_7",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:2,onStart:wrongLetterTone_7});
  gsap.timeline().from(".box_8_7",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
    document.querySelector('.box_8_7').classList.add('border_red');
    document.querySelector('.box_8_7').classList.add('cash_red');
    var first_letter=document.querySelector('.box_8_7').innerHTML='x';


  }});

  gsap.timeline().from(".box_8_7",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:2.3,onStart:function(){
    document.querySelector('.box_8_7').innerHTML='';
    document.querySelector('.box_8_7').classList.add('border_red');
    document.querySelector('.box_8_7').classList.remove('cash_red');
    if(letter_8_7==='M'){
      document.querySelector('.box_8_7').classList.add('letter_m');
      var first_letter=document.querySelector('.box_8_7').innerHTML=letter_8_7;
    }else if(letter_8_7==='I'){
      document.querySelector('.box_8_7').classList.add('letter_i');
      var first_letter=document.querySelector('.box_8_7').innerHTML=letter_8_7;
    }else if(letter_8_7==='J'){
      document.querySelector('.box_8_7').classList.add('letter_j');
      var first_letter=document.querySelector('.box_8_7').innerHTML=letter_8_7;
    }else if(letter_8_7==='W'){
      document.querySelector('.box_8_7').classList.add('letter_w');
      var first_letter=document.querySelector('.box_8_7').innerHTML=letter_8_7;
    }else{
      var first_letter=document.querySelector('.box_8_7').innerHTML=letter_8_7;
    }
    


  }});
  var cash_8_8_minus= -Math.round((.12 * questionCash));
  var cash_8_8=0;
  var total_8_percent_8=0;
  gsap.timeline().from(".box_8_8",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:2.3,onStart:wrongLetterTone_8});
  gsap.timeline().from(".box_8_8",{duration:1,opacity:1,scale:1,x:0,ease: "power1",onStart:function(){
    document.querySelector('.box_8_8').classList.add('border_red');
    document.querySelector('.box_8_8').classList.add('cash_red');
    var first_letter=document.querySelector('.box_8_8').innerHTML='x';


  }});

  gsap.timeline().from(".box_8_8",{duration:1,opacity:1,scale:1,x:0,ease:"back",delay:2.6,onStart:function(){
    document.querySelector('.box_8_8').innerHTML='';
    document.querySelector('.box_8_8').classList.add('border_red');
    document.querySelector('.box_8_8').classList.remove('cash_red');
    if(letter_8_8==='M'){
      document.querySelector('.box_8_8').classList.add('letter_m');
      var first_letter=document.querySelector('.box_8_8').innerHTML=letter_8_8;
    }else if(letter_8_8==='I'){
      document.querySelector('.box_8_8').classList.add('letter_i');
      var first_letter=document.querySelector('.box_8_8').innerHTML=letter_8_8;
    }else if(letter_8_8==='J'){
      document.querySelector('.box_8_8').classList.add('letter_j');
      var first_letter=document.querySelector('.box_8_8').innerHTML=letter_8_8;
    }else if(letter_8_8==='W'){
      document.querySelector('.box_8_8').classList.add('letter_w');
      var first_letter=document.querySelector('.box_8_8').innerHTML=letter_8_8;
    }else{
      var first_letter=document.querySelector('.box_8_8').innerHTML=letter_8_8;
    }
    


  }});
  
  
     total8cashMinus=(cash_8_1_minus+cash_8_2_minus+cash_8_3_minus+cash_8_4_minus+cash_8_5_minus+cash_8_6_minus + cash_8_7_minus + cash_8_8_minus);
     percentage_8_minus=(total_8_percent_1 + total_8_percent_2 + total_8_percent_3 + total_8_percent_4 + total_8_percent_5 + total_8_percent_6 + total_8_percent_7 + total_8_percent_8 ); 
      audienceMinusTone();
      gsap.timeline().from(".points",{duration:1,opacity:0,scale:0,x:0,ease:"back",delay:2.7});
      gsap.timeline().to(".points",{duration:1,opacity:1,scale:0,x:0,ease:"back",delay:2.7,onStart:loseMoneyTone});

    
  

    
     

  
    
  
   
  document.querySelector('.points').innerHTML='-'+ '$'+ -total8cashMinus;
    
    document.querySelector('.points').classList.add('cash_red');
main_score= Math.ceil(main_score+total8cashMinus);
    
    letter_total=8;
    letter_count=letter_total+letter_count;
    
 total_percent =total_percent+percentage_8_minus;
 var percent_total=document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100);
 if(percent_total===0 || percent_total<10){
   document.querySelector('.score_card').classList.remove('percent_padding_100');
   document.querySelector('.score_card').classList.remove('percent_padding_10');
   
   document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
 }else if(percent_total>10 && percent_total<99){
   document.querySelector('.score_card').classList.add('percent_padding_10');
   document.querySelector('.score_card').classList.remove('percent_padding_100');
   
   document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
 }else if(percent_total===100){
   document.querySelector('.score_card').classList.add('percent_padding_100');
   document.querySelector('.score_card').classList.remove('percent_padding_10');
   
   document.querySelector('.score_card ').innerHTML=Math.ceil(total_percent/letter_count *100)+"%";
 }
    
  
  if(main_score<=5){
    ;
    $(".cover ").show();
      $(".game_over ").show();
      document.querySelector('.start_over').addEventListener('click',function(){
        location.reload(true);
      });
  }if(main_score <10){
    document.querySelector('.score_card_1').classList.add('score_card_1_padding');
    document.querySelector('.score_card_1').innerHTML=main_score;
  }else if(main_score>=10 && main_score<100){
    document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
    document.querySelector('.score_card_1').classList.add('score_card_10_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
    document.querySelector('.score_card_1').innerHTML=main_score;
  }else if(main_score>=100 && main_score<1000){
    document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
    document.querySelector('.score_card_1').classList.add('score_card_100_padding');
    document.querySelector('.score_card_1').innerHTML=main_score;
  }else if(main_score>=1000 && main_score<=10000){
    document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
    document.querySelector('.score_card_1').classList.add('score_card_1000_padding');
    document.querySelector('.score_card_1').innerHTML=main_score;
  }else if(main_score>=10000 && main_score<=100000){
    document.querySelector('.score_card_1').classList.remove('score_card_1_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_10_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_100_padding');
    document.querySelector('.score_card_1').classList.remove('score_card_1000_padding');
    document.querySelector('.score_card_1').classList.add('score_card_10000_padding');
    document.querySelector('.score_card_1').innerHTML=main_score;

  }
  document.querySelector('.players_cash').innerHTML=' '+'$'+main_score;
  document.querySelector('.players_cash_1').innerHTML=' '+'$'+main_score;

  document.querySelector('.write_box_8_8').childNodes[15].innerHTML="x";


}






};

//cause vowel box to pop up and start timer
document.querySelector('.vowelBox').addEventListener('click', function(){
  clock_pause();
  
  play1();
  
   isPaused=true;
  

    
  timeLefts = 10;
  element = document.querySelector('.time_choose_vowel');
  timerIds = setInterval(countdown1, 1000);
function countdown1() {
   if (timeLefts == -1) {
     
      clearTimeout(timerIds);
      hideVowelBox();
    } else  {
      
       element.innerHTML = timeLefts ;
       timeLefts--;
    
   
   }
 }



});

//function to hide vowel box and get vowel button
function hideVowelBox(){
  $(".buy_vowel").hide();
  $(".vowelBox").hide();
  document.querySelector('.returnBox').classList.add('category_return_boost');
  clock_play_vowel();
  vowelCountDownPause();
  clearTimeout(timerIds);
 
  isPaused=false;
}


document.querySelector('.vowel_button').addEventListener('click',hideVowelBox);
document.querySelector('.close').addEventListener('click',hideVowelBox);



///hide number of letter boxes and close icon
document.querySelector('.number_of_letters_typed').classList.add('hide_boxes');
  document.querySelector('.amount_of_letters').classList.add('hide_boxes');
  document.querySelector('.close_button').classList.add('hide_boxes');
document.querySelector('.error_input_field').classList.add('hide_boxes');
 

//submit the answer
var giveSubmit=document.querySelector('.submit_button').addEventListener('click',getValueInput);




//determine if there is too many or not enough letters in input box for answer





function goToNextQuestion(){
  $(".submit_button ").attr("disabled",false);
  $(".choose_next_question_category").hide();
  $(".place_bet_box ").show();
  $(".cover ").show();
  $(".question_box").hide();
 
}


 

  function getListeners(){
    document.querySelector('.submit_button').addEventListener('click',getErrorBox);
    document.querySelector('.nextBox').addEventListener('click',getErrorBox);
    document.querySelector('.returnBox').addEventListener('click',getErrorBox);
    
    if(category_chosen==='60\'s Rock Bands'){
      
     
      document.querySelector('.nextBox').removeEventListener('click',RockBand60sQuestionsTracker);
      document.querySelector('.nextBox').removeEventListener('click',goToNextQuestion);
    }else if(category_chosen==='State Capitals'){
      
      
      document.querySelector('.nextBox').removeEventListener('click',StateCapitalsQuestionsTracker);
      document.querySelector('.nextBox').removeEventListener('click',goToNextQuestion);

    }else if(category_chosen==='World History'){
      
      
      document.querySelector('.nextBox').removeEventListener('click',WorldHistoryQuestionsTracker);
      document.querySelector('.nextBox').removeEventListener('click',goToNextQuestion);

    }else if(category_chosen==='American Sports'){
      
      
      document.querySelector('.nextBox').removeEventListener('click',AmericanSportsQuestionsTracker);
      document.querySelector('.nextBox').removeEventListener('click',goToNextQuestion);

    }else if(category_chosen==='Famous Authors'){
      
      
      document.querySelector('.nextBox').removeEventListener('click',FamousAuthorsQuestionsTracker);
      document.querySelector('.nextBox').removeEventListener('click',goToNextQuestion);

    }else if(category_chosen==='Vacation Spots'){
      
      
      document.querySelector('.nextBox').removeEventListener('click',VacationSpotsQuestionsTracker);
      document.querySelector('.nextBox').removeEventListener('click',goToNextQuestion);

    }else if(category_chosen==='One Hit Wonders'){
      
      
      document.querySelector('.nextBox').removeEventListener('click',OneHitWondersQuestionsTracker);
      document.querySelector('.nextBox').removeEventListener('click',goToNextQuestion);

    }else if(category_chosen==='Famous Places'){
      
      
      document.querySelector('.nextBox').removeEventListener('click',FamousPlacesQuestionsTracker);
      document.querySelector('.nextBox').removeEventListener('click',goToNextQuestion);

    }else if(category_chosen==='Fast Food'){
      
      
      document.querySelector('.nextBox').removeEventListener('click',FastFoodQuestionsTracker);
      document.querySelector('.nextBox').removeEventListener('click',goToNextQuestion);

    }
    
    
  
  
    $(".returnBox").click(function(){
      $(".returnBox ").attr("disabled",true);
      $('.question_box').show();
      $('.time_control').show();
      $('.players_box').show();
      $(".categories_box").hide();
      $(".logo_holder ").show();
      $(".logo_holder_1 ").hide();
      $(".rules_back_button ").hide();
      
      
    });

   
  
  
  
 
  }



  function releaseListeners(){
    document.querySelector('.submit_button').removeEventListener('click',getErrorBox);
  document.querySelector('.nextBox').removeEventListener('click',getErrorBox);
  document.querySelector('.returnBox').removeEventListener('click',getErrorBox);
    
    
 if(category_chosen==='60\'s Rock Bands'){
  
  
  document.querySelector('.nextBox').addEventListener('click',RockBand60sQuestionsTracker);
  document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);
 }else if(category_chosen==='State Capitals'){
  
  
  document.querySelector('.nextBox').addEventListener('click',StateCapitalsQuestionsTracker);
  document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);

 }else if(category_chosen==='World History'){
  
  
  document.querySelector('.nextBox').addEventListener('click',WorldHistoryQuestionsTracker);
  document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);

 }else if(category_chosen==='American Sports'){
  
  
  document.querySelector('.nextBox').addEventListener('click',AmericanSportsQuestionsTracker);
  document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);

 }else if(category_chosen==='Famous Authors'){
  
  
  document.querySelector('.nextBox').addEventListener('click',FamousAuthorsQuestionsTracker);
  document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);

 }else if(category_chosen==='Vacation Spots'){
      
      
  document.querySelector('.nextBox').addEventListener('click',VacationSpotsQuestionsTracker);
  document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);

}else if(category_chosen==='One Hit Wonders'){
      
      
  document.querySelector('.nextBox').addEventListener('click',OneHitWondersQuestionsTracker);
  document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);

}else if(category_chosen==='Famous Places'){
      
      
  document.querySelector('.nextBox').addEventListener('click',FamousPlacesQuestionsTracker);
  document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);

}else if(category_chosen==='Fast Food'){
      
      
  document.querySelector('.nextBox').addEventListener('click',FastFoodQuestionsTracker);
  document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);

}
 
  
  
  $(document).ready(function(){
    $(".returnBox").click(function(){
      $(".returnBox ").attr("disabled",false);
      $('.question_box').hide();
      $('.time_control').hide();
      $('.players_box').hide();
      $(".categories_box").show();
      $(".logo_holder ").hide();
      $(".logo_holder_1 ").show();
      $(".rules_back_button ").show();
      
    });
  });
 
  }
  











  function getErrorBox(){
  if(letter_input===''|| n<amount_of_letters){
    document.querySelector('.error_input_field').classList.add('show_boxes');
    document.querySelector('.error_input_field').classList.remove('hide_boxes');
    document.querySelector('.points').innerHTML='';
    document.querySelector('.type_answer').value;
  
    document.querySelector('.number_of_letters_typed').classList.remove('hide_boxes');
    document.querySelector('.amount_of_letters').classList.remove('hide_boxes');
    document.querySelector('.number_of_letters_typed').classList.add('show_boxes');
    document.querySelector('.amount_of_letters').classList.add('show_boxes');
    
    if(category_chosen==='60\'s Rock Bands'){
      document.querySelector('.nextBox').removeEventListener('click',goToNextQuestion);
      document.querySelector('.nextBox').removeEventListener('click',RockBand60sQuestionsTracker);

    }else if(category_chosen==='State Capitals'){
      document.querySelector('.nextBox').removeEventListener('click',goToNextQuestion);
      document.querySelector('.nextBox').removeEventListener('click',StateCapitalsQuestionsTracker);

    }else if(category_chosen==='World History'){
      document.querySelector('.nextBox').removeEventListener('click',goToNextQuestion);
      document.querySelector('.nextBox').removeEventListener('click',WorldHistoryQuestionsTracker);

    }else if(category_chosen==='American Sports'){
      document.querySelector('.nextBox').removeEventListener('click',goToNextQuestion);
      document.querySelector('.nextBox').removeEventListener('click',AmericanSportsQuestionsTracker);

    }else if(category_chosen==='Famous Authors'){
      document.querySelector('.nextBox').removeEventListener('click',goToNextQuestion);
      document.querySelector('.nextBox').removeEventListener('click',FamousAuthorsQuestionsTracker);

    }else if(category_chosen==='Vacation Spots'){
      document.querySelector('.nextBox').removeEventListener('click',goToNextQuestion);
      document.querySelector('.nextBox').removeEventListener('click',VacationSpotsQuestionsTracker);

    }else if(category_chosen==='One Hit Wonders'){
      document.querySelector('.nextBox').removeEventListener('click',goToNextQuestion);
      document.querySelector('.nextBox').removeEventListener('click',OneHitWondersQuestionsTracker);

    }else if(category_chosen==='Famous Places'){
      document.querySelector('.nextBox').removeEventListener('click',goToNextQuestion);
      document.querySelector('.nextBox').removeEventListener('click',FamousPlacesQuestionsTracker);

    }else if(category_chosen==='Fast Food'){
      document.querySelector('.nextBox').removeEventListener('click',goToNextQuestion);
      document.querySelector('.nextBox').removeEventListener('click',FastFoodQuestionsTracker);

    }
    
   
   

  }else if(n===amount_of_letters && letter_input!='') {
    document.querySelector('.type_answer').value='';
     if(category_chosen==='60\'s Rock Bands'){
      
      document.querySelector('.nextBox').addEventListener('click',RockBand60sQuestionsTracker);
      document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);
     }else if(category_chosen==='State Capitals'){
     
      document.querySelector('.nextBox').addEventListener('click',StateCapitalsQuestionsTracker);
      document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);

     }else if(category_chosen==='World History'){
     
      document.querySelector('.nextBox').addEventListener('click',WorldHistoryQuestionsTracker);
      document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);

     }else if(category_chosen==='American Sports'){
     
      document.querySelector('.nextBox').addEventListener('click',AmericanSportsQuestionsTracker);
      document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);

     }else if(category_chosen==='Famous Authors'){
     
      document.querySelector('.nextBox').addEventListener('click',FamousAuthorsQuestionsTracker);
      document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);

     }else if(category_chosen==='Vacation Spots'){
      document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);
      document.querySelector('.nextBox').addEventListener('click',VacationSpotsQuestionsTracker);

    }else if(category_chosen==='One Hit Wonders'){
      document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);
      document.querySelector('.nextBox').addEventListener('click',OneHitWondersQuestionsTracker);

    }else if(category_chosen==='Famous Places'){
      document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);
      document.querySelector('.nextBox').addEventListener('click',FamousPlacesQuestionsTracker);

    }else if(category_chosen==='Fast Food'){
      document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);
      document.querySelector('.nextBox').addEventListener('click',FastFoodQuestionsTracker);

    }
     
      
     
      
      $(document).ready(function(){
        $(".returnBox").click(function(){
          $(".returnBox ").attr("disabled",false);
          $('.question_box').hide();
          $('.time_control').hide();
          $('.players_box').hide();
          $(".categories_box").show();
          $(".logo_holder ").hide();
          $(".logo_holder_1 ").show();
          $(".rules_back_button ").show();
          
          
        });
      });
      
  } else if(n>amount_of_letters && letter_input!='' ){
    document.querySelector('.type_answer').value='';
    if(category_chosen==='60\'s Rock Bands'){
      document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);
      document.querySelector('.nextBox').addEventListener('click',RockBand60sQuestionsTracker);

    }else if(category_chosen==='State Capitals'){
      document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);
      document.querySelector('.nextBox').addEventListener('click',StateCapitalsQuestionsTracker);
    }else if(category_chosen==='World History'){
      document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);
      document.querySelector('.nextBox').addEventListener('click',WorldHistoryQuestionsTracker);
    }else if(category_chosen==='American Sports'){
      document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);
      document.querySelector('.nextBox').addEventListener('click',AmericanSportsQuestionsTracker);
    }else if(category_chosen==='Famous Authors'){
      document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);
      document.querySelector('.nextBox').addEventListener('click',FamousAuthorsQuestionsTracker);
    }else if(category_chosen==='Vacation Spots'){
      document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);
      document.querySelector('.nextBox').addEventListener('click',VacationSpotsQuestionsTracker);

    }else if(category_chosen==='One Hit Wonders'){
      document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);
      document.querySelector('.nextBox').addEventListener('click',OneHitWondersQuestionsTracker);

    }else if(category_chosen==='Famous Places'){
      document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);
      document.querySelector('.nextBox').addEventListener('click',FamousPlacesQuestionsTracker);

    }else if(category_chosen==='Fast Food'){
      document.querySelector('.nextBox').addEventListener('click',goToNextQuestion);
      document.querySelector('.nextBox').addEventListener('click',FastFoodQuestionsTracker);

    }
    
    
    
   
    $(document).ready(function(){
      $(".returnBox").click(function(){
        $(".returnBox ").attr("disabled",false);
        $('.question_box').hide();
        $('.time_control').hide();
        $('.players_box').hide();
        $(".categories_box").show();
        $(".logo_holder ").hide();
        $(".logo_holder_1 ").show();
        $(".rules_back_button ").show();
        
      });
    });
   
  } 
};




document.querySelector('.close_box').addEventListener('click',function(){
  
   
    document.querySelector('.error_input_field').classList.add('hide_boxes');
    document.querySelector('.error_input_field').classList.remove('show_boxes');
    document.querySelector('.cover').classList.add('show_boxes');
   
  
  


});

//change text on button for players cash shown on responsive size
var CashButton=document.querySelector('.check_cash');
function changeText(){
  if(CashButton.innerHTML==='show cash'){
    CashButton.innerHTML='hide cash';
  }else if(CashButton.innerHTML==='hide cash'){
    CashButton.innerHTML='show cash';
  }


}

document.querySelector('.check_cash').addEventListener('click',changeText);










function removeSubmitInput(){
  gsap.to(".disappear", {duration: 3, x: 300, opacity: 0, scale: 0.5});
  
}





//get the count of amount of letters typed into input box
document.querySelector('.type_answer').addEventListener('keydown', getLetterCount);

//calculate the amount of letters to be typed into input box for clue answer
function getLetterCount(){
  letter_input=document.querySelector('.type_answer').value.toUpperCase();
  


   n= letter_input.length+1;
   letters_left=amount_of_letters-n;
   

  
  document.querySelector('.number_of_letters_typed').classList.add('show_boxes');
  document.querySelector('.amount_of_letters').classList.add('show_boxes');
  document.querySelector('.number_of_letters_typed').classList.remove('hide_boxes');
  document.querySelector('.amount_of_letters').classList.remove('hide_boxes');
  document.querySelector('.close_button').classList.add('show_boxes');
  document.querySelector('.close_button').classList.remove('hide_boxes');

  document.querySelector('.close_button').addEventListener('click',function(){

 document.querySelector('.error_input_field').classList.add('hide_boxes');


  });
  ///amount_of_letters is the letter count under the clue on question box
  ///n equals the number of letters that the player inputss into input field
  if(n<=amount_of_letters){
   
  var type=   document.querySelector('.number_of_letters_typed').innerHTML=letters_left;
     document.querySelector(".number_of_letters_typed").style.color = "black";
      
    
     
   }
  else if(n>=amount_of_letters){
   
    
  var back_type=  document.querySelector('.number_of_letters_typed').innerHTML=letters_left;
    //document.querySelector(".number_of_letters_typed").style.color = "red";
    //document.querySelector(".amount_of_letters").style.color = "red";
  
  }if(letters_left<=-1 || letters_left<0){
    document.querySelector(".number_of_letters_typed").style.color = "red";
    document.querySelector('.error_input_field').classList.add('show_boxes');
    document.querySelector('.error_input_field').classList.remove('hide_boxes');
  }if(letters_left===''){
   letters_left=n;
  }if(letters_left===-1){
    document.querySelector('.error_input_field').classList.add('show_boxes');
    document.querySelector('.error_input_field').classList.remove('hide_boxes');
  }
};

//add 2 to answer on input field when using return key
document.querySelector('.type_answer').addEventListener('keydown', function (event){
 var input_field= document.querySelector('.type_answer');
  if (event.keyCode == 8 ) {
     document.querySelector('.number_of_letters_typed').innerHTML=letters_left+2;
    
  }if(event.keyCode == 8 && letters_left>=-2){
    document.querySelector(".number_of_letters_typed").style.color = "black";
    document.querySelector('.error_input_field').classList.remove('show_boxes');
    document.querySelector('.error_input_field').classList.add('hide_boxes');
  }if(event.keyCode==8 && input_field.value.length==0 ){
    document.querySelector('.number_of_letters_typed').innerHTML=letters_left+1;
  }
  
});

//clear input field



//clear input field of textbox
document.querySelector('.close_button').addEventListener('click',function(){
document.querySelector('.type_answer').value='';
document.querySelector('.number_of_letters_typed').innerHTML=amount_of_letters;
document.querySelector(".number_of_letters_typed").style.color = "black";



});



//add players betting box to ui
document.querySelector('.place_bet_box').classList.add('hide_boxes');
document.querySelector('.cover').classList.add('hide_boxes');
document.querySelector('.bet_warning').classList.add('hide_boxes');

//keep track of bets on questions and control if no bet made
var questionCash=[];
document.querySelector('.betters_button').addEventListener('click', cashBetGenereator);



function cashBetGenereator(){
  //document.querySelector('.submit_button').addEventListener('click',getValueInput);
  letter_input='';
 
  questionCash=document.querySelector('.betters_input').value;
   document.querySelector('.betters_input').value='';
   if(questionCash===''||questionCash<5 || questionCash>main_score){
    document.querySelector('.bet_warning').classList.add('show_boxes');
    document.querySelector('.bet_warning').classList.remove('hide_boxes');
    document.querySelector('.betters_button').removeEventListener('click',wooshLetterSound); 
    
    questionCash='';
    $(".place_bet_box ").show();
      $(".cover ").show();
  }else if(questionCash>=5 || questionCash<=main_score){
    document.querySelector('.bet_warning').classList.add('hide_boxes');
    document.querySelector('.bet_warning').classList.remove('show_boxes');
    document.querySelector('.betters_button').addEventListener('click',wooshLetterSound); 
    play();
    
    $(".vowelBox").show();
    document.querySelector('.returnBox').classList.remove('category_return_boost');
    
    gsap.from(".time_control", {duration: .5, xPercent:300, yPercent:-300, opacity: 0, scale: 1,delay:.4});
    gsap.to(".time_control", {duration: 3, x:0,opacity: 1, scale: 1});
    gsap.from(".disappear", {duration: 0, xPercent:0, opacity: 1, scale: 1});
    gsap.to(".disappear", {duration: 0, x:0, opacity: 1, scale: 1});

    
    
    slideTime();

   $(".categories_box").hide();
    $(".rules_back_button ").hide();
    $(".question_box ").show();
    $(".players_box ").show();
    $(".logo_holder ").show();
    $(".logo_holder_1 ").hide();
    $(".time_control ").show();
    $(".place_bet_box ").hide();
    $(".cover ").hide();


      
    timeLeft = 20;
    elem = document.querySelector('.time');
    
    isPaused=false;
  timerId = setInterval(countdown, 1000);
  function countdown() {
     if (timeLeft == -1 && !isPaused ) {
       
        clearTimeout(timerId);
        revealAnswerNoTimeLeft();
        releaseListeners();
      } else if(!isPaused ) {
        getListeners();
         elem.innerHTML = timeLeft + ' ';
         timeLeft--;
      
     if(elem.innerHTML>10){
         document.querySelector('.time_control').classList.add('time_control_white');
         document.querySelector('.time').classList.add('time_double');
         document.querySelector('.time').classList.remove('time_single');
        
         
        
       } if(elem.innerHTML<10){
         document.querySelector('.time').classList.add('time_single');
         document.querySelector('.time').classList.remove('time_double');
         document.querySelector('.time_control').classList.add('time_control_yellow');
         document.querySelector('.time_control').classList.remove('time_control_white');
         document.querySelector('.time_control').classList.remove('time_control_red');
         
        
         gsap.fromTo(".time_control", {opacity: 0}, {opacity: 1, duration: .5, repeat:0});
         
       } if(elem.innerHTML<=5  ){
         document.querySelector('.time_control').classList.add('time_control_red');
         document.querySelector('.time_control').classList.remove('time_control_yellow');
         document.querySelector('.time_control').classList.remove('time_control_white');
         
         gsap.fromTo(".time_control", {opacity: 0}, {opacity: 1, duration: .1, repeat:0});

       }if(elem.innerHTML===0){
         document.querySelector('.time_control').classList.remove('time_control_red');
         document.querySelector('.time_control').classList.add('time_control_white');
         
         
       } 
     }
   }

  

    
  
  }
  


   
  };


  
  


//add padding to certain letters to fit in letter boxes
function findI(){
  if(charac_1==='I'){
    document.querySelector('.write_box_3_3').childNodes[1].classList.add('letter_i');
    document.querySelector('.write_box_4_4').childNodes[1].classList.add('letter_i');
    document.querySelector('.write_box_5_5').childNodes[1].classList.add('letter_i');
    document.querySelector('.write_box_6_6').childNodes[1].classList.add('letter_i');
    document.querySelector('.write_box_7_7').childNodes[1].classList.add('letter_i');
    document.querySelector('.write_box_8_8').childNodes[1].classList.add('letter_i');
   }
    if(charac_2==='I'){
    document.querySelector('.write_box_3_3').childNodes[3].classList.add('letter_i');
    document.querySelector('.write_box_4_4').childNodes[3].classList.add('letter_i');
    document.querySelector('.write_box_5_5').childNodes[3].classList.add('letter_i');
    document.querySelector('.write_box_6_6').childNodes[3].classList.add('letter_i');
    document.querySelector('.write_box_7_7').childNodes[3].classList.add('letter_i');
    document.querySelector('.write_box_8_8').childNodes[3].classList.add('letter_i');
   } if(charac_3==='I'){
    document.querySelector('.write_box_3_3').childNodes[5].classList.add('letter_i');
    document.querySelector('.write_box_4_4').childNodes[5].classList.add('letter_i');
    document.querySelector('.write_box_5_5').childNodes[5].classList.add('letter_i');
    document.querySelector('.write_box_6_6').childNodes[5].classList.add('letter_i');
    document.querySelector('.write_box_7_7').childNodes[5].classList.add('letter_i');
    document.querySelector('.write_box_8_8').childNodes[5].classList.add('letter_i');
   } if(charac_4==='I'){
    
    document.querySelector('.write_box_4_4').childNodes[7].classList.add('letter_i');
    document.querySelector('.write_box_5_5').childNodes[7].classList.add('letter_i');
    document.querySelector('.write_box_6_6').childNodes[7].classList.add('letter_i');
    document.querySelector('.write_box_7_7').childNodes[7].classList.add('letter_i');
    document.querySelector('.write_box_8_8').childNodes[7].classList.add('letter_i');
   } if(charac_5==='I'){
    document.querySelector('.write_box_5_5').childNodes[9].classList.add('letter_i');
    document.querySelector('.write_box_6_6').childNodes[9].classList.add('letter_i');
    document.querySelector('.write_box_7_7').childNodes[9].classList.add('letter_i');
    document.querySelector('.write_box_8_8').childNodes[9].classList.add('letter_i');
   } if(charac_6==='I'){
    document.querySelector('.write_box_6_6').childNodes[11].classList.add('letter_i');
    document.querySelector('.write_box_7_7').childNodes[11].classList.add('letter_i');
    document.querySelector('.write_box_8_8').childNodes[11].classList.add('letter_i');
   } if(charac_7==='I'){
    document.querySelector('.write_box_7_7').childNodes[13].classList.add('letter_i');
    document.querySelector('.write_box_8_8').childNodes[13].classList.add('letter_i');
   } if(charac_8==='I'){
    document.querySelector('.write_box_8_8').childNodes[15].classList.add('letter_i');
   }
}

function removeI(){
  if(charac_1!='I'){
    document.querySelector('.write_box_3_3').childNodes[1].classList.remove('letter_i');
    document.querySelector('.write_box_4_4').childNodes[1].classList.remove('letter_i');
    document.querySelector('.write_box_5_5').childNodes[1].classList.remove('letter_i');
    document.querySelector('.write_box_6_6').childNodes[1].classList.remove('letter_i');
    document.querySelector('.write_box_7_7').childNodes[1].classList.remove('letter_i');
    document.querySelector('.write_box_8_8').childNodes[1].classList.remove('letter_i');

  } if(charac_2!='I'){
    document.querySelector('.write_box_3_3').childNodes[3].classList.remove('letter_i');
    document.querySelector('.write_box_4_4').childNodes[3].classList.remove('letter_i');
    document.querySelector('.write_box_5_5').childNodes[3].classList.remove('letter_i');
    document.querySelector('.write_box_6_6').childNodes[3].classList.remove('letter_i');
    document.querySelector('.write_box_7_7').childNodes[3].classList.remove('letter_i');
    document.querySelector('.write_box_8_8').childNodes[3].classList.remove('letter_i');
   } if(charac_3!='I'){
    document.querySelector('.write_box_3_3').childNodes[5].classList.remove('letter_i');
    document.querySelector('.write_box_4_4').childNodes[5].classList.remove('letter_i');
    document.querySelector('.write_box_5_5').childNodes[5].classList.remove('letter_i');
    document.querySelector('.write_box_6_6').childNodes[5].classList.remove('letter_i');
    document.querySelector('.write_box_7_7').childNodes[5].classList.remove('letter_i');
    document.querySelector('.write_box_8_8').childNodes[5].classList.remove('letter_i');
   } if(charac_4!='I'){
    document.querySelector('.write_box_4_4').childNodes[7].classList.remove('letter_i');
    document.querySelector('.write_box_5_5').childNodes[7].classList.remove('letter_i');
    document.querySelector('.write_box_6_6').childNodes[7].classList.remove('letter_i');
    document.querySelector('.write_box_7_7').childNodes[7].classList.remove('letter_i');
    document.querySelector('.write_box_8_8').childNodes[7].classList.remove('letter_i');
   } if(charac_5!='I'){
    document.querySelector('.write_box_5_5').childNodes[9].classList.remove('letter_i');
    document.querySelector('.write_box_6_6').childNodes[9].classList.remove('letter_i');
    document.querySelector('.write_box_7_7').childNodes[9].classList.remove('letter_i');
    document.querySelector('.write_box_8_8').childNodes[9].classList.remove('letter_i');
   } if(charac_6!='I'){
    document.querySelector('.write_box_6_6').childNodes[11].classList.remove('letter_i');
    document.querySelector('.write_box_7_7').childNodes[11].classList.remove('letter_i');
    document.querySelector('.write_box_8_8').childNodes[11].classList.remove('letter_i');
   } if(charac_7!='I'){
    document.querySelector('.write_box_7_7').childNodes[13].classList.remove('letter_i');
    document.querySelector('.write_box_8_8').childNodes[13].classList.remove('letter_i');
   }if(charac_8!='I'){
    document.querySelector('.write_box_8_8').childNodes[15].classList.remove('letter_i');
   }
}

function findM(){
  if(charac_1==='M'){
    document.querySelector('.write_box_3_3').childNodes[1].classList.add('letter_m');
    document.querySelector('.write_box_4_4').childNodes[1].classList.add('letter_m');
    document.querySelector('.write_box_5_5').childNodes[1].classList.add('letter_m');
    document.querySelector('.write_box_6_6').childNodes[1].classList.add('letter_m');
    document.querySelector('.write_box_7_7').childNodes[1].classList.add('letter_m');
    document.querySelector('.write_box_8_8').childNodes[1].classList.add('letter_m');
   }
    if(charac_2==='M'){
    document.querySelector('.write_box_3_3').childNodes[3].classList.add('letter_m');
    document.querySelector('.write_box_4_4').childNodes[3].classList.add('letter_m');
    document.querySelector('.write_box_5_5').childNodes[3].classList.add('letter_m');
    document.querySelector('.write_box_6_6').childNodes[3].classList.add('letter_m');
    document.querySelector('.write_box_7_7').childNodes[3].classList.add('letter_m');
    document.querySelector('.write_box_8_8').childNodes[3].classList.add('letter_m');
   } if(charac_3==='M'){
    document.querySelector('.write_box_3_3').childNodes[5].classList.add('letter_m');
    document.querySelector('.write_box_4_4').childNodes[5].classList.add('letter_m');
    document.querySelector('.write_box_5_5').childNodes[5].classList.add('letter_m');
    document.querySelector('.write_box_6_6').childNodes[5].classList.add('letter_m');
    document.querySelector('.write_box_7_7').childNodes[5].classList.add('letter_m');
    document.querySelector('.write_box_8_8').childNodes[5].classList.add('letter_m');
   } if(charac_4==='M'){
    
    document.querySelector('.write_box_4_4').childNodes[7].classList.add('letter_m');
    document.querySelector('.write_box_5_5').childNodes[7].classList.add('letter_m');
    document.querySelector('.write_box_6_6').childNodes[7].classList.add('letter_m');
    document.querySelector('.write_box_7_7').childNodes[7].classList.add('letter_m');
    document.querySelector('.write_box_8_8').childNodes[7].classList.add('letter_m');
   } if(charac_5==='M'){
    document.querySelector('.write_box_5_5').childNodes[9].classList.add('letter_m');
    document.querySelector('.write_box_6_6').childNodes[9].classList.add('letter_m');
    document.querySelector('.write_box_7_7').childNodes[9].classList.add('letter_m');
    document.querySelector('.write_box_8_8').childNodes[9].classList.add('letter_m');
   } if(charac_6==='M'){
    document.querySelector('.write_box_6_6').childNodes[11].classList.add('letter_m');
    document.querySelector('.write_box_7_7').childNodes[11].classList.add('letter_m');
    document.querySelector('.write_box_8_8').childNodes[11].classList.add('letter_m');
   } if(charac_7==='M'){
    document.querySelector('.write_box_7_7').childNodes[13].classList.add('letter_m');
    document.querySelector('.write_box_8_8').childNodes[13].classList.add('letter_m');
   } if(charac_8==='M'){
    document.querySelector('.write_box_8_8').childNodes[15].classList.add('letter_m');
   }
}

function removeM(){
  if(charac_1!='M'){
    document.querySelector('.write_box_3_3').childNodes[1].classList.remove('letter_m');
    document.querySelector('.write_box_4_4').childNodes[1].classList.remove('letter_m');
    document.querySelector('.write_box_5_5').childNodes[1].classList.remove('letter_m');
    document.querySelector('.write_box_6_6').childNodes[1].classList.remove('letter_m');
    document.querySelector('.write_box_7_7').childNodes[1].classList.remove('letter_m');
    document.querySelector('.write_box_8_8').childNodes[1].classList.remove('letter_m');

  } if(charac_2!='M'){
    document.querySelector('.write_box_3_3').childNodes[3].classList.remove('letter_m');
    document.querySelector('.write_box_4_4').childNodes[3].classList.remove('letter_m');
    document.querySelector('.write_box_5_5').childNodes[3].classList.remove('letter_m');
    document.querySelector('.write_box_6_6').childNodes[3].classList.remove('letter_m');
    document.querySelector('.write_box_7_7').childNodes[3].classList.remove('letter_m');
    document.querySelector('.write_box_8_8').childNodes[3].classList.remove('letter_m');
   } if(charac_3!='M'){
    document.querySelector('.write_box_3_3').childNodes[5].classList.remove('letter_m');
    document.querySelector('.write_box_4_4').childNodes[5].classList.remove('letter_m');
    document.querySelector('.write_box_5_5').childNodes[5].classList.remove('letter_m');
    document.querySelector('.write_box_6_6').childNodes[5].classList.remove('letter_m');
    document.querySelector('.write_box_7_7').childNodes[5].classList.remove('letter_m');
    document.querySelector('.write_box_8_8').childNodes[5].classList.remove('letter_m');
   } if(charac_4!='M'){
    document.querySelector('.write_box_4_4').childNodes[7].classList.remove('letter_m');
    document.querySelector('.write_box_5_5').childNodes[7].classList.remove('letter_m');
    document.querySelector('.write_box_6_6').childNodes[7].classList.remove('letter_m');
    document.querySelector('.write_box_7_7').childNodes[7].classList.remove('letter_m');
    document.querySelector('.write_box_8_8').childNodes[7].classList.remove('letter_m');
   } if(charac_5!='M'){
    document.querySelector('.write_box_5_5').childNodes[9].classList.remove('letter_m');
    document.querySelector('.write_box_6_6').childNodes[9].classList.remove('letter_m');
    document.querySelector('.write_box_7_7').childNodes[9].classList.remove('letter_m');
    document.querySelector('.write_box_8_8').childNodes[9].classList.remove('letter_m');
   } if(charac_6!='M'){
    document.querySelector('.write_box_6_6').childNodes[11].classList.remove('letter_m');
    document.querySelector('.write_box_7_7').childNodes[11].classList.remove('letter_m');
    document.querySelector('.write_box_8_8').childNodes[11].classList.remove('letter_m');
   } if(charac_7!='M'){
    document.querySelector('.write_box_7_7').childNodes[13].classList.remove('letter_m');
    document.querySelector('.write_box_8_8').childNodes[13].classList.remove('letter_m');
   }if(charac_8!='M'){
    document.querySelector('.write_box_8_8').childNodes[15].classList.remove('letter_m');
   }
}

function findJ(){
  if(charac_1==='J'){
    document.querySelector('.write_box_3_3').childNodes[1].classList.add('letter_j');
    document.querySelector('.write_box_4_4').childNodes[1].classList.add('letter_j');
    document.querySelector('.write_box_5_5').childNodes[1].classList.add('letter_j');
    document.querySelector('.write_box_6_6').childNodes[1].classList.add('letter_j');
    document.querySelector('.write_box_7_7').childNodes[1].classList.add('letter_j');
    document.querySelector('.write_box_8_8').childNodes[1].classList.add('letter_j');
   }
    if(charac_2==='J'){
    document.querySelector('.write_box_3_3').childNodes[3].classList.add('letter_j');
    document.querySelector('.write_box_4_4').childNodes[3].classList.add('letter_j');
    document.querySelector('.write_box_5_5').childNodes[3].classList.add('letter_j');
    document.querySelector('.write_box_6_6').childNodes[3].classList.add('letter_j');
    document.querySelector('.write_box_7_7').childNodes[3].classList.add('letter_j');
    document.querySelector('.write_box_8_8').childNodes[3].classList.add('letter_j');
   } if(charac_3==='J'){
    document.querySelector('.write_box_3_3').childNodes[5].classList.add('letter_j');
    document.querySelector('.write_box_4_4').childNodes[5].classList.add('letter_j');
    document.querySelector('.write_box_5_5').childNodes[5].classList.add('letter_j');
    document.querySelector('.write_box_6_6').childNodes[5].classList.add('letter_j');
    document.querySelector('.write_box_7_7').childNodes[5].classList.add('letter_j');
    document.querySelector('.write_box_8_8').childNodes[5].classList.add('letter_j');
   } if(charac_4==='J'){
    
    document.querySelector('.write_box_4_4').childNodes[7].classList.add('letter_j');
    document.querySelector('.write_box_5_5').childNodes[7].classList.add('letter_j');
    document.querySelector('.write_box_6_6').childNodes[7].classList.add('letter_j');
    document.querySelector('.write_box_7_7').childNodes[7].classList.add('letter_j');
    document.querySelector('.write_box_8_8').childNodes[7].classList.add('letter_j');
   } if(charac_5==='J'){
    document.querySelector('.write_box_5_5').childNodes[9].classList.add('letter_j');
    document.querySelector('.write_box_6_6').childNodes[9].classList.add('letter_j');
    document.querySelector('.write_box_7_7').childNodes[9].classList.add('letter_j');
    document.querySelector('.write_box_8_8').childNodes[9].classList.add('letter_j');
   } if(charac_6==='J'){
    document.querySelector('.write_box_6_6').childNodes[11].classList.add('letter_j');
    document.querySelector('.write_box_7_7').childNodes[11].classList.add('letter_j');
    document.querySelector('.write_box_8_8').childNodes[11].classList.add('letter_j');
   } if(charac_7==='J'){
    document.querySelector('.write_box_7_7').childNodes[13].classList.add('letter_j');
    document.querySelector('.write_box_8_8').childNodes[13].classList.add('letter_j');
   } if(charac_8==='J'){
    document.querySelector('.write_box_8_8').childNodes[15].classList.add('letter_j');
   }
}

function removeJ(){
  if(charac_1!='J'){
    document.querySelector('.write_box_3_3').childNodes[1].classList.remove('letter_j');
    document.querySelector('.write_box_4_4').childNodes[1].classList.remove('letter_j');
    document.querySelector('.write_box_5_5').childNodes[1].classList.remove('letter_j');
    document.querySelector('.write_box_6_6').childNodes[1].classList.remove('letter_j');
    document.querySelector('.write_box_7_7').childNodes[1].classList.remove('letter_j');
    document.querySelector('.write_box_8_8').childNodes[1].classList.remove('letter_j');

  } if(charac_2!='J'){
    document.querySelector('.write_box_3_3').childNodes[3].classList.remove('letter_j');
    document.querySelector('.write_box_4_4').childNodes[3].classList.remove('letter_j');
    document.querySelector('.write_box_5_5').childNodes[3].classList.remove('letter_j');
    document.querySelector('.write_box_6_6').childNodes[3].classList.remove('letter_j');
    document.querySelector('.write_box_7_7').childNodes[3].classList.remove('letter_j');
    document.querySelector('.write_box_8_8').childNodes[3].classList.remove('letter_j');
   } if(charac_3!='J'){
    document.querySelector('.write_box_3_3').childNodes[5].classList.remove('letter_j');
    document.querySelector('.write_box_4_4').childNodes[5].classList.remove('letter_j');
    document.querySelector('.write_box_5_5').childNodes[5].classList.remove('letter_j');
    document.querySelector('.write_box_6_6').childNodes[5].classList.remove('letter_j');
    document.querySelector('.write_box_7_7').childNodes[5].classList.remove('letter_j');
    document.querySelector('.write_box_8_8').childNodes[5].classList.remove('letter_j');
   } if(charac_4!='J'){
    document.querySelector('.write_box_4_4').childNodes[7].classList.remove('letter_j');
    document.querySelector('.write_box_5_5').childNodes[7].classList.remove('letter_j');
    document.querySelector('.write_box_6_6').childNodes[7].classList.remove('letter_j');
    document.querySelector('.write_box_7_7').childNodes[7].classList.remove('letter_j');
    document.querySelector('.write_box_8_8').childNodes[7].classList.remove('letter_j');
   } if(charac_5!='J'){
    document.querySelector('.write_box_5_5').childNodes[9].classList.remove('letter_j');
    document.querySelector('.write_box_6_6').childNodes[9].classList.remove('letter_j');
    document.querySelector('.write_box_7_7').childNodes[9].classList.remove('letter_j');
    document.querySelector('.write_box_8_8').childNodes[9].classList.remove('letter_j');
   } if(charac_6!='J'){
    document.querySelector('.write_box_6_6').childNodes[11].classList.remove('letter_j');
    document.querySelector('.write_box_7_7').childNodes[11].classList.remove('letter_j');
    document.querySelector('.write_box_8_8').childNodes[11].classList.remove('letter_j');
   } if(charac_7!='J'){
    document.querySelector('.write_box_7_7').childNodes[13].classList.remove('letter_j');
    document.querySelector('.write_box_8_8').childNodes[13].classList.remove('letter_j');
   }if(charac_8!='J'){
    document.querySelector('.write_box_8_8').childNodes[15].classList.remove('letter_j');
   }
}

function findW(){
  if(charac_1==='W'){
    document.querySelector('.write_box_3_3').childNodes[1].classList.add('letter_w');
    document.querySelector('.write_box_4_4').childNodes[1].classList.add('letter_w');
    document.querySelector('.write_box_5_5').childNodes[1].classList.add('letter_w');
    document.querySelector('.write_box_6_6').childNodes[1].classList.add('letter_w');
    document.querySelector('.write_box_7_7').childNodes[1].classList.add('letter_w');
    document.querySelector('.write_box_8_8').childNodes[1].classList.add('letter_w');
   }
    if(charac_2==='W'){
    document.querySelector('.write_box_3_3').childNodes[3].classList.add('letter_w');
    document.querySelector('.write_box_4_4').childNodes[3].classList.add('letter_w');
    document.querySelector('.write_box_5_5').childNodes[3].classList.add('letter_w');
    document.querySelector('.write_box_6_6').childNodes[3].classList.add('letter_w');
    document.querySelector('.write_box_7_7').childNodes[3].classList.add('letter_w');
    document.querySelector('.write_box_8_8').childNodes[3].classList.add('letter_w');
   } if(charac_3==='W'){
    document.querySelector('.write_box_3_3').childNodes[5].classList.add('letter_w');
    document.querySelector('.write_box_4_4').childNodes[5].classList.add('letter_w');
    document.querySelector('.write_box_5_5').childNodes[5].classList.add('letter_w');
    document.querySelector('.write_box_6_6').childNodes[5].classList.add('letter_w');
    document.querySelector('.write_box_7_7').childNodes[5].classList.add('letter_w');
    document.querySelector('.write_box_8_8').childNodes[5].classList.add('letter_w');
   } if(charac_4==='W'){
    
    document.querySelector('.write_box_4_4').childNodes[7].classList.add('letter_w');
    document.querySelector('.write_box_5_5').childNodes[7].classList.add('letter_w');
    document.querySelector('.write_box_6_6').childNodes[7].classList.add('letter_w');
    document.querySelector('.write_box_7_7').childNodes[7].classList.add('letter_w');
    document.querySelector('.write_box_8_8').childNodes[7].classList.add('letter_w');
   } if(charac_5==='W'){
    document.querySelector('.write_box_5_5').childNodes[9].classList.add('letter_w');
    document.querySelector('.write_box_6_6').childNodes[9].classList.add('letter_w');
    document.querySelector('.write_box_7_7').childNodes[9].classList.add('letter_w');
    document.querySelector('.write_box_8_8').childNodes[9].classList.add('letter_w');
   } if(charac_6==='W'){
    document.querySelector('.write_box_6_6').childNodes[11].classList.add('letter_w');
    document.querySelector('.write_box_7_7').childNodes[11].classList.add('letter_w');
    document.querySelector('.write_box_8_8').childNodes[11].classList.add('letter_w');
   } if(charac_7==='W'){
    document.querySelector('.write_box_7_7').childNodes[13].classList.add('letter_w');
    document.querySelector('.write_box_8_8').childNodes[13].classList.add('letter_w');
   } if(charac_8==='W'){
    document.querySelector('.write_box_8_8').childNodes[15].classList.add('letter_w');
   }
}

function removeW(){
  if(charac_1!='W'){
    document.querySelector('.write_box_3_3').childNodes[1].classList.remove('letter_w');
    document.querySelector('.write_box_4_4').childNodes[1].classList.remove('letter_w');
    document.querySelector('.write_box_5_5').childNodes[1].classList.remove('letter_w');
    document.querySelector('.write_box_6_6').childNodes[1].classList.remove('letter_w');
    document.querySelector('.write_box_7_7').childNodes[1].classList.remove('letter_w');
    document.querySelector('.write_box_8_8').childNodes[1].classList.remove('letter_w');

  } if(charac_2!='W'){
    document.querySelector('.write_box_3_3').childNodes[3].classList.remove('letter_w');
    document.querySelector('.write_box_4_4').childNodes[3].classList.remove('letter_w');
    document.querySelector('.write_box_5_5').childNodes[3].classList.remove('letter_w');
    document.querySelector('.write_box_6_6').childNodes[3].classList.remove('letter_w');
    document.querySelector('.write_box_7_7').childNodes[3].classList.remove('letter_w');
    document.querySelector('.write_box_8_8').childNodes[3].classList.remove('letter_w');
   } if(charac_3!='W'){
    document.querySelector('.write_box_3_3').childNodes[5].classList.remove('letter_w');
    document.querySelector('.write_box_4_4').childNodes[5].classList.remove('letter_w');
    document.querySelector('.write_box_5_5').childNodes[5].classList.remove('letter_w');
    document.querySelector('.write_box_6_6').childNodes[5].classList.remove('letter_w');
    document.querySelector('.write_box_7_7').childNodes[5].classList.remove('letter_w');
    document.querySelector('.write_box_8_8').childNodes[5].classList.remove('letter_w');
   } if(charac_4!='W'){
    document.querySelector('.write_box_4_4').childNodes[7].classList.remove('letter_w');
    document.querySelector('.write_box_5_5').childNodes[7].classList.remove('letter_w');
    document.querySelector('.write_box_6_6').childNodes[7].classList.remove('letter_w');
    document.querySelector('.write_box_7_7').childNodes[7].classList.remove('letter_w');
    document.querySelector('.write_box_8_8').childNodes[7].classList.remove('letter_w');
   } if(charac_5!='W'){
    document.querySelector('.write_box_5_5').childNodes[9].classList.remove('letter_w');
    document.querySelector('.write_box_6_6').childNodes[9].classList.remove('letter_w');
    document.querySelector('.write_box_7_7').childNodes[9].classList.remove('letter_w');
    document.querySelector('.write_box_8_8').childNodes[9].classList.remove('letter_w');
   } if(charac_6!='W'){
    document.querySelector('.write_box_6_6').childNodes[11].classList.remove('letter_w');
    document.querySelector('.write_box_7_7').childNodes[11].classList.remove('letter_w');
    document.querySelector('.write_box_8_8').childNodes[11].classList.remove('letter_w');
   } if(charac_7!='W'){
    document.querySelector('.write_box_7_7').childNodes[13].classList.remove('letter_w');
    document.querySelector('.write_box_8_8').childNodes[13].classList.remove('letter_w');
   }if(charac_8!='W'){
    document.querySelector('.write_box_8_8').childNodes[15].classList.remove('letter_w');
   }
}






   
   
  
function clearOutAllLetters(){
  document.querySelector('.write_box_3_3').childNodes[1].innerHTML='';
  document.querySelector('.write_box_3_3').childNodes[3].innerHTML='';
  document.querySelector('.write_box_3_3').childNodes[5].innerHTML='';
  document.querySelector('.write_box_4_4').childNodes[1].innerHTML='';
  document.querySelector('.write_box_4_4').childNodes[3].innerHTML='';
  document.querySelector('.write_box_4_4').childNodes[5].innerHTML='';
  document.querySelector('.write_box_4_4').childNodes[7].innerHTML='';
  document.querySelector('.write_box_5_5').childNodes[1].innerHTML='';
  document.querySelector('.write_box_5_5').childNodes[3].innerHTML='';
  document.querySelector('.write_box_5_5').childNodes[5].innerHTML='';
  document.querySelector('.write_box_5_5').childNodes[7].innerHTML='';
  document.querySelector('.write_box_5_5').childNodes[9].innerHTML='';
  document.querySelector('.write_box_6_6').childNodes[1].innerHTML='';
  document.querySelector('.write_box_6_6').childNodes[3].innerHTML='';
  document.querySelector('.write_box_6_6').childNodes[5].innerHTML='';
  document.querySelector('.write_box_6_6').childNodes[7].innerHTML='';
  document.querySelector('.write_box_6_6').childNodes[9].innerHTML='';
  document.querySelector('.write_box_6_6').childNodes[11].innerHTML='';
  document.querySelector('.write_box_7_7').childNodes[1].innerHTML='';
  document.querySelector('.write_box_7_7').childNodes[3].innerHTML='';
  document.querySelector('.write_box_7_7').childNodes[5].innerHTML='';
  document.querySelector('.write_box_7_7').childNodes[7].innerHTML='';
  document.querySelector('.write_box_7_7').childNodes[9].innerHTML='';
  document.querySelector('.write_box_7_7').childNodes[11].innerHTML='';
  document.querySelector('.write_box_7_7').childNodes[13].innerHTML='';
  document.querySelector('.write_box_8_8').childNodes[1].innerHTML='';
  document.querySelector('.write_box_8_8').childNodes[3].innerHTML='';
  document.querySelector('.write_box_8_8').childNodes[5].innerHTML='';
  document.querySelector('.write_box_8_8').childNodes[7].innerHTML='';
  document.querySelector('.write_box_8_8').childNodes[9].innerHTML='';
  document.querySelector('.write_box_8_8').childNodes[11].innerHTML='';
  document.querySelector('.write_box_8_8').childNodes[13].innerHTML='';
  document.querySelector('.write_box_8_8').childNodes[15].innerHTML='';
  document.querySelector('.points').innerHTML='';
  
  document.querySelector('.points').classList.remove('cash_red');
  document.querySelector('.points').classList.remove('cash_green');
  document.querySelector('.box_4_1').classList.remove('border_green');
  document.querySelector('.box_4_2').classList.remove('border_green');
  document.querySelector('.box_4_3').classList.remove('border_green');
  document.querySelector('.box_4_4').classList.remove('border_green');
  document.querySelector('.box_5_1').classList.remove('border_green');
  document.querySelector('.box_5_2').classList.remove('border_green');
  document.querySelector('.box_5_3').classList.remove('border_green');
  document.querySelector('.box_5_4').classList.remove('border_green');
  document.querySelector('.box_5_5').classList.remove('border_green');
  document.querySelector('.box_6_1').classList.remove('border_green');
  document.querySelector('.box_6_2').classList.remove('border_green');
  document.querySelector('.box_6_3').classList.remove('border_green');
  document.querySelector('.box_6_4').classList.remove('border_green');
  document.querySelector('.box_6_5').classList.remove('border_green');
  document.querySelector('.box_6_6').classList.remove('border_green');
  document.querySelector('.box_7_1').classList.remove('border_green');
  document.querySelector('.box_7_2').classList.remove('border_green');
  document.querySelector('.box_7_3').classList.remove('border_green');
  document.querySelector('.box_7_4').classList.remove('border_green');
  document.querySelector('.box_7_5').classList.remove('border_green');
  document.querySelector('.box_7_6').classList.remove('border_green');
  document.querySelector('.box_7_7').classList.remove('border_green');
  document.querySelector('.box_8_1').classList.remove('border_green');
  document.querySelector('.box_8_2').classList.remove('border_green');
  document.querySelector('.box_8_3').classList.remove('border_green');
  document.querySelector('.box_8_4').classList.remove('border_green');
  document.querySelector('.box_8_5').classList.remove('border_green');
  document.querySelector('.box_8_6').classList.remove('border_green');
  document.querySelector('.box_8_7').classList.remove('border_green');
  document.querySelector('.box_8_8').classList.remove('border_green');
  
  document.querySelector('.box_4_1').classList.remove('border_red');
  document.querySelector('.box_4_2').classList.remove('border_red');
  document.querySelector('.box_4_3').classList.remove('border_red');
  document.querySelector('.box_4_4').classList.remove('border_red');
  document.querySelector('.box_5_1').classList.remove('border_red');
  document.querySelector('.box_5_2').classList.remove('border_red');
  document.querySelector('.box_5_3').classList.remove('border_red');
  document.querySelector('.box_5_4').classList.remove('border_red');
  document.querySelector('.box_5_5').classList.remove('border_red');
  document.querySelector('.box_6_1').classList.remove('border_red');
  document.querySelector('.box_6_2').classList.remove('border_red');
  document.querySelector('.box_6_3').classList.remove('border_red');
  document.querySelector('.box_6_4').classList.remove('border_red');
  document.querySelector('.box_6_5').classList.remove('border_red');
  document.querySelector('.box_6_6').classList.remove('border_red');
  document.querySelector('.box_7_1').classList.remove('border_red');
  document.querySelector('.box_7_2').classList.remove('border_red');
  document.querySelector('.box_7_3').classList.remove('border_red');
  document.querySelector('.box_7_4').classList.remove('border_red');
  document.querySelector('.box_7_5').classList.remove('border_red');
  document.querySelector('.box_7_6').classList.remove('border_red');
  document.querySelector('.box_7_7').classList.remove('border_red');
  document.querySelector('.box_8_1').classList.remove('border_red');
  document.querySelector('.box_8_2').classList.remove('border_red');
  document.querySelector('.box_8_3').classList.remove('border_red');
  document.querySelector('.box_8_4').classList.remove('border_red');
  document.querySelector('.box_8_5').classList.remove('border_red');
  document.querySelector('.box_8_6').classList.remove('border_red');
  document.querySelector('.box_8_7').classList.remove('border_red');
  document.querySelector('.box_8_8').classList.remove('border_red');
  document.querySelector('.box_4_1').classList.remove('letter_m');
  document.querySelector('.box_4_1').classList.remove('letter_i');
  document.querySelector('.box_4_1').classList.remove('letter_j');
  document.querySelector('.box_4_1').classList.remove('letter_w');
  document.querySelector('.box_4_2').classList.remove('letter_m');
  document.querySelector('.box_4_2').classList.remove('letter_i');
  document.querySelector('.box_4_2').classList.remove('letter_j');
  document.querySelector('.box_4_2').classList.remove('letter_w');
  document.querySelector('.box_4_3').classList.remove('letter_m');
  document.querySelector('.box_4_3').classList.remove('letter_i');
  document.querySelector('.box_4_3').classList.remove('letter_j');
  document.querySelector('.box_4_3').classList.remove('letter_w');
  document.querySelector('.box_4_4').classList.remove('letter_m');
  document.querySelector('.box_4_4').classList.remove('letter_i');
  document.querySelector('.box_4_4').classList.remove('letter_j');
  document.querySelector('.box_4_4').classList.remove('letter_w');
  document.querySelector('.box_5_1').classList.remove('letter_m');
  document.querySelector('.box_5_1').classList.remove('letter_i');
  document.querySelector('.box_5_1').classList.remove('letter_j');
  document.querySelector('.box_5_1').classList.remove('letter_w');
  document.querySelector('.box_5_2').classList.remove('letter_m');
  document.querySelector('.box_5_2').classList.remove('letter_i');
  document.querySelector('.box_5_2').classList.remove('letter_j');
  document.querySelector('.box_5_2').classList.remove('letter_w');
  document.querySelector('.box_5_3').classList.remove('letter_m');
  document.querySelector('.box_5_3').classList.remove('letter_i');
  document.querySelector('.box_5_3').classList.remove('letter_j');
  document.querySelector('.box_5_3').classList.remove('letter_w');
  document.querySelector('.box_5_4').classList.remove('letter_m');
  document.querySelector('.box_5_4').classList.remove('letter_i');
  document.querySelector('.box_5_4').classList.remove('letter_j');
  document.querySelector('.box_5_4').classList.remove('letter_w');
  document.querySelector('.box_5_5').classList.remove('letter_m');
  document.querySelector('.box_5_5').classList.remove('letter_i');
  document.querySelector('.box_5_5').classList.remove('letter_j');
  document.querySelector('.box_5_5').classList.remove('letter_w');
  document.querySelector('.box_6_1').classList.remove('letter_m');
  document.querySelector('.box_6_1').classList.remove('letter_i');
  document.querySelector('.box_6_1').classList.remove('letter_j');
  document.querySelector('.box_6_1').classList.remove('letter_w');
  document.querySelector('.box_6_2').classList.remove('letter_m');
  document.querySelector('.box_6_2').classList.remove('letter_i');
  document.querySelector('.box_6_2').classList.remove('letter_j');
  document.querySelector('.box_6_2').classList.remove('letter_w');
  document.querySelector('.box_6_3').classList.remove('letter_m');
  document.querySelector('.box_6_3').classList.remove('letter_i');
  document.querySelector('.box_6_3').classList.remove('letter_j');
  document.querySelector('.box_6_3').classList.remove('letter_w');
  document.querySelector('.box_6_4').classList.remove('letter_m');
  document.querySelector('.box_6_4').classList.remove('letter_i');
  document.querySelector('.box_6_4').classList.remove('letter_j');
  document.querySelector('.box_6_4').classList.remove('letter_w');
  document.querySelector('.box_6_5').classList.remove('letter_m');
  document.querySelector('.box_6_5').classList.remove('letter_i');
  document.querySelector('.box_6_5').classList.remove('letter_j');
  document.querySelector('.box_6_5').classList.remove('letter_w');
  document.querySelector('.box_6_6').classList.remove('letter_m');
  document.querySelector('.box_6_6').classList.remove('letter_i');
  document.querySelector('.box_6_6').classList.remove('letter_j');
  document.querySelector('.box_6_6').classList.remove('letter_w');
  document.querySelector('.box_7_1').classList.remove('letter_m');
  document.querySelector('.box_7_1').classList.remove('letter_i');
  document.querySelector('.box_7_1').classList.remove('letter_j');
  document.querySelector('.box_7_1').classList.remove('letter_w');
  document.querySelector('.box_7_2').classList.remove('letter_m');
  document.querySelector('.box_7_2').classList.remove('letter_i');
  document.querySelector('.box_7_2').classList.remove('letter_j');
  document.querySelector('.box_7_2').classList.remove('letter_w');
  document.querySelector('.box_7_3').classList.remove('letter_m');
  document.querySelector('.box_7_3').classList.remove('letter_i');
  document.querySelector('.box_7_3').classList.remove('letter_j');
  document.querySelector('.box_7_3').classList.remove('letter_w');
  document.querySelector('.box_7_4').classList.remove('letter_m');
  document.querySelector('.box_7_4').classList.remove('letter_i');
  document.querySelector('.box_7_4').classList.remove('letter_j');
  document.querySelector('.box_7_4').classList.remove('letter_w');
  document.querySelector('.box_7_5').classList.remove('letter_m');
  document.querySelector('.box_7_5').classList.remove('letter_i');
  document.querySelector('.box_7_5').classList.remove('letter_j');
  document.querySelector('.box_7_5').classList.remove('letter_w');
  document.querySelector('.box_7_6').classList.remove('letter_m');
  document.querySelector('.box_7_6').classList.remove('letter_i');
  document.querySelector('.box_7_6').classList.remove('letter_j');
  document.querySelector('.box_7_6').classList.remove('letter_w');
  document.querySelector('.box_7_7').classList.remove('letter_m');
  document.querySelector('.box_7_7').classList.remove('letter_i');
  document.querySelector('.box_7_7').classList.remove('letter_j');
  document.querySelector('.box_7_7').classList.remove('letter_w');
  document.querySelector('.box_8_1').classList.remove('letter_m');
  document.querySelector('.box_8_1').classList.remove('letter_i');
  document.querySelector('.box_8_1').classList.remove('letter_j');
  document.querySelector('.box_8_1').classList.remove('letter_w');
  document.querySelector('.box_8_2').classList.remove('letter_m');
  document.querySelector('.box_8_2').classList.remove('letter_i');
  document.querySelector('.box_8_2').classList.remove('letter_j');
  document.querySelector('.box_8_2').classList.remove('letter_w');
  document.querySelector('.box_8_3').classList.remove('letter_m');
  document.querySelector('.box_8_3').classList.remove('letter_i');
  document.querySelector('.box_8_3').classList.remove('letter_j');
  document.querySelector('.box_8_3').classList.remove('letter_w');
  document.querySelector('.box_8_4').classList.remove('letter_m');
  document.querySelector('.box_8_4').classList.remove('letter_i');
  document.querySelector('.box_8_4').classList.remove('letter_j');
  document.querySelector('.box_8_4').classList.remove('letter_w');
  document.querySelector('.box_8_5').classList.remove('letter_m');
  document.querySelector('.box_8_5').classList.remove('letter_i');
  document.querySelector('.box_8_5').classList.remove('letter_j');
  document.querySelector('.box_8_5').classList.remove('letter_w');
  document.querySelector('.box_8_6').classList.remove('letter_m');
  document.querySelector('.box_8_6').classList.remove('letter_i');
  document.querySelector('.box_8_6').classList.remove('letter_j');
  document.querySelector('.box_8_6').classList.remove('letter_w');
  document.querySelector('.box_8_7').classList.remove('letter_m');
  document.querySelector('.box_8_7').classList.remove('letter_i');
  document.querySelector('.box_8_7').classList.remove('letter_j');
  document.querySelector('.box_8_7').classList.remove('letter_w');
  document.querySelector('.box_8_8').classList.remove('letter_m');
  document.querySelector('.box_8_8').classList.remove('letter_i');
  document.querySelector('.box_8_8').classList.remove('letter_j');
  document.querySelector('.box_8_8').classList.remove('letter_w');
  document.querySelector('.type_answer').value='';
  
  
  
}


//sound file functions

function correctLetterTone_1(){
  first_correct_Tone.play();
}

function correctLetterTone_2(){
second_correct_Tone.play();
}

function correctLetterTone_3(){
  third_correct_Tone.play();
}

function correctLetterTone_4(){
  fourth_correct_Tone.play();
}

function correctLetterTone_5(){
  fifth_correct_Tone.play();
}

function correctLetterTone_6(){
  sixth_correct_Tone.play();
}

function correctLetterTone_7(){
  seventh_correct_Tone.play();
}

function correctLetterTone_8(){
 eigth_correct_Tone.play();
}

function wrongLetterTone_1(){
  first_wrong_Tone.play();
}

function wrongLetterTone_2(){
  second_wrong_Tone.play();
}

function wrongLetterTone_3(){
  third_wrong_Tone.play();
}

function wrongLetterTone_4(){
  fourth_wrong_Tone.play();
}

function wrongLetterTone_5(){
  fifth_wrong_Tone.play();
}

function wrongLetterTone_6(){
  sixth_wrong_Tone.play();
}

function wrongLetterTone_7(){
  seventh_wrong_Tone.play();
}

function wrongLetterTone_8(){
  eigth_wrong_Tone.play();
}

function playMoneyTone(){
  money_Tone.play();
}

function loseMoneyTone(){
  no_cash_Tone.play();
}

function audiencePlusTone(){
  audience_plus_Tone.play();
}

function audienceMinusTone(){
  audience_wrong_Tone.play();
}

function clock(){
  clock_tone.play();
  currentTime=0;
}

function clock_pause(){
  clock_tone.pause();
  currentTime=0;

}

function clock_pause_vowel(){
  clock_tone.pause();
  currentTime=0;
}

function clock_play_vowel(){
  clock_tone.play();
}

function slideTime(){
  slide_time.play();
}

function vowelCountdown(){
  vowel_countdown.play();
  currentTime=0;
}

function vowelCountDownPause(){
  vowel_countdown.pause();
  
  

}




function play() {
  var audio = document.getElementById('clock_tone');
  if (audio) {
      audio.play();
      audio.currentTime = 0;
  }
}

function play1() {
  var audio1 = document.getElementById('vowel_countdown');
  if (audio1) {
      audio1.play();
      audio1.currentTime = 0;
  }
}

/*
function play() {
    var audio = document.getElementById('audio1');
    if (audio.paused) {
        audio.play();
    }else{
        audio.currentTime = 0
    }
}
*/
