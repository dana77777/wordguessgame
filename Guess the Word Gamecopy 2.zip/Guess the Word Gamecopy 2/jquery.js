
//JQUERY FUNCTIONS

/// 'categories button' to go back to categories page

$(document).ready(function(){
  $(" .category_return_no_more").click(function(){
    $(".question_box").hide();
    $(".time_control").hide();
    $(".players_box").hide();
    $(".categories_box").show();
    $(".logo_holder ").show();
    $(".no_more_questions ").hide();
    $(".logo").show();
    $(".logo_holder_2 ").hide();
    $(".rules_back_button ").show();
    
    
  });
});
 

  

  /// go back from categories page to rules page
 
  $(document).ready(function(){
    $(".rules_back_button ").click(function(){
      $(".categories_box").hide();
      $(".rules_back_button ").hide();
      $(".middle_paragraph").show();
      $(".start_button").show();
      $(".logo_holder_2 ").hide();
      $(".logo").show();

    });
  });
  $(document).ready(function(){
    $(".category_return ").click(function(){
      
      $(".logo").show();

    });
  });

  $(document).ready(function(){
    $(".check_cash").click(function(){
      
      $(".hide_box").toggle();

    });
  });


  /// go back from rules page to categories page

  $(document).ready(function(){
    $(".start_button ").click(function(){
      $(".categories_box").show();
      $(".logo_holder_2 ").hide();
      $(".rules_back_button ").show();
      $(".middle_paragraph").hide();
      $(".start_button").hide();

    });
  });



  /// get vowel box popup
  $(document).ready(function(){
    $(".close ").click(function(){
      $(".buy_vowel").hide();
      
      

    });
  });

  $(document).ready(function(){
    $(".vowel_button ").click(function(){
      $(".buy_vowel").hide();
      
      

    });
  });


  $(document).ready(function(){
    $(".vowelBox ").click(function(){
      $(".buy_vowel").show();
      $(".check_a").prop("checked",false);
      $(".check_i").prop("checked",false);
      $(".check_e").prop("checked",false);
      $(".check_o").prop("checked",false);
      $(".check_u").prop("checked",false);
      
      
    });
  });


  //betters box popup
  $(document).ready(function(){
    $(".betters_button ").click(function(){
      $(".question_box").fadeIn();
      
      

    });
  });

  $(document).ready(function(){
    $(".go_to_next ").click(function(){
      $(".go_to_next_question").hide();
      
      

    });
  });


 

 

  //category buttons

  //60s rock bands
  /*
  $(document).ready(function(){
    $(" .statecapitals").click(function(){
      $(".question_box ").show();
      $(".players_box ").show();
      $(".logo_holder ").show();
      $(".rules_back_button ").hide();
      $(".logo_holder_1 ").hide();
      $(".time_control ").show();
      $(".categories_box").hide();
      $(".middle_paragraph").hide();
      $(".start_button").hide();
      
        $(".place_bet_box ").show();
        $(".cover ").show();

      
      
      

    });
  });
  */

 $(document).ready(function(){
  $(".submit_button ").click(function(){
  $(".submit_button ").attr("disabled",true);
  
    
    
    })
    
});

$(document).ready(function(){
  $(".close_box ").click(function(){
    $(".submit_button ").attr("disabled",false);
    
    })
});






$(document).ready(function(){
  $(".box").click(function(){
    $(".question_box").fadeIn();
    $(".submit_button ").attr("disabled",false);
    $(".logo").hide();
    $(".logo_holder_2").hide();
    

  });
});



  /*
  $(document).ready(function(){
    $(".category_next ").click(function(){
      $(".submit_button ").attr("disabled",false);
      $(".choose_next_question_category").hide();
      $(".place_bet_box ").show();
      $(".cover ").show();
      $(".question_box").hide();
      

    });
  });
*/

  ///end of jquery functions

  //ADD SOUND FILES TO DOCUMENT
   
  var buttonClick=document.getElementById('clickButton');
   var catPopUp=document.getElementById('catPopUp');
   var letterWoosh=document.getElementById('wooshLetter');
   var countDown=document.getElementById('clockCountDown');
   var betterBoxPop=document.getElementById('betterBox');

  //add sound to button click
  var soundClick=true;
  var popUpCat=true;
  var letterSound=true;
  var clockCount=true;
  var seconds=true;
  var betterUp=true;
  var startButton=document.querySelector('.start_button').addEventListener('click',addClickButton);
  var returnButton=document.querySelector('.rules_back_button').addEventListener('click',addClickButton);
  var catReturnButton=document.querySelector('.category_return').addEventListener('click',addClickButton);
  var nextButton=document.querySelector('.category_next').addEventListener('click',addClickButton);
  var submitButton=document.querySelector('.submit_button').addEventListener('click',addClickButton);
  var catPopUpEvent=document.querySelector('.categories_box').addEventListener('animationstart',addCatPopUpSound);
  var errorBox=document.querySelector('.error_input_field').addEventListener('animationstart',addCatPopUpSound);
 var wooshLetter_8=document.querySelector('.betters_button').addEventListener('click',wooshLetterSound); 
  var wooshLetter_8=document.querySelector('.nextBox').addEventListener('click',addBetterPoUp); 
  var clockCountDown_1=document.querySelector('.box').addEventListener('click',addBetterPoUp); 
  var vowelBox_1=document.querySelector('.vowelBox').addEventListener('click',addBetterPoUp); 
  var vowelBoxSubmit=document.querySelector('.vowel_button').addEventListener('click',addClickButton);
   
  
  function addBetterPoUp(){
  
    if(betterUp){
      betterBox.pause();
      betterBox.currentTime=0;
      betterBox.play();
      ///soundndClick=false;
    }
    };




  function addClickButton(){
  
  if(soundClick){
    clickButton.pause();
    clickButton.currentTime=0;
    clickButton.play();
    ///soundndClick=false;
  }
  };

function addCatPopUpSound(){
 if(popUpCat){
  catPopUp.pause();
  catPopUp.currentTime=0;
  catPopUp.play();
  //popUpCat=true;
}
};

function wooshLetterSound(){
  if(letterSound){
   wooshLetter.pause();
   wooshLetter.currentTime=0;
   wooshLetter.play();
   //letterSound=false;
  }
 
};

function countDownClock(){
  if(seconds){
   clockCountDown.pause();
   clockCountDown.currentTime=0;
   clockCountDown.play();
   //letterSound=false;
  }
 
};

//END OF ADD SOUND FILES TO DOCUMENT